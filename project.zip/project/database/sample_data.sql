USE kampala_traffic_predictor;

INSERT INTO users (fullname, email, password, role) VALUES
('Admin User', 'admin@traffic.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin'),
('John Doe', 'john@example.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'user'),
('Jane Smith', 'jane@example.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'user');

INSERT INTO hotspots (location_name, latitude, longitude, peak_start, peak_end, created_by) VALUES
('Clock Tower', 0.3136, 32.5811, '07:00:00', '09:00:00', 1),
('Wandegeya', 0.3352, 32.5693, '07:30:00', '09:30:00', 1),
('Nakawa', 0.3377, 32.6232, '17:00:00', '19:00:00', 1),
('Ntinda', 0.3555, 32.6178, '17:00:00', '19:00:00', 1),
('Kibuye', 0.3289, 32.5589, '16:30:00', '18:30:00', 1),
('Jinja Road', 0.3324, 32.6050, '07:00:00', '09:00:00', 1),
('Bwaise', 0.3615, 32.5558, '17:00:00', '19:00:00', 1);

INSERT INTO traffic_data (hotspot_id, congestion_level, vehicle_speed, traffic_density) VALUES
(1, 'Heavy', 8.5, 85),
(2, 'Moderate', 18.2, 60),
(3, 'Heavy', 12.1, 78),
(4, 'Light', 32.5, 30),
(5, 'Moderate', 22.0, 55),
(6, 'Heavy', 9.8, 82),
(7, 'Moderate', 19.5, 58);

INSERT INTO traffic_reports (user_id, hotspot_id, traffic_level, description, status) VALUES
(2, 1, 'Heavy', 'Road construction causing major delays', 'approved'),
(3, 2, 'Moderate', 'Normal morning traffic', 'approved'),
(2, 3, 'Heavy', 'Accident near Nakawa roundabout', 'pending');

INSERT INTO traffic_predictions (hotspot_id, predicted_level, prediction_time, confidence_score) VALUES
(1, 'Heavy', NOW() + INTERVAL 45 MINUTE, 85.5),
(2, 'Moderate', NOW() + INTERVAL 45 MINUTE, 78.2),
(3, 'Heavy', NOW() + INTERVAL 45 MINUTE, 90.0),
(4, 'Light', NOW() + INTERVAL 45 MINUTE, 72.5),
(5, 'Moderate', NOW() + INTERVAL 45 MINUTE, 80.0);
