-- CREATE DATABASE IF NOT EXISTS kampala_traffic_predictor;
-- USE kampala_traffic_predictor;

CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    fullname VARCHAR(100),
    email VARCHAR(120) UNIQUE,
    password VARCHAR(255),
    role ENUM('admin','user'),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE hotspots (
    id INT AUTO_INCREMENT PRIMARY KEY,
    location_name VARCHAR(150),
    latitude DECIMAL(10,7),
    longitude DECIMAL(10,7),
    peak_start TIME,
    peak_end TIME,
    created_by INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE traffic_data (
    id INT AUTO_INCREMENT PRIMARY KEY,
    hotspot_id INT,
    congestion_level VARCHAR(50),
    vehicle_speed DECIMAL(5,2),
    traffic_density INT,
    recorded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE traffic_predictions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    hotspot_id INT,
    predicted_level VARCHAR(50),
    prediction_time DATETIME,
    confidence_score DECIMAL(5,2),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE traffic_reports (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    hotspot_id INT,
    traffic_level VARCHAR(50),
    description TEXT,
    status ENUM('pending','approved','rejected') DEFAULT 'pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE system_settings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    sidebar_color VARCHAR(50) DEFAULT '#343a40',
    font_family VARCHAR(50) DEFAULT 'Arial',
    font_size VARCHAR(20) DEFAULT '14px'
);

INSERT INTO system_settings (sidebar_color, font_family, font_size)
VALUES ('#343a40', 'Arial', '14px');
