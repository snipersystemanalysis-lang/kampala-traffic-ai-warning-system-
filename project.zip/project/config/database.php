<?php
$host = 'localhost';
$username = 'stpaulsss_Morgan';
$password = 'Secret@123$$';
$database = 'stpaulsss_ai_warning_system';

$conn = mysqli_connect($host, $username, $password, $database);

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
?>
