<?php
session_start();
require_once 'config/database.php';
require_once 'includes/header.php';

if (isset($_SESSION['user_id'])) {
    header("Location: dashboard.php");
    exit();
}

// Fetch system settings for colors
$settings_query = "SELECT * FROM system_settings LIMIT 1";
$settings_result = mysqli_query($conn, $settings_query);
$settings = mysqli_fetch_object($settings_result);

$sidebar_color = $settings ? htmlspecialchars($settings->sidebar_color) : '#4361ee';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Registration | Kampala Traffic Predictor</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        /* Keep all your existing styles - same as before */
        * { margin: 0; padding: 0; box-sizing: border-box; }
        html, body { height: 100%; overflow: hidden; font-family: 'Inter', sans-serif; }
        body { overflow: hidden; position: fixed; width: 100%; height: 100%; }
        .login-container { position: fixed; top: 0; left: 0; right: 0; bottom: 0; width: 100%; height: 100vh; overflow: hidden; }
        .row-full { height: 100vh; margin: 0; overflow: hidden; }
        .hero-panel { position: relative; background-image: url('images/logo.jpg'); background-size: cover; background-position: center; height: 100vh; overflow-y: auto; }
        .hero-overlay { position: absolute; top: 0; left: 0; width: 100%; height: 100%; background: linear-gradient(135deg, <?php echo $sidebar_color; ?>cc 0%, <?php echo $sidebar_color; ?> 100%); backdrop-filter: brightness(0.92); }
        .hero-content { position: relative; z-index: 2; height: 100%; display: flex; flex-direction: column; justify-content: center; align-items: center; text-align: center; padding: 2rem; color: white; }
        .form-panel { height: 100vh; background: linear-gradient(135deg, #f8fafc 0%, #f1f5f9 100%); overflow-y: auto; display: flex; align-items: center; justify-content: center; padding: 1.5rem; }
        .form-card { background: white; border-radius: 2rem; padding: 2rem; box-shadow: 0 25px 45px -12px rgba(0,0,0,0.15); width: 100%; max-width: 500px; margin: auto; }
        .mobile-logo-container { display: none; text-align: center; margin-bottom: 1.5rem; }
        .mobile-logo { width: 80px; height: 80px; object-fit: cover; border-radius: 50%; box-shadow: 0 10px 25px -5px rgba(0,0,0,0.1); border: 3px solid white; }
        .input-group-custom { border: 1px solid #e2e8f0; border-radius: 1rem; transition: all 0.2s; background: white; }
        .input-group-custom:focus-within { border-color: <?php echo $sidebar_color; ?>; box-shadow: 0 0 0 3px <?php echo $sidebar_color; ?>20; }
        .input-group-custom .input-group-text { background: transparent; border: none; color: #94a3b8; padding-left: 1rem; }
        .input-group-custom input { border: none; box-shadow: none; padding: 0.75rem 0.5rem 0.75rem 0; font-size: 0.95rem; }
        .input-group-custom input:focus { outline: none; box-shadow: none; }
        .btn-register { background: linear-gradient(105deg, <?php echo $sidebar_color; ?> 0%, <?php echo $sidebar_color; ?>dd 100%); border: none; border-radius: 1rem; padding: 0.85rem; font-weight: 600; font-size: 1rem; color: white; }
        .btn-register:hover { transform: translateY(-2px); box-shadow: 0 12px 20px -12px <?php echo $sidebar_color; ?>80; }
        .auth-link { color: <?php echo $sidebar_color; ?>; font-weight: 600; text-decoration: none; }
        .auth-link:hover { text-decoration: underline; }
        @media (max-width: 992px) { .hero-panel { display: none; } .mobile-logo-container { display: block; } .form-panel { padding: 1rem; } }
    </style>
</head>
<body>
    <div class="login-container">
        <div class="row row-full g-0">
            <!-- LEFT SIDE: Hero Panel -->
            <div class="col-lg-7 hero-panel">
                <div class="hero-overlay"></div>
                <div class="hero-content">
                    <div class="mb-4">
                        <img src="images/logo.jpg" alt="Logo" style="width: 110px; height: 110px; object-fit: cover; border-radius: 50%; border: 3px solid rgba(255,255,255,0.5);">
                    </div>
                    <h1 class="display-5 fw-bold mb-3">Admin<br>Registration</h1>
                    <p class="fs-5 opacity-90 mb-4">Create an administrator account to manage the traffic prediction system.</p>
                </div>
            </div>

            <!-- RIGHT SIDE: Registration Form -->
            <div class="col-lg-5 form-panel">
                <div class="form-card">
                    <div class="mobile-logo-container">
                        <img src="images/logo.jpg" alt="Logo" class="mobile-logo">
                        <h5 class="mt-2 fw-bold" style="color: <?php echo $sidebar_color; ?>;">Admin Registration</h5>
                    </div>

                    <div class="d-none d-lg-block">
                        <h3 class="fw-bold mb-1" style="color: #1e293b;">Admin Registration</h3>
                        <p class="text-muted mb-4">Create an administrator account</p>
                    </div>

                    <div id="registerMessage"></div>

                    <form id="registerAdminForm">
                        <div class="mb-3">
                            <label class="form-label fw-semibold small text-secondary">Full Name</label>
                            <div class="input-group-custom d-flex align-items-center">
                                <span class="input-group-text"><i class="bi bi-person-fill"></i></span>
                                <input type="text" class="form-control" id="fullname" name="fullname" placeholder="Enter full name" required>
                            </div>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label fw-semibold small text-secondary">Email Address</label>
                            <div class="input-group-custom d-flex align-items-center">
                                <span class="input-group-text"><i class="bi bi-envelope-fill"></i></span>
                                <input type="email" class="form-control" id="email" name="email" placeholder="admin@example.com" required>
                            </div>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label fw-semibold small text-secondary">Password</label>
                            <div class="input-group-custom d-flex align-items-center">
                                <span class="input-group-text"><i class="bi bi-lock-fill"></i></span>
                                <input type="password" class="form-control" id="password" name="password" placeholder="Create a strong password" required>
                                <button class="btn border-0" type="button" id="togglePassword" style="color: #94a3b8;"><i class="bi bi-eye-slash"></i></button>
                            </div>
                        </div>
                        
                        <div class="mb-4">
                            <label class="form-label fw-semibold small text-secondary">Confirm Password</label>
                            <div class="input-group-custom d-flex align-items-center">
                                <span class="input-group-text"><i class="bi bi-lock-fill"></i></span>
                                <input type="password" class="form-control" id="confirm_password" name="confirm_password" placeholder="Re-enter password" required>
                            </div>
                            <div id="passwordMatch" class="small mt-1"></div>
                        </div>
                        
                        <button type="submit" class="btn-register w-100">
                            <i class="bi bi-shield-lock-fill me-2"></i>Register Admin
                        </button>
                    </form>
                    
                    <div class="mt-4 text-center">
                        <p class="mb-2 small text-secondary">Already have an account? <a href="login.php" class="auth-link">Sign In</a></p>
                        <hr class="my-3">
                        <a href="register_user.php" class="small text-muted text-decoration-none">Register as Regular User</a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Toggle password visibility
        $('#togglePassword').click(function() {
            const password = $('#password');
            const icon = $(this).find('i');
            if (password.attr('type') === 'password') {
                password.attr('type', 'text');
                icon.removeClass('bi-eye-slash').addClass('bi-eye');
            } else {
                password.attr('type', 'password');
                icon.removeClass('bi-eye').addClass('bi-eye-slash');
            }
        });

        // Password match check
        $('#confirm_password, #password').on('input', function() {
            const password = $('#password').val();
            const confirm = $('#confirm_password').val();
            if (confirm.length > 0) {
                if (password === confirm) {
                    $('#passwordMatch').html('<span class="text-success"><i class="bi bi-check-circle-fill me-1"></i> Passwords match</span>');
                } else {
                    $('#passwordMatch').html('<span class="text-danger"><i class="bi bi-x-circle-fill me-1"></i> Passwords do not match</span>');
                }
            }
        });

        // Registration form submission - NO VERIFICATION
        $('#registerAdminForm').on('submit', function(e) {
            e.preventDefault();
            
            const password = $('#password').val();
            const confirm = $('#confirm_password').val();
            
            if (password !== confirm) {
                $('#registerMessage').html('<div class="alert alert-danger"><i class="bi bi-exclamation-triangle-fill me-2"></i>Passwords do not match</div>');
                return;
            }
            
            if (password.length < 6) {
                $('#registerMessage').html('<div class="alert alert-danger"><i class="bi bi-exclamation-triangle-fill me-2"></i>Password must be at least 6 characters</div>');
                return;
            }
            
            const $btn = $(this).find('button[type="submit"]');
            $btn.prop('disabled', true).html('<span class="spinner-border spinner-border-sm me-2"></span>Creating Account...');
            
            $.ajax({
                url: 'api/register_admin.php',
                type: 'POST',
                data: $(this).serialize(),
                dataType: 'json',
                success: function(response) {
                    if (response.success) {
                        $('#registerMessage').html('<div class="alert alert-success"><i class="bi bi-check-circle-fill me-2"></i>' + response.message + '</div>');
                        setTimeout(function() {
                            window.location.href = 'login.php';
                        }, 1500);
                    } else {
                        $('#registerMessage').html('<div class="alert alert-danger"><i class="bi bi-x-circle-fill me-2"></i>' + response.message + '</div>');
                        $btn.prop('disabled', false).html('<i class="bi bi-shield-lock-fill me-2"></i>Register Admin');
                    }
                },
                error: function() {
                    $('#registerMessage').html('<div class="alert alert-danger"><i class="bi bi-x-circle-fill me-2"></i>An error occurred. Please try again.</div>');
                    $btn.prop('disabled', false).html('<i class="bi bi-shield-lock-fill me-2"></i>Register Admin');
                }
            });
        });
    </script>
</body>
</html>