<?php
require_once 'includes/admin_auth.php';
require_once 'includes/header.php';

// Set timezone to Africa/Nairobi
date_default_timezone_set('Africa/Nairobi');
?>
<style>
:root {
    --sidebar-color: <?php echo $sidebar_color; ?>;
    --primary-gradient: linear-gradient(135deg, var(--sidebar-color) 0%, <?php echo adjustBrightness($sidebar_color, -20); ?> 100%);
}

/* Modal Styles */
.modal-content {
    border-radius: 20px;
    border: none;
    box-shadow: 0 20px 60px rgba(0,0,0,0.3);
}

.modal-header {
    background: var(--primary-gradient);
    color: white;
    border-radius: 20px 20px 0 0;
    padding: 20px 25px;
    border: none;
}

.modal-header .btn-close {
    filter: brightness(0) invert(1);
    opacity: 0.8;
}

.modal-header .btn-close:hover {
    opacity: 1;
}

.modal-body {
    padding: 25px;
}

.modal-footer {
    padding: 15px 25px;
    border-top: 1px solid #eef2f6;
}

/* Form Styles */
.form-label {
    font-weight: 600;
    color: #2d3748;
    margin-bottom: 8px;
    font-size: 0.9rem;
}

.form-control, .input-group-text {
    border: 2px solid #e2e8f0;
    border-radius: 12px;
    padding: 10px 15px;
    transition: all 0.3s;
}

.form-control:focus {
    border-color: var(--sidebar-color);
    box-shadow: 0 0 0 4px rgba(102, 126, 234, 0.1);
    outline: none;
}

.input-group-text {
    background: white;
    color: var(--sidebar-color);
    border-right: none;
}

.input-group .form-control {
    border-left: none;
    padding-left: 0;
}

/* Location Search */
.location-search-wrapper {
    position: relative;
}

.suggestions-dropdown {
    position: absolute;
    top: 100%;
    left: 0;
    right: 0;
    background: white;
    border-radius: 12px;
    box-shadow: 0 10px 30px rgba(0,0,0,0.15);
    margin-top: 5px;
    max-height: 250px;
    overflow-y: auto;
    z-index: 1060;
    border: 1px solid #e2e8f0;
    display: none;
}

.suggestions-dropdown.show {
    display: block;
}

.suggestion-item {
    padding: 12px 15px;
    cursor: pointer;
    transition: all 0.2s;
    border-bottom: 1px solid #f1f5f9;
    display: flex;
    align-items: center;
    gap: 10px;
}

.suggestion-item:last-child {
    border-bottom: none;
}

.suggestion-item i {
    color: var(--sidebar-color);
    width: 20px;
}

.suggestion-name {
    font-weight: 500;
    color: #1e293b;
    flex: 1;
}

.suggestion-address {
    font-size: 0.8rem;
    color: #64748b;
}

/* Table Styles */
.hotspots-container {
    background: white;
    border-radius: 20px;
    box-shadow: 0 10px 40px rgba(0,0,0,0.08);
    overflow: hidden;
}

.table-header {
    padding: 20px 25px;
    border-bottom: 1px solid #eef2f6;
    display: flex;
    align-items: center;
    justify-content: space-between;
    flex-wrap: wrap;
    gap: 15px;
}

.table-header h2 {
    margin: 0;
    font-size: 1.5rem;
    font-weight: 700;
    color: #1e293b;
    display: flex;
    align-items: center;
    gap: 10px;
}

.table-header h2 i {
    color: var(--sidebar-color);
}

/* Search Bar */
.search-section {
    padding: 0 25px 20px 25px;
}

.search-wrapper {
    position: relative;
    max-width: 400px;
}

.search-wrapper i {
    position: absolute;
    left: 15px;
    top: 50%;
    transform: translateY(-50%);
    color: #94a3b8;
    z-index: 10;
}

.search-wrapper input {
    width: 100%;
    padding: 12px 15px 12px 45px;
    border: 2px solid #e2e8f0;
    border-radius: 50px;
    font-size: 0.95rem;
    transition: all 0.3s;
}

.search-wrapper input:focus {
    outline: none;
    border-color: var(--sidebar-color);
    box-shadow: 0 0 0 4px rgba(102, 126, 234, 0.1);
}

.search-wrapper .clear-search {
    position: absolute;
    right: 15px;
    top: 50%;
    transform: translateY(-50%);
    color: #94a3b8;
    cursor: pointer;
    display: none;
}

.search-wrapper .clear-search:hover {
    color: #ef4444;
}

/* Pagination */
.pagination-section {
    padding: 20px 25px 25px 25px;
    border-top: 1px solid #eef2f6;
    display: flex;
    align-items: center;
    justify-content: space-between;
    flex-wrap: wrap;
    gap: 15px;
}

.pagination-info {
    color: #64748b;
    font-size: 0.9rem;
}

.pagination-info strong {
    color: #1e293b;
}

.pagination-controls {
    display: flex;
    gap: 8px;
    align-items: center;
}

.pagination-btn {
    padding: 8px 14px;
    border: 1px solid #e2e8f0;
    background: white;
    border-radius: 8px;
    color: #475569;
    font-size: 0.9rem;
    cursor: pointer;
    transition: all 0.3s;
    display: flex;
    align-items: center;
    gap: 5px;
}

.pagination-btn:hover:not(:disabled) {
    background: var(--primary-gradient);
    color: white;
    border-color: var(--sidebar-color);
}

.pagination-btn:disabled {
    opacity: 0.5;
    cursor: not-allowed;
}

.pagination-btn.active {
    background: var(--primary-gradient);
    color: white;
    border-color: var(--sidebar-color);
}

.pagination-btn i {
    font-size: 0.8rem;
}

.pagination-ellipsis {
    padding: 8px 5px;
    color: #94a3b8;
}

/* Per page selector */
.per-page-selector {
    display: flex;
    align-items: center;
    gap: 10px;
}

.per-page-selector select {
    padding: 8px 12px;
    border: 2px solid #e2e8f0;
    border-radius: 8px;
    color: #1e293b;
    font-size: 0.9rem;
    cursor: pointer;
    transition: all 0.3s;
}

.per-page-selector select:focus {
    outline: none;
    border-color: var(--sidebar-color);
}

.add-btn {
    background: var(--primary-gradient);
    color: white;
    border: none;
    padding: 12px 25px;
    border-radius: 50px;
    font-weight: 600;
    display: flex;
    align-items: center;
    gap: 8px;
    transition: all 0.3s;
    box-shadow: 0 4px 15px rgba(102, 126, 234, 0.3);
}

.add-btn:hover {
    transform: translateY(-2px);
    box-shadow: 0 8px 25px rgba(102, 126, 234, 0.4);
    color: white;
}

.table-responsive {
    padding: 0 25px;
}

.table {
    margin: 0;
    border-radius: 15px;
    overflow: hidden;
}

.table thead th {
    background: #f8fafc;
    color: #475569;
    font-weight: 600;
    font-size: 0.85rem;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    border-bottom: 2px solid #e2e8f0;
    padding: 15px 12px;
}

.table tbody td {
    padding: 15px 12px;
    vertical-align: middle;
    color: #1e293b;
    border-bottom: 1px solid #eef2f6;
}

.table tbody tr:hover {
    background: #f8fafc;
}

/* Location Cell */
.location-cell {
    display: flex;
    flex-direction: column;
}

.location-name {
    font-weight: 600;
    color: #1e293b;
    margin-bottom: 4px;
}

.location-coords {
    font-size: 0.75rem;
    color: #64748b;
    font-family: monospace;
}

.location-coords i {
    margin-right: 3px;
    color: var(--sidebar-color);
}

/* Traffic Badge */
.traffic-badge {
    display: inline-block;
    padding: 5px 10px;
    border-radius: 30px;
    font-size: 0.75rem;
    font-weight: 600;
}

.traffic-badge.heavy {
    background: #fee2e2;
    color: #991b1b;
}

.traffic-badge.moderate {
    background: #fff3cd;
    color: #856404;
}

.traffic-badge.light {
    background: #d1fae5;
    color: #065f46;
}

/* Action Buttons */
.action-btn {
    padding: 6px 12px;
    border-radius: 8px;
    border: none;
    cursor: pointer;
    transition: all 0.3s;
    margin: 0 3px;
    font-size: 0.85rem;
}

.action-btn.edit {
    background: #e6f7e6;
    color: #0a7b0a;
}

.action-btn.edit:hover {
    background: #0a7b0a;
    color: white;
}

.action-btn.view {
    background: #e6f0ff;
    color: #2563eb;
}

.action-btn.view:hover {
    background: #2563eb;
    color: white;
}

.action-btn.fullscreen {
    background: #f3e8ff;
    color: #7e22ce;
}

.action-btn.fullscreen:hover {
    background: #7e22ce;
    color: white;
}

.action-btn.delete {
    background: #fee2e2;
    color: #991b1b;
}

.action-btn.delete:hover {
    background: #991b1b;
    color: white;
}

/* Status Badge */
.status-badge {
    display: inline-flex;
    align-items: center;
    gap: 5px;
    padding: 4px 10px;
    border-radius: 30px;
    font-size: 0.75rem;
    font-weight: 600;
}

.status-active {
    background: #d1fae5;
    color: #065f46;
}

/* Traffic Indicator */
.traffic-indicator {
    display: flex;
    align-items: center;
    gap: 5px;
}

.traffic-dot {
    width: 10px;
    height: 10px;
    border-radius: 50%;
    display: inline-block;
}

.traffic-dot.red { background: #dc2626; box-shadow: 0 0 10px #dc2626; }
.traffic-dot.orange { background: #f59e0b; box-shadow: 0 0 10px #f59e0b; }
.traffic-dot.green { background: #10b981; box-shadow: 0 0 10px #10b981; }

/* Fullscreen Map */
.fullscreen-map-modal .modal-dialog {
    max-width: 95vw;
    height: 95vh;
    margin: 2.5vh auto;
}

.fullscreen-map-modal .modal-content {
    height: 100%;
}

.fullscreen-map-modal .modal-body {
    padding: 0;
    height: calc(100% - 70px);
}

#fullscreenMap {
    height: 100%;
    width: 100%;
}

/* Loading State */
.loading-spinner {
    text-align: center;
    padding: 40px;
}

.loading-spinner .spinner {
    width: 40px;
    height: 40px;
    border: 3px solid #f3f3f3;
    border-top: 3px solid var(--sidebar-color);
    border-radius: 50%;
    animation: spin 1s linear infinite;
    margin: 0 auto 15px;
}

@keyframes spin {
    0% { transform: rotate(0deg); }
    100% { transform: rotate(360deg); }
}

/* Empty State */
.empty-state {
    text-align: center;
    padding: 50px;
    color: #94a3b8;
}

.empty-state i {
    font-size: 60px;
    margin-bottom: 15px;
    opacity: 0.5;
}

.empty-state h5 {
    font-size: 1.2rem;
    margin-bottom: 10px;
    color: #475569;
}

/* Time Display */
.time-display {
    font-size: 0.75rem;
    color: #64748b;
    margin-top: 4px;
}

.time-display i {
    margin-right: 3px;
    color: var(--sidebar-color);
}

/* No Results */
.no-results {
    text-align: center;
    padding: 40px;
    color: #94a3b8;
}

.no-results i {
    font-size: 48px;
    margin-bottom: 15px;
    opacity: 0.5;
}

/* Responsive */
@media (max-width: 768px) {
    .table-header {
        flex-direction: column;
        align-items: flex-start;
    }
    
    .add-btn {
        width: 100%;
        justify-content: center;
    }
    
    .table-responsive {
        padding: 0 15px;
    }
    
    .pagination-section {
        flex-direction: column;
        align-items: flex-start;
    }
    
    .pagination-controls {
        flex-wrap: wrap;
    }
    
    .fullscreen-map-modal .modal-dialog {
        max-width: 100%;
        height: 100vh;
        margin: 0;
    }
    
    .search-wrapper {
        max-width: 100%;
    }
}
</style>

<?php
function adjustBrightness($hex, $steps) {
    $hex = str_replace('#', '', $hex);
    if (strlen($hex) == 3) {
        $hex = $hex[0].$hex[0].$hex[1].$hex[1].$hex[2].$hex[2];
    }
    
    $r = hexdec(substr($hex, 0, 2));
    $g = hexdec(substr($hex, 2, 2));
    $b = hexdec(substr($hex, 4, 2));
    
    $r = max(0, min(255, $r + $steps));
    $g = max(0, min(255, $g + $steps));
    $b = max(0, min(255, $b + $steps));
    
    return '#' . sprintf("%02x%02x%02x", $r, $g, $b);
}
?>

<div class="d-flex">
    <?php require_once 'includes/sidebar.php'; ?>
    
    <div class="content flex-grow-1 p-4">
        <div class="hotspots-container">
            <div class="table-header">
                <h2>
                    <i class="bi bi-geo-alt-fill"></i>
                    Traffic Hotspots Management
                </h2>
                <button class="add-btn" data-bs-toggle="modal" data-bs-target="#addHotspotModal">
                    <i class="bi bi-plus-circle-fill"></i>
                    Add New Hotspot
                </button>
            </div>

            <!-- Search Bar -->
            <div class="search-section">
                <div class="search-wrapper">
                    <i class="bi bi-search"></i>
                    <input type="text" id="searchInput" placeholder="Search by location name or coordinates..." autocomplete="off">
                    <i class="bi bi-x-circle clear-search" id="clearSearch" onclick="clearSearch()"></i>
                </div>
            </div>

            <div class="table-responsive">
                <table class="table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Location</th>
                            <th>Peak Hours</th>
                            <th>Current Traffic</th>
                            <th>Status</th>
                            <th>Added</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody id="hotspotsTable">
                        <tr>
                            <td colspan="7" class="text-center">
                                <div class="loading-spinner">
                                    <div class="spinner"></div>
                                    <p>Loading hotspots...</p>
                                </div>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>

            <!-- Pagination Section -->
            <div class="pagination-section">
                <div class="pagination-info" id="paginationInfo">
                    Showing <strong id="startCount">0</strong> - <strong id="endCount">0</strong> of <strong id="totalCount">0</strong> hotspots
                </div>
                
                <div class="d-flex align-items-center gap-3">
                    <!-- Per Page Selector -->
                    <div class="per-page-selector">
                        <select id="perPageSelect" onchange="changePerPage()">
                            <option value="5">5 per page</option>
                            <option value="10" selected>10 per page</option>
                            <option value="25">25 per page</option>
                            <option value="50">50 per page</option>
                            <option value="100">100 per page</option>
                        </select>
                    </div>
                    
                    <!-- Pagination Controls -->
                    <div class="pagination-controls" id="paginationControls">
                        <!-- Dynamically populated by JavaScript -->
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Add Hotspot Modal -->
<div class="modal fade" id="addHotspotModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">
                    <i class="bi bi-plus-circle-fill me-2"></i>
                    Add New Traffic Hotspot
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <form id="addHotspotForm">
                    <!-- Hidden field for location name that will be submitted -->
                    <input type="hidden" id="location_name" name="location_name">
                    
                    <div class="location-search-wrapper mb-3">
                        <label class="form-label">
                            <i class="bi bi-pin-map-fill me-2" style="color: var(--sidebar-color);"></i>
                            Location Name <span class="text-danger">*</span>
                        </label>
                        <div class="input-group">
                            <span class="input-group-text">
                                <i class="bi bi-search"></i>
                            </span>
                            <input type="text" class="form-control" id="locationSearch" 
                                   placeholder="Type location name (e.g., Kampala Road, Jinja, Seeta...)" 
                                   autocomplete="off" required>
                        </div>
                        <div class="suggestions-dropdown" id="locationSuggestions"></div>
                        <small class="text-muted">Start typing to search for locations in Uganda</small>
                    </div>

                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label">
                                <i class="bi bi-globe me-2" style="color: var(--sidebar-color);"></i>
                                Latitude
                            </label>
                            <input type="text" class="form-control" id="latitude" name="latitude" readonly 
                                   placeholder="Will auto-fill from location" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">
                                <i class="bi bi-globe me-2" style="color: var(--sidebar-color);"></i>
                                Longitude
                            </label>
                            <input type="text" class="form-control" id="longitude" name="longitude" readonly 
                                   placeholder="Will auto-fill from location" required>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label">
                                <i class="bi bi-clock me-2" style="color: var(--sidebar-color);"></i>
                                Peak Start Time
                            </label>
                            <input type="time" class="form-control" name="peak_start" 
                                   value="07:00" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">
                                <i class="bi bi-clock me-2" style="color: var(--sidebar-color);"></i>
                                Peak End Time
                            </label>
                            <input type="time" class="form-control" name="peak_end" 
                                   value="09:00" required>
                        </div>
                    </div>

                    <div class="alert alert-info">
                        <i class="bi bi-info-circle-fill me-2"></i>
                        Coordinates will be automatically filled when you select a location from the suggestions.
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                <button type="submit" form="addHotspotForm" class="btn" style="background: var(--sidebar-color); color: white;">
                    <i class="bi bi-save me-2"></i>
                    Add Hotspot
                </button>
            </div>
        </div>
    </div>
</div>

<!-- Edit Hotspot Modal -->
<div class="modal fade" id="editHotspotModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">
                    <i class="bi bi-pencil-square me-2"></i>
                    Edit Hotspot
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <form id="editHotspotForm">
                    <input type="hidden" id="edit_id" name="id">
                    
                    <!-- Hidden field for location name that will be submitted -->
                    <input type="hidden" id="edit_location_name" name="location_name">
                    
                    <div class="location-search-wrapper mb-3">
                        <label class="form-label">
                            <i class="bi bi-pin-map-fill me-2" style="color: var(--sidebar-color);"></i>
                            Location Name <span class="text-danger">*</span>
                        </label>
                        <div class="input-group">
                            <span class="input-group-text">
                                <i class="bi bi-search"></i>
                            </span>
                            <input type="text" class="form-control" id="editLocationSearch" 
                                   placeholder="Type location name (e.g., Kampala Road, Jinja, Seeta...)" 
                                   autocomplete="off" required>
                        </div>
                        <div class="suggestions-dropdown" id="editLocationSuggestions"></div>
                        <small class="text-muted">Start typing to search for new locations (coordinates will update)</small>
                    </div>

                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label">
                                <i class="bi bi-globe me-2" style="color: var(--sidebar-color);"></i>
                                Latitude
                            </label>
                            <input type="text" class="form-control" id="edit_latitude" name="latitude" readonly 
                                   placeholder="Will auto-fill from location">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">
                                <i class="bi bi-globe me-2" style="color: var(--sidebar-color);"></i>
                                Longitude
                            </label>
                            <input type="text" class="form-control" id="edit_longitude" name="longitude" readonly 
                                   placeholder="Will auto-fill from location">
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Peak Start Time</label>
                            <input type="time" class="form-control" id="edit_peak_start" name="peak_start" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Peak End Time</label>
                            <input type="time" class="form-control" id="edit_peak_end" name="peak_end" required>
                        </div>
                    </div>

                    <div class="alert alert-info">
                        <i class="bi bi-info-circle-fill me-2"></i>
                        Search for a new location to update coordinates, or keep the existing ones.
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                <button type="submit" form="editHotspotForm" class="btn" style="background: var(--sidebar-color); color: white;">
                    <i class="bi bi-save me-2"></i>
                    Update Hotspot
                </button>
            </div>
        </div>
    </div>
</div>

<!-- View Hotspot Modal (Regular) -->
<div class="modal fade" id="viewHotspotModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">
                    <i class="bi bi-map-fill me-2"></i>
                    Hotspot Location
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body p-0">
                <div id="viewMap" style="height: 400px; width: 100%;"></div>
            </div>
            <div class="modal-footer">
                <div class="me-auto" id="viewLocationInfo"></div>
                <button type="button" class="btn btn-outline-primary" id="fullscreenViewBtn">
                    <i class="bi bi-arrows-fullscreen me-2"></i>
                    Full Screen
                </button>
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>

<!-- Fullscreen Map Modal -->
<div class="modal fade fullscreen-map-modal" id="fullscreenMapModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">
                    <i class="bi bi-map-fill me-2"></i>
                    <span id="fullscreenLocationName"></span>
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body p-0">
                <div id="fullscreenMap"></div>
            </div>
        </div>
    </div>
</div>

<!-- Delete Confirmation Modal -->
<div class="modal fade" id="deleteHotspotModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header bg-danger text-white">
                <h5 class="modal-title">
                    <i class="bi bi-exclamation-triangle-fill me-2"></i>
                    Confirm Delete
                </h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <p>Are you sure you want to delete this hotspot?</p>
                <p class="fw-bold" id="deleteLocationName"></p>
                <p class="text-muted small">This action cannot be undone. All associated traffic data will also be deleted.</p>
            </div>
            <div class="modal-footer">
                <input type="hidden" id="delete_id">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                <button type="button" class="btn btn-danger" id="confirmDelete">
                    <i class="bi bi-trash-fill me-2"></i>
                    Delete Hotspot
                </button>
            </div>
        </div>
    </div>
</div>

<!-- Load Leaflet for Maps -->
<link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />
<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>

<!-- Load Bootstrap Icons -->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">

<script>
// Set timezone for JavaScript
const timezone = 'Africa/Nairobi';
let searchTimeout;
let editSearchTimeout;
let viewMap = null;
let fullscreenMap = null;

// Pagination variables
let currentPage = 1;
let perPage = 10;
let totalHotspots = 0;
let allHotspots = [];
let filteredHotspots = [];
let searchTerm = '';

$(document).ready(function() {
    loadHotspots();
    
    // Search input handler
    $('#searchInput').on('input', function() {
        searchTerm = $(this).val().toLowerCase();
        
        // Show/hide clear button
        if (searchTerm.length > 0) {
            $('#clearSearch').show();
        } else {
            $('#clearSearch').hide();
        }
        
        // Filter hotspots and reset to page 1
        filterHotspots();
        currentPage = 1;
        displayCurrentPage();
    });
    
    // Location search with autocomplete for ADD modal
    $('#locationSearch').on('input', function() {
        let query = $(this).val();
        if (query.length > 2) {
            clearTimeout(searchTimeout);
            searchTimeout = setTimeout(() => searchLocations(query, 'add'), 500);
        } else {
            $('#locationSuggestions').removeClass('show');
        }
    });
    
    // Location search with autocomplete for EDIT modal
    $('#editLocationSearch').on('input', function() {
        let query = $(this).val();
        if (query.length > 2) {
            clearTimeout(editSearchTimeout);
            editSearchTimeout = setTimeout(() => searchLocations(query, 'edit'), 500);
        } else {
            $('#editLocationSuggestions').removeClass('show');
        }
    });
    
    // Add Hotspot Form Submit
    $('#addHotspotForm').on('submit', function(e) {
        e.preventDefault();
        
        // Validate coordinates
        if (!$('#latitude').val() || !$('#longitude').val()) {
            alert('Please select a location from the suggestions');
            return;
        }
        
        $.ajax({
            url: 'api/add_hotspot.php',
            type: 'POST',
            data: $(this).serialize(),
            dataType: 'json',
            success: function(response) {
                if (response.success) {
                    // Show success message
                    alert('Hotspot added successfully');
                    
                    // Reset form and close modal
                    $('#addHotspotModal').modal('hide');
                    $('#addHotspotForm')[0].reset();
                    $('#latitude, #longitude, #location_name').val('');
                    $('#locationSearch').val('');
                    
                    // Reload hotspots
                    loadHotspots();
                } else {
                    alert(response.message || 'Error adding hotspot');
                }
            },
            error: function(xhr, status, error) {
                console.error('Error:', error);
                alert('An error occurred while adding the hotspot');
            }
        });
    });
    
    // Edit Hotspot Form Submit
    $('#editHotspotForm').on('submit', function(e) {
        e.preventDefault();
        
        // Validate coordinates
        if (!$('#edit_latitude').val() || !$('#edit_longitude').val()) {
            alert('Please select a location from the suggestions');
            return;
        }
        
        $.ajax({
            url: 'api/edit_hotspot.php',
            type: 'POST',
            data: $(this).serialize(),
            dataType: 'json',
            success: function(response) {
                if (response.success) {
                    alert('Hotspot updated successfully');
                    $('#editHotspotModal').modal('hide');
                    loadHotspots();
                } else {
                    alert(response.message || 'Error updating hotspot');
                }
            },
            error: function() {
                alert('An error occurred');
            }
        });
    });
    
    // Confirm Delete
    $('#confirmDelete').on('click', function() {
        let id = $('#delete_id').val();
        
        $.ajax({
            url: 'api/delete_hotspot.php',
            type: 'POST',
            data: { id: id },
            dataType: 'json',
            success: function(response) {
                if (response.success) {
                    $('#deleteHotspotModal').modal('hide');
                    loadHotspots();
                } else {
                    alert(response.message || 'Error deleting hotspot');
                }
            }
        });
    });
    
    // Fullscreen view button
    $('#fullscreenViewBtn').on('click', function() {
        $('#viewHotspotModal').modal('hide');
        setTimeout(() => {
            $('#fullscreenMapModal').modal('show');
        }, 500);
    });
    
    // Close fullscreen modal and cleanup
    $('#fullscreenMapModal').on('hidden.bs.modal', function() {
        if (fullscreenMap) {
            fullscreenMap.remove();
            fullscreenMap = null;
        }
    });
});

// Search locations using Nominatim
function searchLocations(query, modal = 'add') {
    $.ajax({
        url: 'https://nominatim.openstreetmap.org/search',
        data: {
            format: 'json',
            q: query + ', Uganda',
            limit: 5,
            countrycodes: 'ug',
            addressdetails: 1
        },
        success: function(data) {
            if (data.length > 0) {
                let html = '';
                data.forEach(item => {
                    let displayName = item.display_name.split(',').slice(0, 3).join(',');
                    html += `
                        <div class="suggestion-item" onclick="selectLocation('${item.display_name.replace(/'/g, "\\'")}', ${item.lat}, ${item.lon}, '${modal}')">
                            <i class="bi bi-geo-alt-fill"></i>
                            <span class="suggestion-name">${item.display_name.split(',')[0]}</span>
                            <span class="suggestion-address">${displayName}</span>
                        </div>
                    `;
                });
                
                if (modal === 'add') {
                    $('#locationSuggestions').html(html).addClass('show');
                } else {
                    $('#editLocationSuggestions').html(html).addClass('show');
                }
            }
        }
    });
}

// Select location from suggestions
function selectLocation(name, lat, lon, modal = 'add') {
    // Extract just the main location name (first part before comma)
    let locationName = name.split(',')[0].trim();
    
    if (modal === 'add') {
        $('#locationSearch').val(locationName);
        $('#location_name').val(locationName);
        $('#latitude').val(lat);
        $('#longitude').val(lon);
        $('#locationSuggestions').removeClass('show');
    } else {
        $('#editLocationSearch').val(locationName);
        $('#edit_location_name').val(locationName);
        $('#edit_latitude').val(lat);
        $('#edit_longitude').val(lon);
        $('#editLocationSuggestions').removeClass('show');
    }
}

// Format time ago function
function formatTimeAgo(timestamp) {
    if (!timestamp) return 'Unknown';
    
    // Parse the timestamp (assuming it's in UTC from database)
    const date = new Date(timestamp);
    const now = new Date();
    
    // Get the actual timestamp in milliseconds
    const dateTime = date.getTime();
    const nowTime = now.getTime();
    
    // Calculate difference in seconds
    const diffSeconds = Math.floor((nowTime - dateTime) / 1000);
    
    if (diffSeconds < 60) {
        return 'just now';
    } else if (diffSeconds < 3600) {
        const minutes = Math.floor(diffSeconds / 60);
        return minutes + ' minute' + (minutes > 1 ? 's' : '') + ' ago';
    } else if (diffSeconds < 86400) {
        const hours = Math.floor(diffSeconds / 3600);
        return hours + ' hour' + (hours > 1 ? 's' : '') + ' ago';
    } else if (diffSeconds < 604800) {
        const days = Math.floor(diffSeconds / 86400);
        return days + ' day' + (days > 1 ? 's' : '') + ' ago';
    } else {
        // For older dates, return formatted date
        return date.toLocaleDateString('en-US', { 
            year: 'numeric', 
            month: 'short', 
            day: 'numeric' 
        });
    }
}

// Filter hotspots based on search term
function filterHotspots() {
    if (!searchTerm) {
        filteredHotspots = [...allHotspots];
    } else {
        filteredHotspots = allHotspots.filter(hotspot => {
            const locationName = (hotspot.location_name || '').toLowerCase();
            const coords = `${hotspot.latitude}, ${hotspot.longitude}`.toLowerCase();
            return locationName.includes(searchTerm) || coords.includes(searchTerm);
        });
    }
    
    totalHotspots = filteredHotspots.length;
}

// Display current page of hotspots
function displayCurrentPage() {
    const start = (currentPage - 1) * perPage;
    const end = Math.min(start + perPage, totalHotspots);
    const pageHotspots = filteredHotspots.slice(start, end);
    
    if (filteredHotspots.length === 0 && searchTerm) {
        // No results found
        let html = `
            <tr>
                <td colspan="7">
                    <div class="no-results">
                        <i class="bi bi-search"></i>
                        <h5>No hotspots found</h5>
                        <p>No results match "${searchTerm}"</p>
                    </div>
                </td>
            </tr>
        `;
        $('#hotspotsTable').html(html);
        $('#startCount').text(0);
        $('#endCount').text(0);
        $('#totalCount').text(0);
    } else if (filteredHotspots.length === 0) {
        // No hotspots at all
        let html = `
            <tr>
                <td colspan="7">
                    <div class="empty-state">
                        <i class="bi bi-geo-alt-fill"></i>
                        <h5>No Hotspots Found</h5>
                        <p>Click the "Add New Hotspot" button to create your first traffic hotspot.</p>
                    </div>
                </td>
            </tr>
        `;
        $('#hotspotsTable').html(html);
        $('#startCount').text(0);
        $('#endCount').text(0);
        $('#totalCount').text(0);
    } else {
        let html = '';
        pageHotspots.forEach(function(hotspot) {
            // Determine traffic class for demo (in real app, fetch from traffic_reports)
            let trafficClass = 'traffic-badge light';
            let trafficDot = 'traffic-dot green';
            let trafficText = 'Light';
            
            if (hotspot.id % 3 === 0) {
                trafficClass = 'traffic-badge moderate';
                trafficDot = 'traffic-dot orange';
                trafficText = 'Moderate';
            } else if (hotspot.id % 3 === 1) {
                trafficClass = 'traffic-badge heavy';
                trafficDot = 'traffic-dot red';
                trafficText = 'Heavy';
            }
            
            // Format coordinates
            const lat = parseFloat(hotspot.latitude).toFixed(6);
            const lng = parseFloat(hotspot.longitude).toFixed(6);
            
            html += '<tr>';
            html += '<td><span class="fw-bold">#' + hotspot.id + '</span></td>';
            html += '<td>';
            html += '<div class="location-cell">';
            html += '<span class="location-name">' + hotspot.location_name + '</span>';
            html += '<span class="location-coords"><i class="bi bi-geo-alt"></i> ' + lat + ', ' + lng + '</span>';
            html += '</div>';
            html += '</td>';
            html += '<td>' + hotspot.peak_start + ' - ' + hotspot.peak_end + '</td>';
            html += '<td>';
            html += '<div class="traffic-indicator">';
            html += '<span class="' + trafficDot + '"></span>';
            html += '<span class="' + trafficClass + '">' + trafficText + '</span>';
            html += '</div>';
            html += '</td>';
            html += '<td><span class="status-badge status-active"><i class="bi bi-circle-fill me-1" style="font-size: 0.5rem;"></i>Active</span></td>';
            html += '<td><div class="time-display"><i class="bi bi-clock"></i> ' + formatTimeAgo(hotspot.created_at) + '</div></td>';
            html += '<td>';
            html += '<button class="action-btn view" onclick="viewHotspot(' + hotspot.id + ', ' + hotspot.latitude + ', ' + hotspot.longitude + ', \'' + hotspot.location_name.replace(/'/g, "\\'") + '\', \'' + trafficClass + '\', \'' + trafficDot + '\')" title="View on Map">';
            html += '<i class="bi bi-eye"></i>';
            html += '</button> ';
            html += '<button class="action-btn fullscreen" onclick="openFullscreenMap(' + hotspot.latitude + ', ' + hotspot.longitude + ', \'' + hotspot.location_name.replace(/'/g, "\\'") + '\')" title="Full Screen Map">';
            html += '<i class="bi bi-arrows-fullscreen"></i>';
            html += '</button> ';
            html += '<button class="action-btn edit" onclick="editHotspot(' + hotspot.id + ', \'' + hotspot.location_name.replace(/'/g, "\\'") + '\', ' + hotspot.latitude + ', ' + hotspot.longitude + ', \'' + hotspot.peak_start + '\', \'' + hotspot.peak_end + '\')" title="Edit">';
            html += '<i class="bi bi-pencil"></i>';
            html += '</button> ';
            html += '<button class="action-btn delete" onclick="showDeleteModal(' + hotspot.id + ', \'' + hotspot.location_name.replace(/'/g, "\\'") + '\')" title="Delete">';
            html += '<i class="bi bi-trash"></i>';
            html += '</button>';
            html += '</td>';
            html += '</tr>';
        });
        
        $('#hotspotsTable').html(html);
        
        // Update pagination info
        $('#startCount').text(start + 1);
        $('#endCount').text(end);
        $('#totalCount').text(totalHotspots);
    }
    
    updatePaginationControls();
}

// Update pagination controls
function updatePaginationControls() {
    const totalPages = Math.ceil(totalHotspots / perPage);
    let controls = '';
    
    // Previous button
    controls += `<button class="pagination-btn" onclick="changePage(${currentPage - 1})" ${currentPage === 1 ? 'disabled' : ''}>`;
    controls += '<i class="bi bi-chevron-left"></i> Prev';
    controls += '</button>';
    
    // Page numbers
    const maxVisiblePages = 5;
    let startPage = Math.max(1, currentPage - Math.floor(maxVisiblePages / 2));
    let endPage = Math.min(totalPages, startPage + maxVisiblePages - 1);
    
    if (endPage - startPage + 1 < maxVisiblePages) {
        startPage = Math.max(1, endPage - maxVisiblePages + 1);
    }
    
    if (startPage > 1) {
        controls += `<button class="pagination-btn" onclick="changePage(1)">1</button>`;
        if (startPage > 2) {
            controls += '<span class="pagination-ellipsis">...</span>';
        }
    }
    
    for (let i = startPage; i <= endPage; i++) {
        controls += `<button class="pagination-btn ${i === currentPage ? 'active' : ''}" onclick="changePage(${i})">${i}</button>`;
    }
    
    if (endPage < totalPages) {
        if (endPage < totalPages - 1) {
            controls += '<span class="pagination-ellipsis">...</span>';
        }
        controls += `<button class="pagination-btn" onclick="changePage(${totalPages})">${totalPages}</button>`;
    }
    
    // Next button
    controls += `<button class="pagination-btn" onclick="changePage(${currentPage + 1})" ${currentPage === totalPages || totalPages === 0 ? 'disabled' : ''}>`;
    controls += 'Next <i class="bi bi-chevron-right"></i>';
    controls += '</button>';
    
    $('#paginationControls').html(controls);
}

// Change page
function changePage(page) {
    const totalPages = Math.ceil(totalHotspots / perPage);
    if (page < 1 || page > totalPages) return;
    
    currentPage = page;
    displayCurrentPage();
}

// Change items per page
function changePerPage() {
    perPage = parseInt($('#perPageSelect').val());
    currentPage = 1;
    displayCurrentPage();
}

// Clear search
function clearSearch() {
    $('#searchInput').val('');
    searchTerm = '';
    $('#clearSearch').hide();
    filterHotspots();
    currentPage = 1;
    displayCurrentPage();
}

// Load hotspots
function loadHotspots() {
    $.ajax({
        url: 'api/fetch_hotspots.php',
        type: 'GET',
        dataType: 'json',
        success: function(response) {
            if (response.success) {
                allHotspots = response.data;
                filterHotspots();
                displayCurrentPage();
            }
        },
        error: function() {
            $('#hotspotsTable').html('<tr><td colspan="7" class="text-center text-danger">Error loading hotspots</td></tr>');
        }
    });
}

// View hotspot on map (regular modal)
function viewHotspot(id, lat, lng, name, trafficClass, trafficDot) {
    $('#viewHotspotModal').modal('show');
    
    setTimeout(function() {
        if (viewMap) {
            viewMap.remove();
        }
        
        viewMap = L.map('viewMap').setView([lat, lng], 15);
        
        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            attribution: '&copy; OpenStreetMap'
        }).addTo(viewMap);
        
        // Determine traffic color
        let trafficColor = '#10b981'; // green default
        if (trafficDot.includes('red')) trafficColor = '#dc2626';
        else if (trafficDot.includes('orange')) trafficColor = '#f59e0b';
        
        L.marker([lat, lng], {
            icon: L.divIcon({
                className: 'traffic-marker',
                html: `<div style="background: ${trafficColor}; width: 20px; height: 20px; border-radius: 50%; border: 3px solid white; box-shadow: 0 0 20px ${trafficColor};"></div>`,
                iconSize: [20, 20],
                iconAnchor: [10, 10]
            })
        }).addTo(viewMap).bindPopup(`
            <b>${name}</b><br>
            Lat: ${lat.toFixed(6)}, Lng: ${lng.toFixed(6)}
        `).openPopup();
        
        $('#viewLocationInfo').html(`
            <strong><i class="bi bi-pin-map-fill me-2" style="color: var(--sidebar-color);"></i>${name}</strong><br>
            <small class="text-muted">${lat.toFixed(6)}, ${lng.toFixed(6)}</small>
        `);
        
        // Store data for fullscreen
        $('#fullscreenLocationName').text(name);
    }, 300);
}

// Open fullscreen map
function openFullscreenMap(lat, lng, name) {
    $('#fullscreenLocationName').text(name);
    $('#fullscreenMapModal').modal('show');
    
    setTimeout(function() {
        if (fullscreenMap) {
            fullscreenMap.remove();
        }
        
        fullscreenMap = L.map('fullscreenMap').setView([lat, lng], 15);
        
        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            attribution: '&copy; OpenStreetMap'
        }).addTo(fullscreenMap);
        
        L.marker([lat, lng]).addTo(fullscreenMap)
            .bindPopup(`<b>${name}</b><br>Lat: ${lat.toFixed(6)}, Lng: ${lng.toFixed(6)}`)
            .openPopup();
    }, 300);
}

// Edit hotspot
function editHotspot(id, name, lat, lng, peakStart, peakEnd) {
    $('#edit_id').val(id);
    $('#editLocationSearch').val(name);
    $('#edit_location_name').val(name);
    $('#edit_latitude').val(lat);
    $('#edit_longitude').val(lng);
    $('#edit_peak_start').val(peakStart);
    $('#edit_peak_end').val(peakEnd);
    
    $('#editHotspotModal').modal('show');
}

// Show delete confirmation modal
function showDeleteModal(id, name) {
    $('#delete_id').val(id);
    $('#deleteLocationName').text(name);
    $('#deleteHotspotModal').modal('show');
}

// Close suggestions when clicking outside
$(document).click(function(e) {
    if (!$(e.target).closest('.location-search-wrapper').length) {
        $('#locationSuggestions').removeClass('show');
        $('#editLocationSuggestions').removeClass('show');
    }
});
</script>

<?php require_once 'includes/footer.php'; ?>