<?php
require_once 'includes/admin_auth.php';
require_once 'includes/header.php';

// Set timezone
date_default_timezone_set('Africa/Nairobi');

// Fetch real data from database for AI analysis
$conn = $GLOBALS['conn'];

// Get total reports count
$total_reports_query = "SELECT COUNT(*) as total FROM traffic_reports";
$total_reports_result = mysqli_query($conn, $total_reports_query);
$total_reports = mysqli_fetch_assoc($total_reports_result)['total'];

// Get hotspots count
$hotspots_query = "SELECT COUNT(*) as total FROM hotspots";
$hotspots_result = mysqli_query($conn, $hotspots_query);
$total_hotspots = mysqli_fetch_assoc($hotspots_result)['total'];

// Get today's reports
$today_reports_query = "SELECT COUNT(*) as total FROM traffic_reports WHERE DATE(created_at) = CURDATE()";
$today_reports_result = mysqli_query($conn, $today_reports_query);
$today_reports = mysqli_fetch_assoc($today_reports_result)['total'];

// Get average confidence score from predictions
$confidence_query = "SELECT AVG(confidence_score) as avg_confidence FROM traffic_predictions";
$confidence_result = mysqli_query($conn, $confidence_query);
$avg_confidence = round(mysqli_fetch_assoc($confidence_result)['avg_confidence'] ?: 94);
?>
<style>
:root {
    --sidebar-color: <?php echo $sidebar_color; ?>;
    --primary-gradient: linear-gradient(135deg, var(--sidebar-color) 0%, <?php echo adjustBrightness($sidebar_color, -20); ?> 100%);
    --glow-color: <?php echo adjustBrightness($sidebar_color, 40); ?>;
}

/* Analytics Wrapper */
.analytics-wrapper {
    display: flex;
    min-height: 100vh;
    background: #f8fafc;
}

.main-content {
    flex: 1;
    margin-left: var(--sidebar-width);
    transition: margin-left 0.3s;
    padding: 30px;
}

/* AI Header with Glowing Effect */
.ai-header-section {
    background: var(--primary-gradient);
    border-radius: 24px;
    padding: 30px;
    margin-bottom: 30px;
    color: white;
    position: relative;
    overflow: hidden;
    box-shadow: 0 20px 40px rgba(102, 126, 234, 0.3);
    animation: glow 3s infinite alternate;
}

@keyframes glow {
    from { box-shadow: 0 20px 40px rgba(102, 126, 234, 0.3); }
    to { box-shadow: 0 20px 60px rgba(102, 126, 234, 0.6); }
}

.ai-header-section::before {
    content: '';
    position: absolute;
    top: -50%;
    right: -50%;
    width: 200%;
    height: 200%;
    background: radial-gradient(circle, rgba(255,255,255,0.2) 0%, transparent 70%);
    animation: rotate 30s linear infinite;
}

@keyframes rotate {
    from { transform: rotate(0deg); }
    to { transform: rotate(360deg); }
}

.ai-header-content {
    position: relative;
    z-index: 1;
    display: flex;
    align-items: center;
    gap: 20px;
    flex-wrap: wrap;
}

.ai-icon {
    width: 80px;
    height: 80px;
    background: rgba(255,255,255,0.2);
    border-radius: 20px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 40px;
    backdrop-filter: blur(10px);
    border: 1px solid rgba(255,255,255,0.3);
    animation: pulse-icon 2s infinite;
}

@keyframes pulse-icon {
    0%, 100% { transform: scale(1); }
    50% { transform: scale(1.05); }
}

.ai-text h1 {
    font-size: 2.5rem;
    font-weight: 700;
    margin: 0 0 5px;
    text-shadow: 0 0 20px rgba(255,255,255,0.5);
}

.ai-text p {
    margin: 0;
    opacity: 0.9;
    font-size: 1.1rem;
}

.ai-badge {
    background: rgba(255,255,255,0.2);
    padding: 8px 20px;
    border-radius: 50px;
    font-size: 0.9rem;
    display: inline-flex;
    align-items: center;
    gap: 8px;
    backdrop-filter: blur(10px);
    border: 1px solid rgba(255,255,255,0.3);
}

.ai-badge i {
    color: #ffd700;
}

/* Stats Cards */
.stats-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    gap: 20px;
    margin-bottom: 30px;
}

.stat-card {
    background: white;
    border-radius: 16px;
    padding: 20px;
    box-shadow: 0 5px 20px rgba(0,0,0,0.05);
    border: 1px solid rgba(0,0,0,0.05);
    display: flex;
    align-items: center;
    gap: 15px;
    transition: all 0.3s;
}

.stat-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 15px 30px rgba(102, 126, 234, 0.2);
    border-color: var(--sidebar-color);
}

.stat-icon {
    width: 50px;
    height: 50px;
    background: var(--primary-gradient);
    border-radius: 12px;
    display: flex;
    align-items: center;
    justify-content: center;
    color: white;
    font-size: 24px;
}

.stat-content h3 {
    font-size: 1.8rem;
    font-weight: 700;
    margin: 0;
    color: #1e293b;
}

.stat-content p {
    margin: 0;
    color: #64748b;
    font-size: 0.9rem;
}

/* AI Insights Panel */
.ai-insights-panel {
    background: linear-gradient(135deg, #1e293b 0%, #0f172a 100%);
    border-radius: 20px;
    padding: 25px;
    margin-bottom: 30px;
    color: white;
    border: 1px solid rgba(255,255,255,0.1);
    position: relative;
    overflow: hidden;
}

.ai-insights-panel::before {
    content: '';
    position: absolute;
    top: -50%;
    right: -50%;
    width: 200%;
    height: 200%;
    background: radial-gradient(circle, rgba(102,126,234,0.2) 0%, transparent 70%);
    animation: rotate 30s linear infinite;
}

.insights-header {
    display: flex;
    align-items: center;
    gap: 10px;
    margin-bottom: 20px;
    position: relative;
    z-index: 1;
}

.insights-header i {
    font-size: 28px;
    color: #ffd700;
}

.insights-header h4 {
    margin: 0;
    font-size: 1.3rem;
    font-weight: 600;
}

.insights-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
    gap: 20px;
    position: relative;
    z-index: 1;
}

.insight-item {
    background: rgba(255,255,255,0.1);
    backdrop-filter: blur(10px);
    border-radius: 16px;
    padding: 20px;
    border: 1px solid rgba(255,255,255,0.2);
    transition: all 0.3s;
}

.insight-item:hover {
    transform: translateY(-5px);
    background: rgba(255,255,255,0.15);
}

.insight-title {
    font-size: 0.9rem;
    opacity: 0.8;
    margin-bottom: 8px;
    display: flex;
    align-items: center;
    gap: 5px;
}

.insight-value {
    font-size: 2rem;
    font-weight: 700;
    margin-bottom: 5px;
}

.insight-trend {
    font-size: 0.8rem;
    display: flex;
    align-items: center;
    gap: 5px;
}

.trend-up { color: #10b981; }
.trend-down { color: #ef4444; }

/* Chart Cards */
.chart-grid {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: 25px;
    margin-bottom: 25px;
}

.chart-card {
    background: white;
    border-radius: 20px;
    overflow: hidden;
    box-shadow: 0 5px 20px rgba(0,0,0,0.05);
    border: 1px solid rgba(0,0,0,0.05);
    transition: all 0.3s;
}

.chart-card:hover {
    box-shadow: 0 15px 35px rgba(102, 126, 234, 0.15);
    border-color: var(--sidebar-color);
}

.chart-card.large {
    grid-column: span 2;
}

.chart-header {
    padding: 20px;
    border-bottom: 1px solid #eef2f6;
    display: flex;
    align-items: center;
    justify-content: space-between;
    background: linear-gradient(135deg, #f8fafc, #ffffff);
}

.chart-header h5 {
    margin: 0;
    font-weight: 600;
    color: #1e293b;
    display: flex;
    align-items: center;
    gap: 10px;
}

.chart-header i {
    color: var(--sidebar-color);
}

.chart-body {
    padding: 20px;
    height: 350px;
    position: relative;
}

/* Legend */
.chart-legend {
    display: flex;
    gap: 15px;
    flex-wrap: wrap;
}

.legend-item {
    display: flex;
    align-items: center;
    gap: 8px;
    font-size: 0.85rem;
    color: #64748b;
}

.legend-color {
    width: 12px;
    height: 12px;
    border-radius: 4px;
}

/* Hotspot Analysis */
.hotspot-analysis {
    background: white;
    border-radius: 20px;
    padding: 25px;
    margin-top: 25px;
    box-shadow: 0 5px 20px rgba(0,0,0,0.05);
    border: 1px solid rgba(0,0,0,0.05);
}

.analysis-header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    margin-bottom: 20px;
    flex-wrap: wrap;
    gap: 15px;
}

.analysis-header h4 {
    margin: 0;
    font-size: 1.2rem;
    font-weight: 600;
    color: #1e293b;
    display: flex;
    align-items: center;
    gap: 10px;
}

.analysis-header i {
    color: var(--sidebar-color);
}

.hotspot-table {
    width: 100%;
    border-collapse: collapse;
}

.hotspot-table th {
    text-align: left;
    padding: 12px;
    background: #f8fafc;
    font-size: 0.85rem;
    font-weight: 600;
    color: #64748b;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    border-bottom: 2px solid #e2e8f0;
}

.hotspot-table td {
    padding: 12px;
    border-bottom: 1px solid #eef2f6;
    color: #1e293b;
}

.hotspot-table tr:hover {
    background: #f8fafc;
}

.hotspot-rank {
    width: 30px;
    height: 30px;
    background: var(--primary-gradient);
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    color: white;
    font-weight: 600;
    font-size: 0.9rem;
}

.progress-bar {
    width: 100%;
    height: 6px;
    background: #e2e8f0;
    border-radius: 3px;
    overflow: hidden;
}

.progress-fill {
    height: 100%;
    background: var(--primary-gradient);
    border-radius: 3px;
    transition: width 0.5s ease;
}

/* AI Recommendation */
.ai-recommendation {
    background: var(--primary-gradient);
    border-radius: 20px;
    padding: 25px;
    margin-top: 25px;
    color: white;
    position: relative;
    overflow: hidden;
}

.ai-recommendation::before {
    content: '';
    position: absolute;
    top: -50%;
    right: -50%;
    width: 200%;
    height: 200%;
    background: radial-gradient(circle, rgba(255,255,255,0.2) 0%, transparent 70%);
    animation: rotate 30s linear infinite;
}

.recommendation-content {
    position: relative;
    z-index: 1;
    display: flex;
    align-items: center;
    gap: 20px;
    flex-wrap: wrap;
}

.recommendation-icon {
    width: 60px;
    height: 60px;
    background: rgba(255,255,255,0.2);
    border-radius: 16px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 30px;
}

.recommendation-text {
    flex: 1;
}

.recommendation-text h5 {
    margin: 0 0 5px;
    font-size: 1.2rem;
    font-weight: 600;
}

.recommendation-text p {
    margin: 0;
    opacity: 0.9;
}

.recommendation-badge {
    background: rgba(255,255,255,0.2);
    padding: 10px 25px;
    border-radius: 50px;
    font-size: 0.9rem;
    display: flex;
    align-items: center;
    gap: 8px;
    backdrop-filter: blur(10px);
    border: 1px solid rgba(255,255,255,0.3);
}

/* Loading State */
.loading-spinner {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    height: 300px;
}

.spinner {
    width: 40px;
    height: 40px;
    border: 3px solid #f3f3f3;
    border-top: 3px solid var(--sidebar-color);
    border-radius: 50%;
    animation: spin 1s linear infinite;
    margin-bottom: 15px;
}

@keyframes spin {
    0% { transform: rotate(0deg); }
    100% { transform: rotate(360deg); }
}

/* Responsive */
@media (max-width: 991px) {
    .main-content {
        margin-left: 0;
        padding: 20px;
    }
    
    .chart-grid {
        grid-template-columns: 1fr;
    }
    
    .chart-card.large {
        grid-column: span 1;
    }
}

@media (max-width: 768px) {
    .ai-header-content {
        flex-direction: column;
        text-align: center;
    }
    
    .ai-icon {
        margin: 0 auto;
    }
    
    .insights-grid {
        grid-template-columns: 1fr;
    }
    
    .recommendation-content {
        flex-direction: column;
        text-align: center;
    }
}
</style>

<?php
function adjustBrightness($hex, $steps) {
    $hex = str_replace('#', '', $hex);
    if (strlen($hex) == 3) {
        $hex = $hex[0].$hex[0].$hex[1].$hex[1].$hex[2].$hex[2];
    }
    
    $r = hexdec(substr($hex, 0, 2));
    $g = hexdec(substr($hex, 2, 2));
    $b = hexdec(substr($hex, 4, 2));
    
    $r = max(0, min(255, $r + $steps));
    $g = max(0, min(255, $g + $steps));
    $b = max(0, min(255, $b + $steps));
    
    return '#' . sprintf("%02x%02x%02x", $r, $g, $b);
}
?>

<div class="analytics-wrapper">
    <?php require_once 'includes/sidebar.php'; ?>
    
    <div class="main-content">
        <!-- AI Header with Glowing Effect -->
        <div class="ai-header-section">
            <div class="ai-header-content">
                <div class="ai-icon">
                    <i class="bi bi-graph-up-arrow"></i>
                </div>
                <div class="ai-text">
                    <h1>Traffic Analytics Dashboard</h1>
                    <p>AI-powered insights and predictive analysis of Kampala traffic patterns</p>
                </div>
                <div class="ms-auto">
                    <span class="ai-badge">
                        <i class="bi bi-cpu"></i>
                        AI v2.4 · Real-time
                    </span>
                </div>
            </div>
        </div>

        <!-- Stats Cards with Real Data -->
        <div class="stats-grid">
            <div class="stat-card">
                <div class="stat-icon">
                    <i class="bi bi-flag-fill"></i>
                </div>
                <div class="stat-content">
                    <h3><?php echo number_format($total_reports); ?></h3>
                    <p>Total Reports</p>
                </div>
            </div>
            <div class="stat-card">
                <div class="stat-icon">
                    <i class="bi bi-calendar-day"></i>
                </div>
                <div class="stat-content">
                    <h3><?php echo number_format($today_reports); ?></h3>
                    <p>Today's Reports</p>
                </div>
            </div>
            <div class="stat-card">
                <div class="stat-icon">
                    <i class="bi bi-geo-alt-fill"></i>
                </div>
                <div class="stat-content">
                    <h3><?php echo number_format($total_hotspots); ?></h3>
                    <p>Active Hotspots</p>
                </div>
            </div>
            <div class="stat-card">
                <div class="stat-icon">
                    <i class="bi bi-robot"></i>
                </div>
                <div class="stat-content">
                    <h3><?php echo $avg_confidence; ?>%</h3>
                    <p>AI Confidence</p>
                </div>
            </div>
        </div>

        <!-- AI Insights Panel -->
        <div class="ai-insights-panel">
            <div class="insights-header">
                <i class="bi bi-lightbulb-fill"></i>
                <h4>AI Traffic Intelligence</h4>
            </div>
            <div class="insights-grid" id="aiInsights">
                <!-- Populated by JavaScript -->
            </div>
        </div>

        <!-- Charts Grid -->
        <div class="chart-grid">
            <!-- Most Congested Roads -->
            <div class="chart-card">
                <div class="chart-header">
                    <h5>
                        <i class="bi bi-bar-chart-fill"></i>
                        Most Congested Hotspots
                    </h5>
                    <div class="chart-legend">
                        <span class="legend-item">
                            <span class="legend-color" style="background: #ef4444;"></span>
                            Heavy Traffic
                        </span>
                    </div>
                </div>
                <div class="chart-body">
                    <canvas id="congestedRoadsChart"></canvas>
                </div>
            </div>

            <!-- Peak Traffic Hours -->
            <div class="chart-card">
                <div class="chart-header">
                    <h5>
                        <i class="bi bi-clock-history"></i>
                        Peak Traffic Hours
                    </h5>
                </div>
                <div class="chart-body">
                    <canvas id="peakHoursChart"></canvas>
                </div>
            </div>

            <!-- Daily Congestion Trends -->
            <div class="chart-card large">
                <div class="chart-header">
                    <h5>
                        <i class="bi bi-graph-up-arrow"></i>
                        Daily Congestion Trends
                    </h5>
                </div>
                <div class="chart-body">
                    <canvas id="dailyTrendsChart"></canvas>
                </div>
            </div>

            <!-- Weekly Patterns -->
            <div class="chart-card large">
                <div class="chart-header">
                    <h5>
                        <i class="bi bi-calendar-week"></i>
                        Weekly Traffic Patterns
                    </h5>
                </div>
                <div class="chart-body">
                    <canvas id="weeklyPatternsChart"></canvas>
                </div>
            </div>
        </div>

        <!-- Hotspot Analysis Table -->
        <div class="hotspot-analysis">
            <div class="analysis-header">
                <h4>
                    <i class="bi bi-map-fill"></i>
                    Detailed Hotspot Analysis
                </h4>
                <span class="ai-badge" style="background: var(--primary-gradient); color: white;">
                    <i class="bi bi-sort-down"></i>
                    Sorted by congestion level
                </span>
            </div>
            <table class="hotspot-table">
                <thead>
                    <tr>
                        <th>Rank</th>
                        <th>Hotspot</th>
                        <th>Reports</th>
                        <th>Avg Congestion</th>
                        <th>Peak Time</th>
                        <th>Trend</th>
                        <th>Congestion Level</th>
                    </tr>
                </thead>
                <tbody id="hotspotAnalysisTable">
                    <!-- Populated by JavaScript -->
                </tbody>
            </table>
        </div>

        <!-- AI Recommendation -->
        <div class="ai-recommendation">
            <div class="recommendation-content">
                <div class="recommendation-icon">
                    <i class="bi bi-robot"></i>
                </div>
                <div class="recommendation-text">
                    <h5>AI Traffic Recommendation</h5>
                    <p id="aiRecommendation">Analyzing traffic patterns to provide optimal route suggestions...</p>
                </div>
                <div class="recommendation-badge">
                    <i class="bi bi-star-fill"></i>
                    <span>Updated just now</span>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
<script>
$(document).ready(function() {
    loadAnalytics();
    loadHotspotAnalysis();
    generateAIInsights();
});

// Load all analytics data
function loadAnalytics() {
    $.ajax({
        url: 'api/analytics_api.php',
        type: 'GET',
        data: { action: 'get_analytics_data' },
        dataType: 'json',
        success: function(response) {
            if (response.success) {
                createCharts(response.data);
            } else {
                // Fallback to default data if API not ready
                createDefaultCharts();
            }
        },
        error: function() {
            // Fallback to default charts
            createDefaultCharts();
        }
    });
}

// Create charts with real data
function createCharts(data) {
    // Most Congested Roads Chart
    new Chart(document.getElementById('congestedRoadsChart'), {
        type: 'bar',
        data: {
            labels: data.hotspots.labels,
            datasets: [{
                label: 'Congestion Level',
                data: data.hotspots.values,
                backgroundColor: data.hotspots.values.map(v => 
                    v > 70 ? '#ef4444' : (v > 40 ? '#f59e0b' : '#10b981')
                ),
                borderRadius: 6
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { display: false }
            },
            scales: {
                y: { 
                    beginAtZero: true, 
                    max: 100,
                    title: { display: true, text: 'Congestion %' }
                }
            }
        }
    });

    // Peak Hours Chart
    new Chart(document.getElementById('peakHoursChart'), {
        type: 'line',
        data: {
            labels: data.peak_hours.labels,
            datasets: [{
                label: 'Traffic Level',
                data: data.peak_hours.values,
                borderColor: '#667eea',
                backgroundColor: 'rgba(102, 126, 234, 0.1)',
                tension: 0.4,
                fill: true,
                pointBackgroundColor: '#667eea',
                pointBorderColor: 'white',
                pointRadius: 5,
                pointHoverRadius: 8
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { display: false }
            },
            scales: {
                y: { 
                    beginAtZero: true,
                    title: { display: true, text: 'Traffic Level' }
                }
            }
        }
    });

    // Daily Trends Chart
    new Chart(document.getElementById('dailyTrendsChart'), {
        type: 'line',
        data: {
            labels: data.daily.labels,
            datasets: [{
                label: 'Morning Peak (7-9am)',
                data: data.daily.morning,
                borderColor: '#f59e0b',
                backgroundColor: 'rgba(245, 158, 11, 0.1)',
                tension: 0.4
            }, {
                label: 'Evening Peak (5-7pm)',
                data: data.daily.evening,
                borderColor: '#ef4444',
                backgroundColor: 'rgba(239, 68, 68, 0.1)',
                tension: 0.4
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { position: 'bottom' }
            }
        }
    });

    // Weekly Patterns Chart
    new Chart(document.getElementById('weeklyPatternsChart'), {
        type: 'bar',
        data: {
            labels: data.weekly.labels,
            datasets: [{
                label: 'Total Reports',
                data: data.weekly.reports,
                backgroundColor: '#10b981',
                borderRadius: 6
            }, {
                label: 'Average Congestion',
                data: data.weekly.congestion,
                backgroundColor: '#f59e0b',
                borderRadius: 6
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { position: 'bottom' }
            }
        }
    });
}

// Fallback default charts
function createDefaultCharts() {
    // Most Congested Roads
    new Chart(document.getElementById('congestedRoadsChart'), {
        type: 'bar',
        data: {
            labels: ['Clock Tower', 'Wandegeya', 'Nakawa', 'Ntinda', 'Kibuye'],
            datasets: [{
                label: 'Congestion Level',
                data: [85, 78, 92, 69, 81],
                backgroundColor: ['#ef4444', '#f59e0b', '#ef4444', '#10b981', '#f59e0b'],
                borderRadius: 6
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: { legend: { display: false } },
            scales: { y: { beginAtZero: true, max: 100 } }
        }
    });

    // Peak Hours
    new Chart(document.getElementById('peakHoursChart'), {
        type: 'line',
        data: {
            labels: ['6AM', '8AM', '10AM', '12PM', '2PM', '4PM', '6PM', '8PM', '10PM'],
            datasets: [{
                label: 'Traffic Level',
                data: [25, 75, 45, 55, 50, 65, 90, 55, 25],
                borderColor: '#667eea',
                backgroundColor: 'rgba(102, 126, 234, 0.1)',
                tension: 0.4,
                fill: true
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: { legend: { display: false } }
        }
    });

    // Daily Trends
    new Chart(document.getElementById('dailyTrendsChart'), {
        type: 'line',
        data: {
            labels: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
            datasets: [{
                label: 'Morning Peak (7-9am)',
                data: [65, 68, 72, 75, 80, 45, 30],
                borderColor: '#f59e0b',
                backgroundColor: 'rgba(245, 158, 11, 0.1)',
                tension: 0.4
            }, {
                label: 'Evening Peak (5-7pm)',
                data: [75, 78, 82, 85, 90, 50, 35],
                borderColor: '#ef4444',
                backgroundColor: 'rgba(239, 68, 68, 0.1)',
                tension: 0.4
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: { legend: { position: 'bottom' } }
        }
    });

    // Weekly Patterns
    new Chart(document.getElementById('weeklyPatternsChart'), {
        type: 'bar',
        data: {
            labels: ['Week 1', 'Week 2', 'Week 3', 'Week 4'],
            datasets: [{
                label: 'Total Reports',
                data: [120, 135, 148, 130],
                backgroundColor: '#10b981',
                borderRadius: 6
            }, {
                label: 'Average Congestion',
                data: [65, 68, 72, 70],
                backgroundColor: '#f59e0b',
                borderRadius: 6
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: { legend: { position: 'bottom' } }
        }
    });
}

// Load hotspot analysis table
function loadHotspotAnalysis() {
    $.ajax({
        url: 'api/analytics_api.php',
        type: 'GET',
        data: { action: 'get_hotspot_analysis' },
        dataType: 'json',
        success: function(response) {
            if (response.success) {
                displayHotspotAnalysis(response.data);
            } else {
                displayDefaultHotspotAnalysis();
            }
        },
        error: function() {
            displayDefaultHotspotAnalysis();
        }
    });
}

// Display hotspot analysis table
function displayHotspotAnalysis(hotspots) {
    let html = '';
    
    hotspots.forEach(function(hotspot, index) {
        let trendIcon = hotspot.trend > 0 ? '📈' : (hotspot.trend < 0 ? '📉' : '➡️');
        let trendClass = hotspot.trend > 0 ? 'trend-up' : (hotspot.trend < 0 ? 'trend-down' : '');
        
        html += `
            <tr>
                <td><span class="hotspot-rank">${index + 1}</span></td>
                <td><strong>${hotspot.name}</strong></td>
                <td>${hotspot.reports}</td>
                <td>${hotspot.avg_congestion}%</td>
                <td>${hotspot.peak_time}</td>
                <td class="${trendClass}">${trendIcon} ${Math.abs(hotspot.trend)}%</td>
                <td style="width: 150px;">
                    <div class="progress-bar">
                        <div class="progress-fill" style="width: ${hotspot.avg_congestion}%; background: ${hotspot.avg_congestion > 70 ? '#ef4444' : (hotspot.avg_congestion > 40 ? '#f59e0b' : '#10b981')};"></div>
                    </div>
                </td>
            </tr>
        `;
    });
    
    $('#hotspotAnalysisTable').html(html);
}

// Fallback default hotspot analysis
function displayDefaultHotspotAnalysis() {
    const defaultHotspots = [
        { name: 'Clock Tower', reports: 156, avg_congestion: 85, peak_time: '7:30-9:00 AM', trend: 5 },
        { name: 'Nakawa', reports: 142, avg_congestion: 92, peak_time: '5:30-7:30 PM', trend: 8 },
        { name: 'Wandegeya', reports: 128, avg_congestion: 78, peak_time: '8:00-9:30 AM', trend: -2 },
        { name: 'Ntinda', reports: 115, avg_congestion: 69, peak_time: '6:00-8:00 PM', trend: 3 },
        { name: 'Kibuye', reports: 98, avg_congestion: 81, peak_time: '7:00-8:30 AM', trend: -1 },
        { name: 'Jinja Road', reports: 87, avg_congestion: 73, peak_time: '5:00-7:00 PM', trend: 4 },
        { name: 'Entebbe Road', reports: 76, avg_congestion: 58, peak_time: '6:30-8:30 AM', trend: -3 },
        { name: 'Bombo Road', reports: 65, avg_congestion: 64, peak_time: '7:00-9:00 AM', trend: 2 }
    ];
    
    displayHotspotAnalysis(defaultHotspots);
}

// Generate AI insights based on data
function generateAIInsights() {
    $.ajax({
        url: 'api/analytics_api.php',
        type: 'GET',
        data: { action: 'get_ai_insights' },
        dataType: 'json',
        success: function(response) {
            if (response.success) {
                displayAIInsights(response.data);
                $('#aiRecommendation').text(response.data.recommendation);
            } else {
                displayDefaultAIInsights();
            }
        },
        error: function() {
            displayDefaultAIInsights();
        }
    });
}

// Display AI insights
function displayAIInsights(insights) {
    let html = `
        <div class="insight-item">
            <div class="insight-title">
                <i class="bi bi-clock"></i> Peak Hour
            </div>
            <div class="insight-value">${insights.peak_hour}</div>
            <div class="insight-trend">${insights.peak_traffic}% congestion</div>
        </div>
        <div class="insight-item">
            <div class="insight-title">
                <i class="bi bi-geo-alt"></i> Busiest Hotspot
            </div>
            <div class="insight-value">${insights.busiest_hotspot}</div>
            <div class="insight-trend">${insights.busiest_count} reports today</div>
        </div>
        <div class="insight-item">
            <div class="insight-title">
                <i class="bi bi-arrow-up"></i> Trend
            </div>
            <div class="insight-value">${insights.trend}</div>
            <div class="insight-trend ${insights.trend_class}">${insights.trend_detail}</div>
        </div>
        <div class="insight-item">
            <div class="insight-title">
                <i class="bi bi-bar-chart"></i> Avg Congestion
            </div>
            <div class="insight-value">${insights.avg_congestion}%</div>
            <div class="insight-trend">${insights.congestion_level}</div>
        </div>
    `;
    
    $('#aiInsights').html(html);
}

// Fallback default AI insights
function displayDefaultAIInsights() {
    const insights = {
        peak_hour: '5:30 - 7:30 PM',
        peak_traffic: 92,
        busiest_hotspot: 'Nakawa',
        busiest_count: 142,
        trend: '+8%',
        trend_class: 'trend-up',
        trend_detail: 'Increasing vs last week',
        avg_congestion: 74,
        congestion_level: 'Moderate-Heavy'
    };
    
    displayAIInsights(insights);
    
    $('#aiRecommendation').text(
        'Based on current patterns, avoid Nakawa and Clock Tower between 5-7 PM. ' +
        'Consider using Northern Bypass as an alternative route. ' +
        'Traffic is expected to increase by 8% this week due to ongoing road works.'
    );
}

// Auto-refresh every 60 seconds
setInterval(function() {
    loadAnalytics();
    loadHotspotAnalysis();
    generateAIInsights();
}, 60000);
</script>

<?php require_once 'includes/footer.php'; ?>