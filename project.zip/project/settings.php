<?php
require_once 'includes/admin_auth.php';
require_once 'includes/header.php';
require_once 'config/database.php';

$query = "SELECT * FROM system_settings LIMIT 1";
$result = mysqli_query($conn, $query);
$settings = mysqli_fetch_object($result);
?>
<div class="d-flex">
    <?php require_once 'includes/sidebar.php'; ?>
    <div class="content flex-grow-1 p-4">
        <div class="container-fluid">
            <h2 class="mb-4">System Settings</h2>

            <div class="card">
                <div class="card-header bg-primary text-white">
                    <h5>Customize System Appearance</h5>
                </div>
                <div class="card-body">
                    <div id="settingsMessage"></div>
                    <form id="settingsForm">
                        <div class="mb-3">
                            <label class="form-label">Sidebar Color</label>
                            <input type="color" class="form-control" name="sidebar_color" value="<?php echo htmlspecialchars($settings->sidebar_color); ?>">
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Font Family</label>
                            <select class="form-control" name="font_family">
                                <option value="Arial" <?php echo $settings->font_family == 'Arial' ? 'selected' : ''; ?>>Arial</option>
                                <option value="Helvetica" <?php echo $settings->font_family == 'Helvetica' ? 'selected' : ''; ?>>Helvetica</option>
                                <option value="Times New Roman" <?php echo $settings->font_family == 'Times New Roman' ? 'selected' : ''; ?>>Times New Roman</option>
                                <option value="Georgia" <?php echo $settings->font_family == 'Georgia' ? 'selected' : ''; ?>>Georgia</option>
                                <option value="Georgia" <?php echo $settings->font_family == 'Calibri' ? 'selected' : ''; ?>>Calibri</option>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Font Size</label>
                            <select class="form-control" name="font_size">
                                <option value="12px" <?php echo $settings->font_size == '12px' ? 'selected' : ''; ?>>12px</option>
                                <option value="14px" <?php echo $settings->font_size == '14px' ? 'selected' : ''; ?>>14px</option>
                                <option value="16px" <?php echo $settings->font_size == '16px' ? 'selected' : ''; ?>>16px</option>
                                <option value="18px" <?php echo $settings->font_size == '18px' ? 'selected' : ''; ?>>18px</option>
                            </select>
                        </div>
                        <button type="submit" class="btn btn-primary">Save Settings</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
$('#settingsForm').on('submit', function(e) {
    e.preventDefault();
    $.ajax({
        url: 'api/update_settings.php',
        type: 'POST',
        data: $(this).serialize(),
        dataType: 'json',
        success: function(response) {
            if (response.success) {
                $('#settingsMessage').html('<div class="alert alert-success">Settings updated successfully</div>');
                setTimeout(function() {
                    location.reload();
                }, 1500);
            } else {
                $('#settingsMessage').html('<div class="alert alert-danger">' + response.message + '</div>');
            }
        }
    });
});
</script>

<?php require_once 'includes/footer.php'; ?>
