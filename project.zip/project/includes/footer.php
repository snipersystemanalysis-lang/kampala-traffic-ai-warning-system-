    
    <script src="assets/js/validation.js"></script>
    <script src="assets/js/ajax_requests.js"></script>
</body>
</html>
