<?php
require_once 'config/database.php';

$settings_query = "SELECT * FROM system_settings LIMIT 1";
$settings_result = mysqli_query($conn, $settings_query);
$settings = mysqli_fetch_object($settings_result);

$sidebar_color = $settings ? htmlspecialchars($settings->sidebar_color) : '#343a40';
$font_family = $settings ? htmlspecialchars($settings->font_family) : 'Arial';
$font_size = $settings ? htmlspecialchars($settings->font_size) : '14px';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kampala Traffic Predictor</title>
    
    <link rel="icon" name="text/x-image" href="images/logo1.jpg">
    <!-- Add Font Awesome if not already included -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">


    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    
    
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/custom.css">
    <style>
        body {
            font-family: <?php echo $font_family; ?>;
            font-size: <?php echo $font_size; ?>;
        }
    </style>
</head>
<body>
