<?php
// Start session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once 'config/database.php';

// Get system settings for colors
$settings_query = "SELECT * FROM system_settings LIMIT 1";
$settings_result = mysqli_query($conn, $settings_query);
$settings = mysqli_fetch_object($settings_result);
$sidebar_color = $settings ? htmlspecialchars($settings->sidebar_color) : '#343a40';

$current_page = basename($_SERVER['PHP_SELF']);
$user_role = isset($_SESSION['role']) ? $_SESSION['role'] : '';
$user_name = isset($_SESSION['user_name']) ? $_SESSION['user_name'] : 'User';
$user_id = isset($_SESSION['user_id']) ? $_SESSION['user_id'] : 0;

// Debug - remove after fixing
if ($user_role === 'admin') {
    error_log("Sidebar: Admin user detected - showing all admin links");
} else {
    error_log("Sidebar: User role is '$user_role' - only showing basic links");
}
?>
<!-- Sidebar Menu Icon for Mobile -->
<div class="menu-toggle" id="menuToggle">
    <i class="bi bi-list"></i>
</div>

<!-- Overlay for mobile -->
<div class="sidebar-overlay" id="sidebarOverlay"></div>

<!-- Main Sidebar -->
<div class="sidebar" id="sidebar">
    <!-- System Logo/Name at Top -->
    <div class="sidebar-header">
        <div class="d-flex align-items-center">
            <div class="logo-icon me-2">
                <i class="bi bi-signpost-2-fill fs-2"></i>
            </div>
            <div class="logo-text">
                <h4 class="mb-0">Traffic Predictor</h4>
                <small class="text-white-50">Kampala Traffic System</small>
            </div>
        </div>
        <button class="close-sidebar d-lg-none" id="closeSidebar">
            <i class="bi bi-x-lg"></i>
        </button>
    </div>

    <!-- User Info -->
    <div class="user-info">
        <div class="user-avatar">
            <i class="bi bi-person-circle fs-1"></i>
        </div>
        <div class="user-details">
            <span class="user-name"><?php echo htmlspecialchars($user_name); ?></span>
            <span class="user-role badge bg-light text-dark">
                <?php echo ucfirst($user_role ?: 'Guest'); ?>
                <?php if($user_role === 'admin'): ?>
                    <i class="bi bi-crown text-warning ms-1" style="font-size: 10px;"></i>
                <?php endif; ?>
            </span>
        </div>
    </div>

    <!-- Debug info - Remove after fixing -->
    <?php if($user_role !== 'admin' && $user_id > 0): ?>
    <div style="background: #ffc107; color: #000; padding: 10px; margin: 10px; border-radius: 5px; font-size: 12px;">
        <!--
        <strong>Debug:</strong> Your role is "<?php echo $user_role; ?>". 
        To see admin links, role must be exactly "admin". 
        <a href="test_session.php" target="_blank">Check Session</a>
        -->
    </div>
    <?php endif; ?>

    <!-- Navigation Links - Scrollable Area -->
    <div class="sidebar-nav">
        <ul class="nav-list">
            <!-- Dashboard - Always visible -->
            <li class="nav-item <?php echo $current_page == 'dashboard.php' ? 'active' : ''; ?>">
                <a href="dashboard.php" class="nav-link">
                    <i class="bi bi-speedometer2"></i>
                    <span class="nav-text">Dashboard</span>
                </a>
            </li>

            <!-- Admin Only Links - Using strict comparison -->
            <?php if ($user_role === 'admin'): ?>
                <li class="nav-divider">
                    <span>ADMIN PANEL</span>
                </li>
                
                <li class="nav-item <?php echo $current_page == 'hotspots.php' ? 'active' : ''; ?>">
                    <a href="hotspots.php" class="nav-link">
                        <i class="bi bi-geo-alt-fill"></i>
                        <span class="nav-text">Traffic Hotspots</span>
                    </a>
                </li>
                
                <li class="nav-item <?php echo $current_page == 'traffic_reports.php' ? 'active' : ''; ?>">
                    <a href="traffic_reports.php" class="nav-link">
                        <i class="bi bi-flag-fill"></i>
                        <span class="nav-text">Traffic Reports</span>
                    </a>
                </li>
                
                <li class="nav-item <?php echo $current_page == 'analytics.php' ? 'active' : ''; ?>">
                    <a href="analytics.php" class="nav-link">
                        <i class="bi bi-bar-chart-fill"></i>
                        <span class="nav-text">Analytics</span>
                    </a>
                </li>
                
                <li class="nav-item <?php echo $current_page == 'users.php' ? 'active' : ''; ?>">
                    <a href="users.php" class="nav-link">
                        <i class="bi bi-people-fill"></i>
                        <span class="nav-text">Users Management</span>
                    </a>
                </li>
                
                <li class="nav-item <?php echo $current_page == 'settings.php' ? 'active' : ''; ?>">
                    <a href="settings.php" class="nav-link">
                        <i class="bi bi-gear-fill"></i>
                        <span class="nav-text">System Settings</span>
                    </a>
                </li>
            <?php endif; ?>

            <!-- Common Links for All Users -->
            <li class="nav-divider">
                <span>NAVIGATION</span>
            </li>
            
            <li class="nav-item <?php echo $current_page == 'traffic_map.php' ? 'active' : ''; ?>">
                <a href="traffic_map.php" class="nav-link">
                    <i class="bi bi-map-fill"></i>
                    <span class="nav-text">Traffic Map</span>
                </a>
            </li>
            
            <li class="nav-item <?php echo $current_page == 'predictions.php' ? 'active' : ''; ?>">
                <a href="predictions.php" class="nav-link">
                    <i class="bi bi-robot"></i>
                    <span class="nav-text">AI Predictions</span>
                </a>
            </li>
            
            <li class="nav-item <?php echo $current_page == 'routes.php' ? 'active' : ''; ?>">
                <a href="routes.php" class="nav-link">
                    <i class="bi bi-signpost-split-fill"></i>
                    <span class="nav-text">Route Suggestions</span>
                </a>
            </li>
            
            <li class="nav-item <?php echo $current_page == 'profile.php' ? 'active' : ''; ?>">
                <a href="profile.php" class="nav-link">
                    <i class="bi bi-person-fill"></i>
                    <span class="nav-text">Profile</span>
                </a>
            </li>
        </ul>
    </div>

    <!-- Logout Button at Bottom -->
    <div class="sidebar-footer">
        <a href="logout.php" class="logout-btn">
            <i class="bi bi-box-arrow-right"></i>
            <span>Logout</span>
        </a>
    </div>
</div>

<!-- Add Bootstrap Icons CDN if not already in header -->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">

<style>
:root {
    --sidebar-width: 280px;
    --sidebar-color: <?php echo $sidebar_color; ?>;
}

/* Menu Toggle Button */
.menu-toggle {
    position: fixed;
    top: 15px;
    left: 15px;
    z-index: 1001;
    background: var(--sidebar-color);
    color: white;
    width: 45px;
    height: 45px;
    border-radius: 8px;
    display: none;
    align-items: center;
    justify-content: center;
    cursor: pointer;
    box-shadow: 0 4px 10px rgba(0,0,0,0.2);
    transition: all 0.3s;
}

.menu-toggle:hover {
    transform: scale(1.05);
    box-shadow: 0 6px 15px rgba(0,0,0,0.3);
}

/* Sidebar Overlay */
.sidebar-overlay {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(0,0,0,0.5);
    z-index: 999;
    display: none;
    opacity: 0;
    transition: opacity 0.3s;
}

.sidebar-overlay.active {
    display: block;
    opacity: 1;
}

/* Main Sidebar */
.sidebar {
    position: fixed;
    top: 0;
    left: 0;
    height: 100vh;
    width: var(--sidebar-width);
    background: var(--sidebar-color);
    color: white;
    display: flex;
    flex-direction: column;
    z-index: 1000;
    box-shadow: 4px 0 20px rgba(0,0,0,0.15);
    transition: transform 0.3s ease;
}

/* Sidebar Header */
.sidebar-header {
    padding: 25px 20px;
    background: rgba(0,0,0,0.1);
    border-bottom: 1px solid rgba(255,255,255,0.1);
    display: flex;
    align-items: center;
    justify-content: space-between;
}

.logo-icon {
    width: 45px;
    height: 45px;
    background: rgba(255,255,255,0.2);
    border-radius: 12px;
    display: flex;
    align-items: center;
    justify-content: center;
}

.logo-icon i {
    color: white;
    font-size: 1.8rem;
}

.close-sidebar {
    background: transparent;
    border: none;
    color: white;
    font-size: 1.5rem;
    cursor: pointer;
    display: none;
}

/* User Info */
.user-info {
    padding: 20px;
    background: rgba(255,255,255,0.05);
    border-bottom: 1px solid rgba(255,255,255,0.1);
    display: flex;
    align-items: center;
    gap: 12px;
}

.user-avatar {
    width: 50px;
    height: 50px;
    background: rgba(255,255,255,0.1);
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
}

.user-avatar i {
    color: white;
    font-size: 2.5rem;
}

.user-details {
    display: flex;
    flex-direction: column;
}

.user-name {
    font-weight: 600;
    font-size: 0.95rem;
    margin-bottom: 4px;
    color: white;
}

.user-role {
    font-size: 0.7rem;
    padding: 2px 8px;
    border-radius: 12px;
    align-self: flex-start;
}

/* Navigation Area - Scrollable */
.sidebar-nav {
    flex: 1;
    overflow-y: auto;
    overflow-x: hidden;
    padding: 15px 0;
}

/* Custom Scrollbar */
.sidebar-nav::-webkit-scrollbar {
    width: 5px;
}

.sidebar-nav::-webkit-scrollbar-track {
    background: rgba(255,255,255,0.1);
}

.sidebar-nav::-webkit-scrollbar-thumb {
    background: rgba(255,255,255,0.3);
    border-radius: 10px;
}

.sidebar-nav::-webkit-scrollbar-thumb:hover {
    background: rgba(255,255,255,0.5);
}

.nav-list {
    list-style: none;
    padding: 0;
    margin: 0;
}

.nav-divider {
    padding: 15px 20px 5px;
    font-size: 0.7rem;
    font-weight: 600;
    letter-spacing: 1px;
    color: rgba(255,255,255,0.5);
    text-transform: uppercase;
}

.nav-item {
    margin: 2px 10px;
    border-radius: 8px;
    transition: all 0.3s;
}

.nav-item:hover {
    background: rgba(255,255,255,0.1);
}

.nav-item.active {
    background: rgba(255,255,255,0.2);
    box-shadow: 0 4px 10px rgba(0,0,0,0.1);
}

.nav-link {
    display: flex;
    align-items: center;
    padding: 12px 15px;
    color: rgba(255,255,255,0.8);
    text-decoration: none;
    transition: all 0.3s;
    gap: 12px;
}

.nav-link:hover {
    color: white;
    transform: translateX(5px);
}

.nav-link i {
    width: 24px;
    font-size: 1.2rem;
    text-align: center;
    color: rgba(255,255,255,0.9);
}

.nav-text {
    font-size: 0.9rem;
    font-weight: 500;
}

/* Sidebar Footer */
.sidebar-footer {
    padding: 15px 20px;
    background: rgba(0,0,0,0.2);
    border-top: 1px solid rgba(255,255,255,0.1);
}

.logout-btn {
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 8px;
    padding: 12px;
    background: #dc3545;
    color: white;
    text-decoration: none;
    border-radius: 8px;
    transition: all 0.3s;
    font-size: 0.9rem;
    box-shadow: 0 4px 10px rgba(220, 53, 69, 0.3);
}

.logout-btn:hover {
    background: #c82333;
    transform: translateY(-2px);
    box-shadow: 0 6px 15px rgba(220, 53, 69, 0.4);
    color: white;
}

.logout-btn i {
    font-size: 1.1rem;
}

/* Responsive Design */
@media (max-width: 991px) {
    .menu-toggle {
        display: flex;
    }

    .sidebar {
        transform: translateX(-100%);
    }

    .sidebar.active {
        transform: translateX(0);
    }

    .close-sidebar {
        display: block;
    }
}

/* Bootstrap Icons specific styles */
.bi {
    display: inline-block;
    vertical-align: -0.125em;
    fill: currentColor;
}
</style>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const menuToggle = document.getElementById('menuToggle');
    const sidebar = document.getElementById('sidebar');
    const overlay = document.getElementById('sidebarOverlay');
    const closeBtn = document.getElementById('closeSidebar');

    function openSidebar() {
        sidebar.classList.add('active');
        overlay.classList.add('active');
        document.body.style.overflow = 'hidden';
    }

    function closeSidebar() {
        sidebar.classList.remove('active');
        overlay.classList.remove('active');
        document.body.style.overflow = '';
    }

    if (menuToggle) {
        menuToggle.addEventListener('click', openSidebar);
    }
    
    if (closeBtn) {
        closeBtn.addEventListener('click', closeSidebar);
    }
    
    if (overlay) {
        overlay.addEventListener('click', closeSidebar);
    }

    // Close sidebar on escape key
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape' && sidebar.classList.contains('active')) {
            closeSidebar();
        }
    });

    // Handle window resize
    window.addEventListener('resize', function() {
        if (window.innerWidth > 991 && sidebar.classList.contains('active')) {
            closeSidebar();
        }
    });
});
</script>