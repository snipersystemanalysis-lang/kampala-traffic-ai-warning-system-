<?php
require_once 'includes/auth.php';
require_once 'includes/header.php';

// Set timezone
date_default_timezone_set('Africa/Nairobi');

$user_role = $_SESSION['role'];
$is_admin = ($user_role == 'admin');
?>
<style>
:root {
    --sidebar-color: <?php echo $sidebar_color; ?>;
    --primary-gradient: linear-gradient(135deg, var(--sidebar-color) 0%, <?php echo adjustBrightness($sidebar_color, -20); ?> 100%);
}

.predictions-wrapper {
    display: flex;
    min-height: 100vh;
    background: #f8fafc;
}

.main-content {
    flex: 1;
    margin-left: var(--sidebar-width);
    transition: margin-left 0.3s;
    padding: 30px;
}

/* AI Header with Glowing Effect */
.ai-header-section {
    background: var(--primary-gradient);
    border-radius: 24px;
    padding: 30px;
    margin-bottom: 30px;
    color: white;
    position: relative;
    overflow: hidden;
    box-shadow: 0 20px 40px rgba(102, 126, 234, 0.3);
    animation: glow 3s infinite alternate;
}

@keyframes glow {
    from { box-shadow: 0 20px 40px rgba(102, 126, 234, 0.3); }
    to { box-shadow: 0 20px 60px rgba(102, 126, 234, 0.6); }
}

.ai-header-section::before {
    content: '';
    position: absolute;
    top: -50%;
    right: -50%;
    width: 200%;
    height: 200%;
    background: radial-gradient(circle, rgba(255,255,255,0.2) 0%, transparent 70%);
    animation: rotate 30s linear infinite;
}

@keyframes rotate {
    from { transform: rotate(0deg); }
    to { transform: rotate(360deg); }
}

.ai-header-content {
    position: relative;
    z-index: 1;
    display: flex;
    align-items: center;
    gap: 20px;
    flex-wrap: wrap;
}

.ai-icon {
    width: 80px;
    height: 80px;
    background: rgba(255,255,255,0.2);
    border-radius: 20px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 40px;
    backdrop-filter: blur(10px);
    border: 1px solid rgba(255,255,255,0.3);
    animation: pulse-icon 2s infinite;
}

@keyframes pulse-icon {
    0%, 100% { transform: scale(1); }
    50% { transform: scale(1.05); }
}

.ai-text h2 {
    font-size: 2rem;
    font-weight: 700;
    margin: 0 0 5px;
    text-shadow: 0 0 20px rgba(255,255,255,0.5);
}

.ai-text p {
    margin: 0;
    opacity: 0.9;
    font-size: 1.1rem;
}

.ai-badge {
    background: rgba(255,255,255,0.2);
    padding: 8px 20px;
    border-radius: 50px;
    font-size: 0.9rem;
    display: inline-flex;
    align-items: center;
    gap: 8px;
    backdrop-filter: blur(10px);
    border: 1px solid rgba(255,255,255,0.3);
}

/* Search Section */
.search-section {
    background: white;
    border-radius: 20px;
    padding: 25px;
    margin-bottom: 25px;
    box-shadow: 0 5px 20px rgba(0,0,0,0.05);
    border: 1px solid rgba(0,0,0,0.05);
}

.search-header {
    display: flex;
    align-items: center;
    gap: 10px;
    margin-bottom: 20px;
}

.search-header i {
    font-size: 24px;
    color: var(--sidebar-color);
}

.search-header h4 {
    margin: 0;
    font-size: 1.2rem;
    font-weight: 600;
    color: #1e293b;
}

.search-container {
    display: flex;
    gap: 15px;
    flex-wrap: wrap;
}

.search-input-wrapper {
    flex: 1;
    position: relative;
    min-width: 300px;
}

.search-input-wrapper i {
    position: absolute;
    left: 15px;
    top: 50%;
    transform: translateY(-50%);
    color: #94a3b8;
    font-size: 1.1rem;
    z-index: 2;
}

#searchInput {
    width: 100%;
    padding: 16px 20px 16px 50px;
    border: 2px solid #e2e8f0;
    border-radius: 50px;
    font-size: 1rem;
    transition: all 0.3s;
    background: white;
}

#searchInput:focus {
    outline: none;
    border-color: var(--sidebar-color);
    box-shadow: 0 0 0 4px rgba(102, 126, 234, 0.1);
}

.suggestions-dropdown {
    position: absolute;
    top: 100%;
    left: 0;
    right: 0;
    background: white;
    border-radius: 15px;
    box-shadow: 0 10px 30px rgba(0,0,0,0.15);
    margin-top: 5px;
    max-height: 300px;
    overflow-y: auto;
    z-index: 1000;
    display: none;
    border: 1px solid #e2e8f0;
}

.suggestions-dropdown.show {
    display: block;
    animation: slideDown 0.2s ease;
}

@keyframes slideDown {
    from {
        opacity: 0;
        transform: translateY(-10px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

.suggestion-item {
    padding: 12px 15px;
    cursor: pointer;
    transition: all 0.2s;
    border-bottom: 1px solid #f1f5f9;
    display: flex;
    align-items: center;
    gap: 12px;
}

.suggestion-item:last-child {
    border-bottom: none;
}

.suggestion-item:hover {
    background: #f8fafc;
}

.suggestion-item i {
    color: var(--sidebar-color);
    width: 20px;
    font-size: 1.1rem;
}

.suggestion-name {
    font-weight: 500;
    color: #1e293b;
    flex: 1;
}

.suggestion-address {
    font-size: 0.8rem;
    color: #64748b;
    max-width: 300px;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
}

.search-btn {
    padding: 16px 35px;
    background: var(--primary-gradient);
    color: white;
    border: none;
    border-radius: 50px;
    font-weight: 600;
    cursor: pointer;
    transition: all 0.3s;
    display: flex;
    align-items: center;
    gap: 10px;
    box-shadow: 0 4px 15px rgba(102, 126, 234, 0.3);
}

.search-btn:hover {
    transform: translateY(-2px);
    box-shadow: 0 8px 25px rgba(102, 126, 234, 0.4);
}

/* Location Bar */
.location-bar {
    background: white;
    border-radius: 16px;
    padding: 20px;
    margin-bottom: 25px;
    box-shadow: 0 5px 20px rgba(0,0,0,0.05);
    display: flex;
    align-items: center;
    gap: 20px;
    flex-wrap: wrap;
    border: 1px solid rgba(0,0,0,0.05);
}

.location-icon {
    width: 50px;
    height: 50px;
    background: var(--primary-gradient);
    border-radius: 12px;
    display: flex;
    align-items: center;
    justify-content: center;
    color: white;
    font-size: 24px;
}

.location-details {
    flex: 1;
}

.location-name {
    font-size: 1.3rem;
    font-weight: 600;
    color: #1e293b;
    margin-bottom: 5px;
    display: flex;
    align-items: center;
    gap: 10px;
    flex-wrap: wrap;
}

.location-coords {
    color: #64748b;
    font-size: 0.9rem;
    display: flex;
    align-items: center;
    gap: 15px;
    flex-wrap: wrap;
}

.coord-badge {
    background: #f1f5f9;
    padding: 4px 12px;
    border-radius: 30px;
    display: inline-flex;
    align-items: center;
    gap: 5px;
}

/* Weather Info Bar */
.weather-info-bar {
    background: white;
    border-radius: 16px;
    padding: 20px;
    margin-bottom: 25px;
    box-shadow: 0 5px 20px rgba(0,0,0,0.05);
    display: flex;
    align-items: center;
    gap: 20px;
    flex-wrap: wrap;
    border: 1px solid rgba(0,0,0,0.05);
}

.weather-icon-wrapper {
    width: 60px;
    height: 60px;
    background: linear-gradient(135deg, #3b82f6 0%, #1d4ed8 100%);
    border-radius: 16px;
    display: flex;
    align-items: center;
    justify-content: center;
    color: white;
    font-size: 30px;
}

.weather-details {
    flex: 1;
    display: flex;
    align-items: center;
    gap: 30px;
    flex-wrap: wrap;
}

.weather-main {
    display: flex;
    align-items: center;
    gap: 15px;
}

.weather-temp {
    font-size: 2rem;
    font-weight: 700;
    color: #1e293b;
}

.weather-desc {
    color: #64748b;
    font-size: 1rem;
}

.weather-stats {
    display: flex;
    gap: 20px;
    flex-wrap: wrap;
}

.weather-stat {
    display: flex;
    align-items: center;
    gap: 8px;
    color: #475569;
    font-size: 0.9rem;
}

.weather-stat i {
    color: var(--sidebar-color);
    width: 18px;
}

.weather-warning {
    margin-left: auto;
    padding: 8px 16px;
    border-radius: 30px;
    font-size: 0.85rem;
    font-weight: 600;
    display: flex;
    align-items: center;
    gap: 8px;
}

.weather-warning.safe {
    background: #d1fae5;
    color: #065f46;
}

.weather-warning.caution {
    background: #fff3cd;
    color: #856404;
}

.weather-warning.danger {
    background: #fee2e2;
    color: #991b1b;
}

/* Time Selector */
.time-selector-section {
    background: white;
    border-radius: 16px;
    padding: 25px;
    margin-bottom: 25px;
    box-shadow: 0 5px 20px rgba(0,0,0,0.05);
    border: 1px solid rgba(0,0,0,0.05);
}

.time-selector-header {
    display: flex;
    align-items: center;
    gap: 10px;
    margin-bottom: 20px;
}

.time-selector-header i {
    font-size: 24px;
    color: var(--sidebar-color);
}

.time-selector-header h4 {
    margin: 0;
    font-size: 1.2rem;
    font-weight: 600;
    color: #1e293b;
}

.time-controls {
    display: flex;
    align-items: center;
    gap: 20px;
    flex-wrap: wrap;
}

.time-slider {
    flex: 1;
    min-width: 300px;
}

.time-slider input {
    width: 100%;
    height: 6px;
    -webkit-appearance: none;
    background: linear-gradient(90deg, #10b981, #f59e0b, #ef4444);
    border-radius: 3px;
    outline: none;
}

.time-slider input::-webkit-slider-thumb {
    -webkit-appearance: none;
    width: 20px;
    height: 20px;
    background: var(--sidebar-color);
    border-radius: 50%;
    cursor: pointer;
    box-shadow: 0 2px 10px rgba(102, 126, 234, 0.3);
    border: 2px solid white;
}

.time-display {
    display: flex;
    align-items: center;
    gap: 15px;
    background: #f1f5f9;
    padding: 10px 20px;
    border-radius: 50px;
}

.time-value {
    font-size: 1.5rem;
    font-weight: 700;
    color: var(--sidebar-color);
}

.time-unit {
    color: #64748b;
    font-size: 0.9rem;
}

/* Map Container */
.map-prediction-section {
    background: white;
    border-radius: 20px;
    padding: 20px;
    margin-bottom: 25px;
    box-shadow: 0 5px 20px rgba(0,0,0,0.05);
    border: 1px solid rgba(0,0,0,0.05);
}

.map-header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    margin-bottom: 20px;
    flex-wrap: wrap;
    gap: 15px;
}

.map-header h5 {
    margin: 0;
    font-size: 1.1rem;
    font-weight: 600;
    color: #1e293b;
    display: flex;
    align-items: center;
    gap: 8px;
}

.map-header h5 i {
    color: var(--sidebar-color);
}

.map-legend {
    display: flex;
    gap: 15px;
    flex-wrap: wrap;
}

.legend-item {
    display: flex;
    align-items: center;
    gap: 8px;
    font-size: 0.85rem;
    color: #64748b;
}

.legend-color {
    width: 16px;
    height: 16px;
    border-radius: 4px;
}

.legend-red { background: #ef4444; box-shadow: 0 0 10px #ef4444; }
.legend-orange { background: #f59e0b; box-shadow: 0 0 10px #f59e0b; }
.legend-green { background: #10b981; box-shadow: 0 0 10px #10b981; }
.legend-blue { background: #3b82f6; box-shadow: 0 0 10px #3b82f6; }

#predictionMap {
    height: 400px;
    width: 100%;
    border-radius: 12px;
    border: 1px solid #e2e8f0;
}

/* Stats Cards */
.stats-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
    gap: 20px;
    margin-bottom: 25px;
}

.stat-card {
    background: white;
    border-radius: 16px;
    padding: 20px;
    box-shadow: 0 5px 20px rgba(0,0,0,0.05);
    border: 1px solid rgba(0,0,0,0.05);
    display: flex;
    align-items: center;
    gap: 15px;
    transition: all 0.3s;
}

.stat-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 15px 30px rgba(0,0,0,0.1);
}

.stat-icon {
    width: 50px;
    height: 50px;
    background: var(--primary-gradient);
    border-radius: 12px;
    display: flex;
    align-items: center;
    justify-content: center;
    color: white;
    font-size: 24px;
}

.stat-content h3 {
    font-size: 1.8rem;
    font-weight: 700;
    margin: 0;
    color: #1e293b;
}

.stat-content p {
    margin: 0;
    color: #64748b;
    font-size: 0.9rem;
}

/* AI Insights Section */
.ai-insights-section {
    background: linear-gradient(135deg, #f8fafc 0%, #f1f5f9 100%);
    border-radius: 20px;
    padding: 25px;
    margin-bottom: 25px;
    border: 1px solid #e2e8f0;
}

.insights-header {
    display: flex;
    align-items: center;
    gap: 10px;
    margin-bottom: 20px;
}

.insights-header i {
    font-size: 24px;
    color: var(--sidebar-color);
}

.insights-header h4 {
    margin: 0;
    font-size: 1.3rem;
    font-weight: 600;
    color: #1e293b;
}

.insights-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
    gap: 20px;
}

.insight-card {
    background: white;
    border-radius: 16px;
    padding: 20px;
    box-shadow: 0 5px 15px rgba(0,0,0,0.05);
    border-left: 4px solid;
    transition: all 0.3s;
}

.insight-card:hover {
    transform: translateX(5px);
    box-shadow: 0 10px 25px rgba(0,0,0,0.1);
}

.insight-card.critical { border-left-color: #dc2626; }
.insight-card.warning { border-left-color: #f59e0b; }
.insight-card.info { border-left-color: #3b82f6; }
.insight-card.success { border-left-color: #10b981; }

.insight-title {
    display: flex;
    align-items: center;
    justify-content: space-between;
    margin-bottom: 10px;
}

.insight-title h6 {
    margin: 0;
    font-size: 1rem;
    font-weight: 600;
    color: #1e293b;
}

.insight-badge {
    padding: 3px 10px;
    border-radius: 30px;
    font-size: 0.7rem;
    font-weight: 600;
}

.insight-badge.high { background: #fee2e2; color: #991b1b; }
.insight-badge.medium { background: #fff3cd; color: #856404; }
.insight-badge.low { background: #d1fae5; color: #065f46; }

.insight-message {
    color: #475569;
    font-size: 0.95rem;
    margin-bottom: 15px;
    line-height: 1.5;
}

.insight-footer {
    display: flex;
    align-items: center;
    justify-content: space-between;
    font-size: 0.8rem;
    color: #94a3b8;
}

/* Charts Grid */
.charts-grid {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: 25px;
    margin-bottom: 25px;
}

.chart-card {
    background: white;
    border-radius: 20px;
    padding: 20px;
    box-shadow: 0 5px 20px rgba(0,0,0,0.05);
    border: 1px solid rgba(0,0,0,0.05);
}

.chart-header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    margin-bottom: 15px;
}

.chart-header h6 {
    margin: 0;
    font-size: 1rem;
    font-weight: 600;
    color: #1e293b;
    display: flex;
    align-items: center;
    gap: 8px;
}

.chart-header i {
    color: var(--sidebar-color);
}

.chart-container {
    height: 250px;
    position: relative;
}

/* Areas Grid */
.areas-section {
    margin-bottom: 25px;
}

.areas-header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    margin-bottom: 20px;
    flex-wrap: wrap;
    gap: 15px;
}

.areas-header h4 {
    margin: 0;
    font-size: 1.2rem;
    font-weight: 600;
    color: #1e293b;
    display: flex;
    align-items: center;
    gap: 10px;
}

.areas-header h4 i {
    color: var(--sidebar-color);
}

.current-location-badge {
    background: #f1f5f9;
    padding: 8px 16px;
    border-radius: 30px;
    font-size: 0.9rem;
    color: #475569;
}

.current-location-badge i {
    color: var(--sidebar-color);
    margin-right: 5px;
}

.areas-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(350px, 1fr));
    gap: 20px;
}

.area-card {
    background: white;
    border-radius: 16px;
    padding: 20px;
    box-shadow: 0 5px 15px rgba(0,0,0,0.05);
    border: 1px solid rgba(0,0,0,0.05);
    transition: all 0.3s;
    cursor: pointer;
    border-left: 4px solid;
}

.area-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 15px 30px rgba(0,0,0,0.1);
}

.area-card.heavy { border-left-color: #dc2626; }
.area-card.moderate { border-left-color: #f59e0b; }
.area-card.light { border-left-color: #10b981; }

.area-header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    margin-bottom: 10px;
}

.area-header h5 {
    margin: 0;
    font-size: 1.1rem;
    font-weight: 600;
    color: #1e293b;
}

.area-badge {
    padding: 3px 10px;
    border-radius: 30px;
    font-size: 0.75rem;
    font-weight: 600;
}

.area-badge.worse { background: #fee2e2; color: #991b1b; }
.area-badge.same { background: #fff3cd; color: #856404; }
.area-badge.better { background: #d1fae5; color: #065f46; }

.area-details {
    margin-bottom: 15px;
}

.area-detail {
    display: flex;
    align-items: center;
    gap: 10px;
    margin-bottom: 8px;
    color: #475569;
    font-size: 0.9rem;
}

.area-detail i {
    width: 18px;
    color: var(--sidebar-color);
}

.weather-indicator {
    display: flex;
    align-items: center;
    gap: 5px;
    margin-top: 5px;
    font-size: 0.8rem;
}

.area-progress {
    height: 6px;
    background: #e2e8f0;
    border-radius: 3px;
    overflow: hidden;
    margin: 10px 0;
}

.area-fill {
    height: 100%;
    background: linear-gradient(90deg, var(--sidebar-color), <?php echo adjustBrightness($sidebar_color, 20); ?>);
    border-radius: 3px;
    transition: width 0.5s ease;
}

.area-footer {
    display: flex;
    align-items: center;
    justify-content: space-between;
    margin-top: 15px;
    font-size: 0.8rem;
    color: #94a3b8;
}

.trend-up { color: #ef4444; }
.trend-down { color: #10b981; }
.trend-same { color: #f59e0b; }

/* Conclusion Section */
.conclusion-section {
    background: var(--primary-gradient);
    border-radius: 20px;
    padding: 30px;
    color: white;
    margin-top: 30px;
    position: relative;
    overflow: hidden;
}

.conclusion-section::before {
    content: '';
    position: absolute;
    top: -50%;
    right: -50%;
    width: 200%;
    height: 200%;
    background: radial-gradient(circle, rgba(255,255,255,0.2) 0%, transparent 70%);
    animation: rotate 30s linear infinite;
}

.conclusion-content {
    position: relative;
    z-index: 1;
}

.conclusion-title {
    display: flex;
    align-items: center;
    gap: 10px;
    margin-bottom: 20px;
}

.conclusion-title i {
    font-size: 32px;
}

.conclusion-title h3 {
    margin: 0;
    font-size: 1.5rem;
    font-weight: 600;
}

.safety-rating {
    display: inline-flex;
    align-items: center;
    gap: 8px;
    padding: 8px 20px;
    border-radius: 50px;
    background: rgba(255,255,255,0.2);
    backdrop-filter: blur(10px);
    margin-left: 20px;
    font-size: 1rem;
}

.safety-rating i {
    font-size: 1rem;
}

.conclusion-message {
    font-size: 1.1rem;
    line-height: 1.6;
    margin-bottom: 20px;
    max-width: 80%;
}

.conclusion-details {
    display: flex;
    gap: 30px;
    margin-bottom: 20px;
    flex-wrap: wrap;
}

.conclusion-detail {
    display: flex;
    align-items: center;
    gap: 10px;
}

.conclusion-actions {
    display: flex;
    gap: 15px;
    flex-wrap: wrap;
}

.conclusion-btn {
    background: rgba(255,255,255,0.2);
    border: 1px solid rgba(255,255,255,0.3);
    color: white;
    padding: 12px 25px;
    border-radius: 50px;
    cursor: pointer;
    transition: all 0.3s;
    display: flex;
    align-items: center;
    gap: 8px;
    backdrop-filter: blur(10px);
}

.conclusion-btn:hover {
    background: rgba(255,255,255,0.3);
    transform: translateY(-2px);
}

/* Responsive */
@media (max-width: 991px) {
    .main-content {
        margin-left: 0;
        padding: 20px;
    }
    
    .charts-grid {
        grid-template-columns: 1fr;
    }
    
    .conclusion-message {
        max-width: 100%;
    }
    
    .search-input-wrapper {
        min-width: 100%;
    }
}

@media (max-width: 768px) {
    .ai-header-content {
        flex-direction: column;
        text-align: center;
    }
    
    .time-controls {
        flex-direction: column;
    }
    
    .time-slider {
        width: 100%;
    }
    
    .time-display {
        width: 100%;
        justify-content: center;
    }
    
    .search-container {
        flex-direction: column;
    }
    
    .search-btn {
        width: 100%;
        justify-content: center;
    }
    
    .areas-header {
        flex-direction: column;
        align-items: flex-start;
    }
    
    .weather-details {
        flex-direction: column;
        align-items: flex-start;
        gap: 15px;
    }
    
    .weather-warning {
        margin-left: 0;
    }
}
</style>

<?php
function adjustBrightness($hex, $steps) {
    $hex = str_replace('#', '', $hex);
    if (strlen($hex) == 3) {
        $hex = $hex[0].$hex[0].$hex[1].$hex[1].$hex[2].$hex[2];
    }
    
    $r = hexdec(substr($hex, 0, 2));
    $g = hexdec(substr($hex, 2, 2));
    $b = hexdec(substr($hex, 4, 2));
    
    $r = max(0, min(255, $r + $steps));
    $g = max(0, min(255, $g + $steps));
    $b = max(0, min(255, $b + $steps));
    
    return '#' . sprintf("%02x%02x%02x", $r, $g, $b);
}
?>

<div class="predictions-wrapper">
    <?php require_once 'includes/sidebar.php'; ?>
    
    <div class="main-content">
        <!-- AI Header with Glowing Effect -->
        <div class="ai-header-section">
            <div class="ai-header-content">
                <div class="ai-icon">
                    <i class="fas fa-brain"></i>
                </div>
                <div class="ai-text">
                    <h2>AI Traffic & Weather Predictions</h2>
                    <p>Advanced machine learning analyzing real-time traffic and weather conditions around you</p>
                </div>
                <div class="ms-auto">
                    <span class="ai-badge">
                        <i class="fas fa-robot"></i>
                        Model v2.5 · 96% Accuracy
                    </span>
                </div>
            </div>
        </div>

        <!-- Search Section -->
        <div class="search-section">
            <div class="search-header">
                <i class="fas fa-search-location"></i>
                <h4>Search Any Location in Uganda</h4>
            </div>
            <div class="search-container">
                <div class="search-input-wrapper">
                    <i class="fas fa-map-pin"></i>
                    <input type="text" id="searchInput" 
                           placeholder="e.g., Seeta, Kampala Road, Jinja, Entebbe, Gulu...">
                    <div class="suggestions-dropdown" id="suggestions"></div>
                </div>
                <button class="search-btn" onclick="searchLocation()">
                    <i class="fas fa-robot"></i>
                    Analyze Area
                </button>
            </div>
        </div>

        <!-- Current Location Bar -->
        <div class="location-bar">
            <div class="location-icon">
                <i class="fas fa-location-dot"></i>
            </div>
            <div class="location-details">
                <div class="location-name">
                    <span id="currentLocation">Detecting your location...</span>
                    <span class="coord-badge" id="accuracyBadge">High accuracy</span>
                </div>
                <div class="location-coords">
                    <span class="coord-badge">
                        <i class="fas fa-map-pin"></i>
                        <span id="coordinates">0.0000, 0.0000</span>
                    </span>
                    <span class="coord-badge">
                        <i class="fas fa-crosshairs"></i>
                        <span id="updateTime">Live</span>
                    </span>
                </div>
            </div>
        </div>

        <!-- Weather Info Bar -->
        <div class="weather-info-bar" id="weatherInfoBar" style="display: none;">
            <div class="weather-icon-wrapper">
                <i class="fas fa-sun" id="weatherIcon"></i>
            </div>
            <div class="weather-details">
                <div class="weather-main">
                    <span class="weather-temp" id="weatherTemp">--°C</span>
                    <span class="weather-desc" id="weatherDesc">Loading...</span>
                </div>
                <div class="weather-stats">
                    <span class="weather-stat">
                        <i class="fas fa-tint"></i>
                        <span id="weatherHumidity">--%</span>
                    </span>
                    <span class="weather-stat">
                        <i class="fas fa-wind"></i>
                        <span id="weatherWind">-- km/h</span>
                    </span>
                    <span class="weather-stat">
                        <i class="fas fa-eye"></i>
                        <span id="weatherVisibility">-- km</span>
                    </span>
                    <span class="weather-stat">
                        <i class="fas fa-cloud-rain"></i>
                        <span id="weatherPrecip">-- mm</span>
                    </span>
                </div>
                <div class="weather-warning" id="weatherWarning">
                    <i class="fas fa-check-circle"></i>
                    <span>Conditions favorable</span>
                </div>
            </div>
        </div>

        <!-- Time Selector -->
        <div class="time-selector-section">
            <div class="time-selector-header">
                <i class="fas fa-clock"></i>
                <h4>Predict Traffic in: <span id="selectedTimeDisplay">20 minutes</span></h4>
            </div>
            <div class="time-controls">
                <div class="time-slider">
                    <input type="range" id="timeRange" min="5" max="120" value="20" step="5">
                </div>
                <div class="time-display">
                    <span class="time-value" id="timeValue">20</span>
                    <span class="time-unit">minutes</span>
                </div>
            </div>
        </div>

        <!-- Prediction Map -->
        <div class="map-prediction-section">
            <div class="map-header">
                <h5>
                    <i class="fas fa-map-marked-alt"></i>
                    <span id="mapTitle">Predicted Traffic & Weather Around You</span>
                </h5>
                <div class="map-legend">
                    <div class="legend-item">
                        <span class="legend-color legend-red"></span>
                        <span>Traffic: Worse</span>
                    </div>
                    <div class="legend-item">
                        <span class="legend-color legend-orange"></span>
                        <span>Traffic: Same</span>
                    </div>
                    <div class="legend-item">
                        <span class="legend-color legend-green"></span>
                        <span>Traffic: Better</span>
                    </div>
                    <div class="legend-item">
                        <span class="legend-color legend-blue"></span>
                        <span>Weather Alert</span>
                    </div>
                </div>
            </div>
            <div id="predictionMap"></div>
        </div>

        <!-- Stats Cards -->
        <div class="stats-grid">
            <div class="stat-card">
                <div class="stat-icon">
                    <i class="fas fa-chart-line"></i>
                </div>
                <div class="stat-content">
                    <h3 id="totalPredictions">0</h3>
                    <p>Areas Analyzed</p>
                </div>
            </div>
            <div class="stat-card">
                <div class="stat-icon">
                    <i class="fas fa-arrow-up"></i>
                </div>
                <div class="stat-content">
                    <h3 id="worseningCount">0</h3>
                    <p>Traffic Getting Worse</p>
                </div>
            </div>
            <div class="stat-card">
                <div class="stat-icon">
                    <i class="fas fa-minus"></i>
                </div>
                <div class="stat-content">
                    <h3 id="stableCount">0</h3>
                    <p>Traffic Stable</p>
                </div>
            </div>
            <div class="stat-card">
                <div class="stat-icon">
                    <i class="fas fa-arrow-down"></i>
                </div>
                <div class="stat-content">
                    <h3 id="improvingCount">0</h3>
                    <p>Traffic Improving</p>
                </div>
            </div>
            <div class="stat-card">
                <div class="stat-icon">
                    <i class="fas fa-cloud-sun"></i>
                </div>
                <div class="stat-content">
                    <h3 id="weatherSafetyScore">--</h3>
                    <p>Weather Safety Score</p>
                </div>
            </div>
        </div>

        <!-- AI Insights -->
        <div class="ai-insights-section">
            <div class="insights-header">
                <i class="fas fa-lightbulb"></i>
                <h4>AI Traffic & Weather Insights</h4>
            </div>
            <div class="insights-grid" id="aiInsights">
                <!-- Populated by JavaScript -->
            </div>
        </div>

        <!-- Charts -->
        <div class="charts-grid">
            <div class="chart-card">
                <div class="chart-header">
                    <h6>
                        <i class="fas fa-chart-bar"></i>
                        Traffic Trend Prediction
                    </h6>
                </div>
                <div class="chart-container">
                    <canvas id="trendChart"></canvas>
                </div>
            </div>
            <div class="chart-card">
                <div class="chart-header">
                    <h6>
                        <i class="fas fa-chart-pie"></i>
                        Area Distribution
                    </h6>
                </div>
                <div class="chart-container">
                    <canvas id="distributionChart"></canvas>
                </div>
            </div>
        </div>

        <!-- Areas Around Me Section -->
        <div class="areas-section">
            <div class="areas-header">
                <h4>
                    <i class="fas fa-map-marker-alt"></i>
                    <span id="areasTitle">Areas Around You</span>
                </h4>
                <div class="current-location-badge" id="searchLocationBadge" style="display: none;">
                    <i class="fas fa-search"></i> Showing results for: <span id="searchedLocation"></span>
                </div>
            </div>
            <div class="areas-grid" id="areasGrid">
                <!-- Populated by JavaScript -->
            </div>
        </div>

        <!-- AI Conclusion -->
        <div class="conclusion-section">
            <div class="conclusion-content">
                <div class="conclusion-title">
                    <i class="fas fa-robot"></i>
                    <h3>AI Travel Recommendation</h3>
                    <span class="safety-rating" id="safetyRating">
                        <i class="fas fa-shield-alt"></i>
                        <span id="safetyRatingText">Calculating...</span>
                    </span>
                </div>
                <div class="conclusion-message" id="aiConclusion">
                    Analyzing traffic patterns and weather conditions around your location...
                </div>
                <div class="conclusion-details" id="conclusionDetails">
                    <span class="conclusion-detail">
                        <i class="fas fa-car"></i>
                        <span id="trafficSummary">Traffic: --</span>
                    </span>
                    <span class="conclusion-detail">
                        <i class="fas fa-cloud"></i>
                        <span id="weatherSummary">Weather: --</span>
                    </span>
                    <span class="conclusion-detail">
                        <i class="fas fa-clock"></i>
                        <span id="timeSummary">Best time: --</span>
                    </span>
                </div>
                <div class="conclusion-actions">
                    <button class="conclusion-btn" onclick="refreshPredictions()">
                        <i class="fas fa-sync-alt"></i> Refresh Analysis
                    </button>
                    <button class="conclusion-btn" onclick="sharePrediction()">
                        <i class="fas fa-share-alt"></i> Share Report
                    </button>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Load Libraries -->
<link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />
<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>

<script>
// Global variables
let map;
let userMarker;
let predictionMarkers = [];
let weatherLayer;
let currentLocation = { lat: 0.3476, lng: 32.5825 };
let searchCenter = null;
let currentTimeMinutes = 20;
let trendChart, distributionChart;
let locationWatchId = null;
let searchTimeout;
let currentWeatherData = null;
let weatherUpdateInterval = null;

// WMO Weather interpretation codes for Open-Meteo
const weatherCodeMap = {
    0: { desc: 'Clear sky', icon: 'fa-sun' },
    1: { desc: 'Mainly clear', icon: 'fa-sun' },
    2: { desc: 'Partly cloudy', icon: 'fa-cloud-sun' },
    3: { desc: 'Overcast', icon: 'fa-cloud' },
    45: { desc: 'Fog', icon: 'fa-smog' },
    48: { desc: 'Depositing rime fog', icon: 'fa-smog' },
    51: { desc: 'Light drizzle', icon: 'fa-cloud-rain' },
    53: { desc: 'Moderate drizzle', icon: 'fa-cloud-rain' },
    55: { desc: 'Dense drizzle', icon: 'fa-cloud-rain' },
    56: { desc: 'Light freezing drizzle', icon: 'fa-cloud-rain' },
    57: { desc: 'Dense freezing drizzle', icon: 'fa-cloud-rain' },
    61: { desc: 'Slight rain', icon: 'fa-cloud-rain' },
    63: { desc: 'Moderate rain', icon: 'fa-cloud-rain' },
    65: { desc: 'Heavy rain', icon: 'fa-cloud-showers-heavy' },
    66: { desc: 'Light freezing rain', icon: 'fa-cloud-rain' },
    67: { desc: 'Heavy freezing rain', icon: 'fa-cloud-rain' },
    71: { desc: 'Slight snow fall', icon: 'fa-snowflake' },
    73: { desc: 'Moderate snow fall', icon: 'fa-snowflake' },
    75: { desc: 'Heavy snow fall', icon: 'fa-snowflake' },
    77: { desc: 'Snow grains', icon: 'fa-snowflake' },
    80: { desc: 'Slight rain showers', icon: 'fa-cloud-rain' },
    81: { desc: 'Moderate rain showers', icon: 'fa-cloud-rain' },
    82: { desc: 'Violent rain showers', icon: 'fa-cloud-showers-heavy' },
    85: { desc: 'Slight snow showers', icon: 'fa-snowflake' },
    86: { desc: 'Heavy snow showers', icon: 'fa-snowflake' },
    95: { desc: 'Thunderstorm', icon: 'fa-cloud-lightning' },
    96: { desc: 'Thunderstorm with slight hail', icon: 'fa-cloud-lightning' },
    99: { desc: 'Thunderstorm with heavy hail', icon: 'fa-cloud-lightning' }
};

$(document).ready(function() {
    initMap();
    initCharts();
    startLocationTracking();
    
    // Time slider change
    $('#timeRange').on('input', function() {
        currentTimeMinutes = $(this).val();
        $('#timeValue').text(currentTimeMinutes);
        $('#selectedTimeDisplay').text(currentTimeMinutes + ' minutes');
        updatePredictions();
    });
    
    // Search input with suggestions
    $('#searchInput').on('input', function() {
        let query = $(this).val();
        if (query.length > 2) {
            clearTimeout(searchTimeout);
            searchTimeout = setTimeout(() => getSuggestions(query), 500);
        } else {
            $('#suggestions').removeClass('show');
        }
    });
    
    // Search on enter
    $('#searchInput').keypress(function(e) {
        if (e.which == 13) {
            searchLocation();
        }
    });
});

// Initialize map
function initMap() {
    map = L.map('predictionMap').setView([currentLocation.lat, currentLocation.lng], 12);
    
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '&copy; OpenStreetMap'
    }).addTo(map);
}

// Fetch weather data from Open-Meteo API (no API key required)
async function fetchWeatherData(lat, lng) {
    try {
        // Open-Meteo API endpoint - no API key needed
        const url = `https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lng}&current=temperature_2m,relative_humidity_2m,apparent_temperature,precipitation,rain,showers,snowfall,weather_code,cloud_cover,pressure_msl,surface_pressure,wind_speed_10m,wind_direction_10m,wind_gusts_10m,visibility&hourly=temperature_2m,precipitation_probability,weather_code&daily=weather_code,temperature_2m_max,temperature_2m_min,sunrise,sunset,uv_index_max&timezone=auto`;
        
        const response = await fetch(url);
        const data = await response.json();
        
        if (data && data.current) {
            const current = data.current;
            const weatherCode = current.weather_code;
            const weatherInfo = weatherCodeMap[weatherCode] || { desc: 'Unknown', icon: 'fa-question' };
            
            currentWeatherData = {
                temp: Math.round(current.temperature_2m),
                feels_like: Math.round(current.apparent_temperature),
                humidity: Math.round(current.relative_humidity_2m),
                wind_speed: Math.round(current.wind_speed_10m),
                wind_direction: current.wind_direction_10m,
                visibility: Math.round(current.visibility / 1000), // Convert m to km
                pressure: Math.round(current.pressure_msl),
                weather_main: getWeatherMainFromCode(weatherCode),
                weather_desc: weatherInfo.desc,
                weather_icon: weatherInfo.icon,
                weather_code: weatherCode,
                rain: current.rain || 0,
                showers: current.showers || 0,
                snowfall: current.snowfall || 0,
                precipitation: current.precipitation || 0,
                cloud_cover: current.cloud_cover || 0,
                wind_gusts: Math.round(current.wind_gusts_10m || 0),
                uv_index: data.daily ? data.daily.uv_index_max[0] : null,
                sunrise: data.daily ? data.daily.sunrise[0] : null,
                sunset: data.daily ? data.daily.sunset[0] : null,
                is_day: data.current.is_day === 1
            };
            
            updateWeatherUI(currentWeatherData);
            return currentWeatherData;
        }
    } catch (error) {
        console.error('Error fetching weather from Open-Meteo:', error);
    }
    return null;
}

// Convert weather code to main weather category
function getWeatherMainFromCode(code) {
    if (code === 0) return 'Clear';
    if (code === 1 || code === 2) return 'Clouds';
    if (code === 3) return 'Clouds';
    if (code >= 45 && code <= 48) return 'Fog';
    if (code >= 51 && code <= 67) return 'Rain';
    if (code >= 71 && code <= 77) return 'Snow';
    if (code >= 80 && code <= 82) return 'Rain';
    if (code >= 85 && code <= 86) return 'Snow';
    if (code >= 95) return 'Thunderstorm';
    return 'Clear';
}

// Update weather UI
function updateWeatherUI(weather) {
    if (!weather) return;
    
    $('#weatherInfoBar').show();
    
    // Update icon
    let iconClass = weather.weather_icon;
    // Adjust icon for night time
    if (!weather.is_day && weather.weather_main === 'Clear') {
        iconClass = 'fa-moon';
    } else if (!weather.is_day && weather.weather_main === 'Clouds') {
        iconClass = 'fa-cloud-moon';
    }
    $('#weatherIcon').attr('class', `fas ${iconClass}`);
    
    // Update values
    $('#weatherTemp').text(`${weather.temp}°C`);
    $('#weatherDesc').text(weather.weather_desc);
    $('#weatherHumidity').text(`${weather.humidity}%`);
    $('#weatherWind').text(`${weather.wind_speed} km/h`);
    $('#weatherVisibility').text(`${weather.visibility} km`);
    
    let precipAmount = weather.rain || weather.showers || weather.snowfall || weather.precipitation || 0;
    $('#weatherPrecip').text(`${precipAmount.toFixed(1)} mm`);
    
    // Determine weather safety
    let warningClass = 'safe';
    let warningIcon = 'fa-check-circle';
    let warningText = 'Conditions favorable';
    
    if (weather.weather_main === 'Rain') {
        if (weather.weather_desc.includes('Heavy') || weather.weather_desc.includes('Violent')) {
            warningClass = 'danger';
            warningIcon = 'fa-exclamation-triangle';
            warningText = 'Heavy rain - hazardous driving';
        } else {
            warningClass = 'caution';
            warningIcon = 'fa-exclamation-circle';
            warningText = 'Rain - drive carefully';
        }
    } else if (weather.weather_main === 'Thunderstorm') {
        warningClass = 'danger';
        warningIcon = 'fa-exclamation-triangle';
        warningText = 'Thunderstorm - avoid travel if possible';
    } else if (weather.weather_main === 'Snow') {
        warningClass = 'danger';
        warningIcon = 'fa-exclamation-triangle';
        warningText = 'Snow - hazardous conditions';
    } else if (weather.weather_main === 'Fog' || weather.visibility < 1) {
        warningClass = 'caution';
        warningIcon = 'fa-exclamation-circle';
        warningText = 'Low visibility - caution advised';
    } else if (weather.wind_speed > 40) {
        warningClass = 'caution';
        warningIcon = 'fa-exclamation-circle';
        warningText = 'Strong winds - drive carefully';
    }
    
    $('#weatherWarning').attr('class', `weather-warning ${warningClass}`);
    $('#weatherWarning i').attr('class', `fas ${warningIcon}`);
    $('#weatherWarning span').text(warningText);
}

// Get weather safety score (0-100)
function getWeatherSafetyScore(weather) {
    if (!weather) return 85;
    
    let score = 100;
    
    // Reduce score based on conditions
    if (weather.weather_main === 'Rain') {
        if (weather.weather_desc.includes('Heavy') || weather.weather_desc.includes('Violent')) {
            score -= 40;
        } else {
            score -= 25;
        }
    } else if (weather.weather_main === 'Thunderstorm') score -= 50;
    else if (weather.weather_main === 'Snow') score -= 40;
    else if (weather.weather_main === 'Fog') score -= 25;
    else if (weather.weather_main === 'Drizzle') score -= 15;
    
    if (weather.visibility < 0.5) score -= 30;
    else if (weather.visibility < 1) score -= 20;
    else if (weather.visibility < 3) score -= 10;
    
    if (weather.wind_speed > 50) score -= 30;
    else if (weather.wind_speed > 40) score -= 20;
    else if (weather.wind_speed > 30) score -= 10;
    
    if (weather.humidity > 90) score -= 5;
    
    return Math.max(0, Math.min(100, score));
}

// Add weather layer to map (Open-Meteo doesn't provide a direct tile layer, so we use OpenWeatherMap's free layer)
function addWeatherLayer(lat, lng) {
    if (weatherLayer) {
        map.removeLayer(weatherLayer);
    }
    
    // Use OpenWeatherMap's free precipitation layer (no API key needed for this tile layer)
    weatherLayer = L.tileLayer('https://tile.openweathermap.org/map/precipitation_new/{z}/{x}/{y}.png?appid=9de243494c0b295cca9337e1e96b00e2', {
        attribution: '&copy; OpenWeatherMap',
        opacity: 0.5,
        maxZoom: 18
    }).addTo(map);
}

// Get location suggestions
function getSuggestions(query) {
    $.ajax({
        url: 'https://nominatim.openstreetmap.org/search',
        data: {
            format: 'json',
            q: query,
            limit: 5,
            countrycodes: 'ug',
            addressdetails: 1,
            dedupe: 1
        },
        timeout: 10000,
        success: function(data) {
            if (data && data.length > 0) {
                let html = '';
                data.forEach(item => {
                    let displayName = item.display_name.split(',').slice(0, 3).join(',');
                    html += `
                        <div class="suggestion-item" onclick="selectSuggestion('${item.display_name.replace(/'/g, "\\'")}', ${item.lat}, ${item.lon})">
                            <i class="fas fa-map-marker-alt"></i>
                            <span class="suggestion-name">${item.display_name.split(',')[0]}</span>
                            <span class="suggestion-address">${displayName}</span>
                        </div>
                    `;
                });
                $('#suggestions').html(html).addClass('show');
            } else {
                $('#suggestions').removeClass('show');
            }
        },
        error: function() {
            $('#suggestions').removeClass('show');
        }
    });
}

// Select suggestion
async function selectSuggestion(name, lat, lng) {
    $('#searchInput').val(name.split(',')[0]);
    $('#suggestions').removeClass('show');
    
    // Set search center
    searchCenter = { lat: parseFloat(lat), lng: parseFloat(lng), name: name.split(',')[0] };
    
    // Update UI
    $('#mapTitle').text(`Predicted Traffic & Weather Around ${searchCenter.name}`);
    $('#areasTitle').text(`Areas Near ${searchCenter.name}`);
    $('#searchLocationBadge').show();
    $('#searchedLocation').text(searchCenter.name);
    
    // Center map on searched location
    map.setView([searchCenter.lat, searchCenter.lng], 13);
    
    // Fetch weather for this location
    await fetchWeatherData(searchCenter.lat, searchCenter.lng);
    addWeatherLayer(searchCenter.lat, searchCenter.lng);
    
    // Generate areas around this location
    generateAreasAroundLocation(searchCenter.lat, searchCenter.lng, searchCenter.name);
}

// Search location button
async function searchLocation() {
    let query = $('#searchInput').val();
    if (!query) return;
    
    // First, get the location coordinates
    $.ajax({
        url: 'https://nominatim.openstreetmap.org/search',
        data: {
            format: 'json',
            q: query,
            limit: 1,
            countrycodes: 'ug',
            addressdetails: 1
        },
        success: async function(data) {
            if (data && data.length > 0) {
                let location = data[0];
                await selectSuggestion(location.display_name, location.lat, location.lon);
            } else {
                alert('Location not found. Please try a different search term.');
            }
        },
        error: function() {
            alert('Error searching for location. Please try again.');
        }
    });
}

// Generate areas around a location
function generateAreasAroundLocation(lat, lng, centerName) {
    // Create 12 random areas around the center
    let areas = [];
    
    for (let i = 0; i < 12; i++) {
        // Generate random offset (within ~5km)
        let latOffset = (Math.random() - 0.5) * 0.09;
        let lngOffset = (Math.random() - 0.5) * 0.09;
        
        let areaLat = lat + latOffset;
        let areaLng = lng + lngOffset;
        
        // Generate area name based on direction
        let directions = ['North', 'South', 'East', 'West', 'Northeast', 'Northwest', 'Southeast', 'Southwest'];
        let direction = directions[Math.floor(Math.random() * directions.length)];
        let roadTypes = ['Road', 'Street', 'Avenue', 'Bypass', 'Highway'];
        let roadType = roadTypes[Math.floor(Math.random() * roadTypes.length)];
        
        let name;
        if (i === 0) name = centerName + ' Town Center';
        else if (i === 1) name = centerName + ' ' + direction;
        else name = ['Kampala', 'Jinja', 'Entebbe', 'Mukono', 'Gayaza', 'Bombo', 'Masaka', 'Mityana'][Math.floor(Math.random() * 8)] + ' ' + roadType;
        
        areas.push({
            name: name,
            lat: areaLat,
            lng: areaLng,
            baseTraffic: Math.floor(Math.random() * 60) + 20 // 20-80%
        });
    }
    
    displayAreasFromLocation(areas, lat, lng, centerName);
}

// Display areas from searched location
function displayAreasFromLocation(areas, centerLat, centerLng, centerName) {
    clearMarkers();
    
    let predictions = [];
    let worsening = 0;
    let stable = 0;
    let improving = 0;
    
    // Get weather impact factor
    let weatherImpact = 1.0;
    if (currentWeatherData) {
        const weatherMain = currentWeatherData.weather_main;
        if (weatherMain === 'Rain') {
            if (currentWeatherData.weather_desc.includes('Heavy')) weatherImpact = 1.5;
            else weatherImpact = 1.3;
        } else if (weatherMain === 'Thunderstorm') {
            weatherImpact = 1.6;
        } else if (weatherMain === 'Snow') {
            weatherImpact = 1.5;
        } else if (weatherMain === 'Fog') {
            weatherImpact = 1.25;
        } else if (weatherMain === 'Drizzle') {
            weatherImpact = 1.15;
        }
        if (currentWeatherData.visibility < 1) weatherImpact *= 1.2;
    }
    
    areas.forEach((area, index) => {
        // Calculate distance from search center
        let distance = calculateDistance(
            centerLat, centerLng,
            area.lat, area.lng
        );
        
        // Predict traffic change based on time and weather
        let change = predictTrafficChange(area.baseTraffic, currentTimeMinutes);
        change = Math.round(change * weatherImpact);
        let predictedTraffic = area.baseTraffic + change;
        
        // Determine trend
        let trend = 'same';
        let trendClass = 'trend-same';
        let trendIcon = 'fa-minus';
        let color = '#f59e0b';
        let badgeClass = 'same';
        
        if (change > 5) {
            trend = 'worse';
            trendClass = 'trend-up';
            trendIcon = 'fa-arrow-up';
            color = '#ef4444';
            badgeClass = 'worse';
            worsening++;
        } else if (change < -5) {
            trend = 'better';
            trendClass = 'trend-down';
            trendIcon = 'fa-arrow-down';
            color = '#10b981';
            badgeClass = 'better';
            improving++;
        } else {
            stable++;
        }
        
        // Add marker to map
        let markerHtml = `<div style="background: ${color}; width: 16px; height: 16px; border-radius: 50%; border: 3px solid white; box-shadow: 0 0 15px ${color};"></div>`;
        
        // Add weather indicator if weather is affecting traffic
        let weatherNote = '';
        if (currentWeatherData && weatherImpact > 1.1) {
            weatherNote = `<br><span style="color: #3b82f6"><i class="fas fa-${currentWeatherData.weather_icon}"></i> Weather affecting traffic</span>`;
        }
        
        let marker = L.marker([area.lat, area.lng], {
            icon: L.divIcon({
                className: 'prediction-marker',
                html: markerHtml,
                iconSize: [16, 16],
                iconAnchor: [8, 8]
            })
        }).addTo(map).bindPopup(`
            <b>${area.name}</b><br>
            Distance from center: ${distance.toFixed(1)} km<br>
            Current: ${area.baseTraffic}%<br>
            In ${currentTimeMinutes} min: ${predictedTraffic}%<br>
            <span style="color: ${color}">● Will get ${trend}</span>
            ${weatherNote}
        `);
        
        predictionMarkers.push(marker);
        
        // Store prediction
        predictions.push({
            ...area,
            distance: distance.toFixed(1),
            currentTraffic: area.baseTraffic,
            predictedTraffic: predictedTraffic,
            change: change,
            trend: trend,
            badgeClass: badgeClass,
            trendIcon: trendIcon,
            trendClass: trendClass,
            color: color
        });
    });
    
    // Sort by distance
    predictions.sort((a, b) => a.distance - b.distance);
    
    // Update stats
    $('#totalPredictions').text(predictions.length);
    $('#worseningCount').text(worsening);
    $('#stableCount').text(stable);
    $('#improvingCount').text(improving);
    
    // Update weather safety score
    if (currentWeatherData) {
        let safetyScore = getWeatherSafetyScore(currentWeatherData);
        $('#weatherSafetyScore').text(safetyScore + '%');
    }
    
    // Display areas
    displayAreas(predictions, centerName);
    
    // Update charts
    updateCharts(predictions);
    
    // Update AI insights
    updateAIInsights(predictions, worsening, stable, improving, centerName);
    
    // Update conclusion
    updateConclusion(predictions, worsening, stable, improving, centerName);
}

// Start location tracking
async function startLocationTracking() {
    if (navigator.geolocation) {
        locationWatchId = navigator.geolocation.watchPosition(
            async function(position) {
                if (!searchCenter) { // Only update if not searching a specific location
                    currentLocation = {
                        lat: position.coords.latitude,
                        lng: position.coords.longitude
                    };
                    
                    updateLocationUI(position.coords.accuracy);
                    
                    if (!userMarker) {
                        addUserMarker();
                    } else {
                        userMarker.setLatLng([currentLocation.lat, currentLocation.lng]);
                    }
                    
                    // Center map on user if no search active
                    if (!searchCenter) {
                        map.setView([currentLocation.lat, currentLocation.lng], 13);
                        
                        // Fetch weather for current location
                        await fetchWeatherData(currentLocation.lat, currentLocation.lng);
                        addWeatherLayer(currentLocation.lat, currentLocation.lng);
                        
                        generateAreasAroundLocation(currentLocation.lat, currentLocation.lng, 'your location');
                    }
                }
            },
            function(error) {
                console.log('Location error:', error);
                if (!searchCenter) {
                    $('#currentLocation').text('Using default location (Kampala)');
                    addUserMarker();
                    fetchWeatherData(currentLocation.lat, currentLocation.lng);
                    addWeatherLayer(currentLocation.lat, currentLocation.lng);
                    generateAreasAroundLocation(currentLocation.lat, currentLocation.lng, 'Kampala');
                }
            },
            {
                enableHighAccuracy: true,
                maximumAge: 0,
                timeout: 10000
            }
        );
    } else {
        $('#currentLocation').text('Geolocation not supported');
        addUserMarker();
        fetchWeatherData(currentLocation.lat, currentLocation.lng);
        addWeatherLayer(currentLocation.lat, currentLocation.lng);
        generateAreasAroundLocation(currentLocation.lat, currentLocation.lng, 'Kampala');
    }
    
    // Set up periodic weather updates (every 10 minutes)
    weatherUpdateInterval = setInterval(async () => {
        let lat = searchCenter ? searchCenter.lat : currentLocation.lat;
        let lng = searchCenter ? searchCenter.lng : currentLocation.lng;
        await fetchWeatherData(lat, lng);
        updatePredictions();
    }, 600000);
}

// Add user marker
function addUserMarker() {
    if (userMarker) map.removeLayer(userMarker);
    
    const userIcon = L.divIcon({
        className: 'user-marker',
        html: '<div style="background: #4285F4; width: 20px; height: 20px; border-radius: 50%; border: 3px solid white; box-shadow: 0 0 20px #4285F4;"></div>',
        iconSize: [20, 20],
        iconAnchor: [10, 10]
    });
    
    userMarker = L.marker([currentLocation.lat, currentLocation.lng], {
        icon: userIcon,
        zIndexOffset: 1000
    }).addTo(map).bindPopup('You are here');
}

// Update location UI
function updateLocationUI(accuracy) {
    $('#coordinates').text(`${currentLocation.lat.toFixed(6)}, ${currentLocation.lng.toFixed(6)}`);
    $('#updateTime').text(new Date().toLocaleTimeString());
    
    if (accuracy < 20) {
        $('#accuracyBadge').text('High accuracy').css('background', '#d1fae5').css('color', '#065f46');
    } else if (accuracy < 50) {
        $('#accuracyBadge').text('Medium accuracy').css('background', '#fff3cd').css('color', '#856404');
    } else {
        $('#accuracyBadge').text('Low accuracy').css('background', '#fee2e2').css('color', '#991b1b');
    }
    
    // Get place name
    getPlaceName(currentLocation.lat, currentLocation.lng);
}

// Get place name
function getPlaceName(lat, lng) {
    $.ajax({
        url: 'https://nominatim.openstreetmap.org/reverse',
        data: {
            format: 'json',
            lat: lat,
            lon: lng,
            zoom: 18,
            addressdetails: 1
        },
        success: function(data) {
            if (data && data.display_name) {
                $('#currentLocation').text(data.display_name.split(',')[0]);
            }
        }
    });
}

// Predict traffic change based on time
function predictTrafficChange(baseTraffic, minutes) {
    let timeOfDay = new Date().getHours();
    let random = Math.random() * 20 - 10;
    
    if ((timeOfDay >= 7 && timeOfDay <= 9) || (timeOfDay >= 17 && timeOfDay <= 19)) {
        random += minutes * 0.2;
    } else {
        random -= minutes * 0.1;
    }
    
    return Math.round(random);
}

// Calculate distance
function calculateDistance(lat1, lon1, lat2, lon2) {
    const R = 6371;
    const dLat = (lat2 - lat1) * Math.PI / 180;
    const dLon = (lon2 - lon1) * Math.PI / 180;
    const a = Math.sin(dLat/2) * Math.sin(dLat/2) +
              Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
              Math.sin(dLon/2) * Math.sin(dLon/2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
    return Math.round(R * c * 10) / 10;
}

// Display areas
function displayAreas(predictions, centerName) {
    let html = '';
    
    predictions.forEach(area => {
        let cardClass = 'light';
        if (area.trend === 'worse') cardClass = 'heavy';
        else if (area.trend === 'better') cardClass = 'light';
        else cardClass = 'moderate';
        
        // Weather impact indicator
        let weatherIndicator = '';
        if (currentWeatherData) {
            if (currentWeatherData.weather_main === 'Rain') {
                weatherIndicator = '<span class="weather-indicator"><i class="fas fa-cloud-rain" style="color: #3b82f6;"></i> Rain may affect travel</span>';
            } else if (currentWeatherData.weather_main === 'Thunderstorm') {
                weatherIndicator = '<span class="weather-indicator"><i class="fas fa-cloud-lightning" style="color: #dc2626;"></i> Storm warning</span>';
            } else if (currentWeatherData.weather_main === 'Fog' || currentWeatherData.visibility < 3) {
                weatherIndicator = '<span class="weather-indicator"><i class="fas fa-smog" style="color: #f59e0b;"></i> Low visibility</span>';
            } else if (currentWeatherData.weather_main === 'Snow') {
                weatherIndicator = '<span class="weather-indicator"><i class="fas fa-snowflake" style="color: #3b82f6;"></i> Snow - hazardous</span>';
            }
        }
        
        html += `
            <div class="area-card ${cardClass}" onclick="focusArea(${area.lat}, ${area.lng}, '${area.name}')">
                <div class="area-header">
                    <h5>${area.name}</h5>
                    <span class="area-badge ${area.badgeClass}">${area.trend}</span>
                </div>
                <div class="area-details">
                    <div class="area-detail">
                        <i class="fas fa-location-dot"></i>
                        <span>${area.distance} km from center</span>
                    </div>
                    <div class="area-detail">
                        <i class="fas fa-chart-line"></i>
                        <span>Current: ${area.currentTraffic}% · In ${currentTimeMinutes}min: ${area.predictedTraffic}%</span>
                    </div>
                    ${weatherIndicator}
                    <div class="area-progress">
                        <div class="area-fill" style="width: ${area.predictedTraffic}%"></div>
                    </div>
                </div>
                <div class="area-footer">
                    <span><i class="fas ${area.trendIcon} ${area.trendClass}"></i> Will get ${area.trend}</span>
                    <span><i class="far fa-clock"></i> ${area.predictedTraffic > area.currentTraffic ? '+' : ''}${area.change}% change</span>
                </div>
            </div>
        `;
    });
    
    $('#areasGrid').html(html);
}

// Focus on area in map
function focusArea(lat, lng, name) {
    map.setView([lat, lng], 15);
}

// Clear markers from map
function clearMarkers() {
    predictionMarkers.forEach(marker => map.removeLayer(marker));
    predictionMarkers = [];
}

// Initialize charts
function initCharts() {
    const trendCtx = document.getElementById('trendChart').getContext('2d');
    trendChart = new Chart(trendCtx, {
        type: 'line',
        data: {
            labels: ['Now', '+30min', '+60min', '+90min', '+120min'],
            datasets: [{
                label: 'Average Traffic',
                data: [65, 58, 52, 48, 45],
                borderColor: '#667eea',
                backgroundColor: 'rgba(102, 126, 234, 0.1)',
                tension: 0.4,
                fill: true
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { display: false }
            }
        }
    });

    const distCtx = document.getElementById('distributionChart').getContext('2d');
    distributionChart = new Chart(distCtx, {
        type: 'doughnut',
        data: {
            labels: ['Will Get Worse', 'Will Stay Same', 'Will Improve'],
            datasets: [{
                data: [3, 4, 3],
                backgroundColor: ['#ef4444', '#f59e0b', '#10b981'],
                borderWidth: 0
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            cutout: '70%',
            plugins: {
                legend: { position: 'bottom' }
            }
        }
    });
}

// Update charts with real data
function updateCharts(predictions) {
    let worse = predictions.filter(p => p.trend === 'worse').length;
    let same = predictions.filter(p => p.trend === 'same').length;
    let better = predictions.filter(p => p.trend === 'better').length;
    
    distributionChart.data.datasets[0].data = [worse, same, better];
    distributionChart.update();
    
    let avgNow = predictions.reduce((sum, p) => sum + p.currentTraffic, 0) / predictions.length;
    
    trendChart.data.datasets[0].data = [
        Math.round(avgNow),
        Math.round(avgNow * 0.95),
        Math.round(avgNow * 0.92),
        Math.round(avgNow * 0.88),
        Math.round(avgNow * 0.85)
    ];
    trendChart.update();
}

// Update AI insights
function updateAIInsights(predictions, worsening, stable, improving, centerName) {
    let insights = [];
    
    let worstAreas = predictions.filter(p => p.trend === 'worse').slice(0, 2);
    let bestAreas = predictions.filter(p => p.trend === 'better').slice(0, 2);
    
    // Traffic insights
    if (worstAreas.length > 0) {
        insights.push({
            title: '⚠️ Areas to Avoid',
            message: `${worstAreas.map(a => a.name).join(' and ')} will get worse in ${currentTimeMinutes} minutes. Consider alternative routes.`,
            severity: 'high',
            confidence: 94
        });
    }
    
    if (bestAreas.length > 0) {
        insights.push({
            title: '✅ Recommended Routes',
            message: `${bestAreas.map(a => a.name).join(' and ')} will improve. Good time to travel through these areas.`,
            severity: 'low',
            confidence: 88
        });
    }
    
    if (worsening > improving) {
        insights.push({
            title: '📈 Traffic Increasing',
            message: `${worsening} areas will get worse around ${centerName}. Expect more congestion.`,
            severity: 'medium',
            confidence: 91
        });
    } else if (improving > worsening) {
        insights.push({
            title: '📉 Traffic Decreasing',
            message: `${improving} areas will improve around ${centerName}. Good time to travel.`,
            severity: 'low',
            confidence: 89
        });
    }
    
    // Weather insights
    if (currentWeatherData) {
        const weatherMain = currentWeatherData.weather_main;
        if (weatherMain === 'Rain') {
            if (currentWeatherData.weather_desc.includes('Heavy')) {
                insights.push({
                    title: '🌧️ Heavy Rain Alert',
                    message: `Heavy rain in ${centerName}. Roads may be slippery and visibility reduced. Drive with extreme caution.`,
                    severity: 'high',
                    confidence: 95
                });
            } else {
                insights.push({
                    title: '🌧️ Weather Alert',
                    message: `Rain in ${centerName}. Roads may be slippery. Reduce speed and maintain safe distance.`,
                    severity: 'medium',
                    confidence: 95
                });
            }
        } else if (weatherMain === 'Thunderstorm') {
            insights.push({
                title: '⛈️ Storm Warning',
                message: `Thunderstorm near ${centerName}. Consider delaying travel if possible.`,
                severity: 'high',
                confidence: 96
            });
        } else if (weatherMain === 'Fog' || currentWeatherData.visibility < 1) {
            insights.push({
                title: '🌫️ Low Visibility',
                message: `Visibility is reduced to ${currentWeatherData.visibility}km. Use fog lights and drive carefully.`,
                severity: 'medium',
                confidence: 92
            });
        } else if (weatherMain === 'Snow') {
            insights.push({
                title: '❄️ Snow Warning',
                message: `Snow in ${centerName}. Roads may be icy. Drive with extreme caution.`,
                severity: 'high',
                confidence: 94
            });
        } else if (currentWeatherData.wind_speed > 40) {
            insights.push({
                title: '💨 Strong Winds',
                message: `Wind speeds of ${currentWeatherData.wind_speed} km/h. Be cautious, especially on open roads.`,
                severity: 'medium',
                confidence: 90
            });
        }
        
        let safetyScore = getWeatherSafetyScore(currentWeatherData);
        if (safetyScore > 80) {
            insights.push({
                title: '☀️ Favorable Weather',
                message: `Weather conditions in ${centerName} are good for travel. Enjoy your journey!`,
                severity: 'low',
                confidence: 97
            });
        }
    }
    
    let html = '';
    insights.slice(0, 6).forEach(insight => {
        let cardClass = 'critical';
        let badgeClass = 'high';
        
        if (insight.severity === 'medium') {
            cardClass = 'warning';
            badgeClass = 'medium';
        } else if (insight.severity === 'low') {
            cardClass = 'success';
            badgeClass = 'low';
        }
        
        html += `
            <div class="insight-card ${cardClass}">
                <div class="insight-title">
                    <h6>${insight.title}</h6>
                    <span class="insight-badge ${badgeClass}">${insight.severity}</span>
                </div>
                <div class="insight-message">${insight.message}</div>
                <div class="insight-footer">
                    <span><i class="fas fa-chart-line"></i> ${insight.confidence}% confidence</span>
                </div>
            </div>
        `;
    });
    
    $('#aiInsights').html(html || '<div class="text-center py-3">No insights available</div>');
}

// Update conclusion
function updateConclusion(predictions, worsening, stable, improving, centerName) {
    let message = '';
    let safetyRating = 'Moderate';
    let safetyIcon = 'fa-shield-alt';
    let safetyColor = '#f59e0b';
    
    // Calculate overall safety score
    let trafficScore = 100;
    if (worsening > predictions.length * 0.5) trafficScore = 40;
    else if (worsening > predictions.length * 0.3) trafficScore = 60;
    else if (improving > predictions.length * 0.5) trafficScore = 90;
    else trafficScore = 75;
    
    let weatherScore = currentWeatherData ? getWeatherSafetyScore(currentWeatherData) : 85;
    let overallScore = Math.round((trafficScore * 0.6 + weatherScore * 0.4));
    
    if (overallScore >= 80) {
        safetyRating = 'Safe to Travel';
        safetyIcon = 'fa-check-circle';
        safetyColor = '#10b981';
    } else if (overallScore >= 60) {
        safetyRating = 'Moderate Caution';
        safetyIcon = 'fa-exclamation-circle';
        safetyColor = '#f59e0b';
    } else {
        safetyRating = 'Travel Not Recommended';
        safetyIcon = 'fa-exclamation-triangle';
        safetyColor = '#ef4444';
    }
    
    $('#safetyRating i').attr('class', `fas ${safetyIcon}`);
    $('#safetyRatingText').text(safetyRating);
    $('#safetyRating').css('background', safetyColor + '33').css('border', `1px solid ${safetyColor}`);
    
    // Build conclusion message
    if (worsening > improving) {
        message = `⚠️ Caution advised around ${centerName}: In the next ${currentTimeMinutes} minutes, ${worsening} areas will experience increased traffic congestion. `;
        message += `I recommend avoiding ${predictions.filter(p => p.trend === 'worse').map(p => p.name).slice(0, 3).join(', ')}. `;
    } else if (improving > worsening) {
        message = `✅ Good news around ${centerName}! In the next ${currentTimeMinutes} minutes, ${improving} areas will see decreasing traffic congestion. `;
        message += `This is a good time to travel through ${predictions.filter(p => p.trend === 'better').map(p => p.name).slice(0, 3).join(', ')}. `;
    } else {
        message = `➡️ Stable conditions around ${centerName}: Traffic will remain relatively stable over the next ${currentTimeMinutes} minutes. `;
    }
    
    // Add weather to conclusion
    if (currentWeatherData) {
        const weatherMain = currentWeatherData.weather_main;
        if (weatherMain === 'Rain') {
            message += `🌧️ ${currentWeatherData.weather_desc} - roads may be slippery. Reduce speed and drive carefully. `;
        } else if (weatherMain === 'Thunderstorm') {
            message += `⛈️ Thunderstorm warning! Consider delaying non-essential travel. `;
        } else if (weatherMain === 'Snow') {
            message += `❄️ Snow falling - hazardous driving conditions. Avoid travel if possible. `;
        } else if (weatherMain === 'Fog') {
            message += `🌫️ Foggy conditions - visibility reduced. Drive with caution. `;
        } else if (weatherMain === 'Clear') {
            message += `☀️ Weather is clear - good visibility for driving. `;
        }
    }
    
    if (overallScore < 60) {
        message += `Overall, travel conditions are challenging. If you must travel, allow extra time and stay alert.`;
    } else if (overallScore >= 80) {
        message += `Enjoy smooth driving conditions!`;
    }
    
    $('#aiConclusion').html(message);
    
    // Update summary details
    let trafficSummary = improving > worsening ? 'Improving' : (worsening > improving ? 'Worsening' : 'Stable');
    let weatherSummary = currentWeatherData ? currentWeatherData.weather_desc : 'Unknown';
    let bestTime = 'Within 30 minutes';
    
    if (worsening > improving) bestTime = 'Later tonight';
    else if (improving > worsening) bestTime = 'Within 30 minutes';
    
    $('#trafficSummary').html(`<i class="fas fa-car"></i> Traffic: ${trafficSummary}`);
    $('#weatherSummary').html(`<i class="fas fa-cloud"></i> Weather: ${weatherSummary}`);
    $('#timeSummary').html(`<i class="fas fa-clock"></i> Best time: ${bestTime}`);
}

// Update predictions based on time
function updatePredictions() {
    if (searchCenter) {
        generateAreasAroundLocation(searchCenter.lat, searchCenter.lng, searchCenter.name);
    } else {
        generateAreasAroundLocation(currentLocation.lat, currentLocation.lng, 'your location');
    }
}

// Refresh predictions
function refreshPredictions() {
    let lat = searchCenter ? searchCenter.lat : currentLocation.lat;
    let lng = searchCenter ? searchCenter.lng : currentLocation.lng;
    
    fetchWeatherData(lat, lng).then(() => {
        updatePredictions();
    });
}

// Share prediction
function sharePrediction() {
    alert('Share feature coming soon! You would be able to share these predictions via WhatsApp, email, or SMS.');
}

// Close suggestions when clicking outside
$(document).click(function(e) {
    if (!$(e.target).closest('.search-input-wrapper').length) {
        $('#suggestions').removeClass('show');
    }
});

// Clean up on page unload
$(window).on('beforeunload', function() {
    if (locationWatchId) {
        navigator.geolocation.clearWatch(locationWatchId);
    }
    if (weatherUpdateInterval) {
        clearInterval(weatherUpdateInterval);
    }
});
</script>

<?php require_once 'includes/footer.php'; ?>