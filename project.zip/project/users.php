<?php
require_once 'includes/admin_auth.php';
require_once 'includes/header.php';

// Set timezone
date_default_timezone_set('Africa/Nairobi');

$user_role = $_SESSION['role'];
?>
<style>
:root {
    --sidebar-color: <?php echo $sidebar_color; ?>;
    --primary-gradient: linear-gradient(135deg, var(--sidebar-color) 0%, <?php echo adjustBrightness($sidebar_color, -20); ?> 100%);
}

.users-wrapper {
    display: flex;
    min-height: 100vh;
    background: #f8fafc;
}

.main-content {
    flex: 1;
    margin-left: var(--sidebar-width);
    transition: margin-left 0.3s;
    padding: 30px;
}

/* Stats Cards */
.stats-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    gap: 20px;
    margin-bottom: 25px;
}

.stat-card {
    background: white;
    border-radius: 16px;
    padding: 20px;
    box-shadow: 0 5px 20px rgba(0,0,0,0.05);
    border: 1px solid rgba(0,0,0,0.05);
    display: flex;
    align-items: center;
    gap: 15px;
    transition: all 0.3s;
}

.stat-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 15px 30px rgba(0,0,0,0.1);
}

.stat-icon {
    width: 50px;
    height: 50px;
    background: var(--primary-gradient);
    border-radius: 12px;
    display: flex;
    align-items: center;
    justify-content: center;
    color: white;
    font-size: 24px;
}

.stat-content h3 {
    font-size: 1.8rem;
    font-weight: 700;
    margin: 0;
    color: #1e293b;
}

.stat-content p {
    margin: 0;
    color: #64748b;
    font-size: 0.9rem;
}

/* Filter Section */
.filter-section {
    background: white;
    border-radius: 20px;
    padding: 20px;
    margin-bottom: 25px;
    box-shadow: 0 5px 20px rgba(0,0,0,0.05);
    display: flex;
    align-items: center;
    justify-content: space-between;
    flex-wrap: wrap;
    gap: 15px;
}

.filter-tabs {
    display: flex;
    gap: 10px;
    flex-wrap: wrap;
}

.filter-tab {
    padding: 8px 16px;
    border: 1px solid #e2e8f0;
    background: white;
    border-radius: 30px;
    font-size: 0.9rem;
    cursor: pointer;
    transition: all 0.3s;
    color: #475569;
    display: flex;
    align-items: center;
    gap: 5px;
}

.filter-tab:hover {
    background: #f8fafc;
    border-color: var(--sidebar-color);
    color: var(--sidebar-color);
}

.filter-tab.active {
    background: var(--primary-gradient);
    color: white;
    border-color: var(--sidebar-color);
}

.filter-tab i {
    font-size: 0.9rem;
}

.search-box {
    position: relative;
    min-width: 250px;
}

.search-box i {
    position: absolute;
    left: 12px;
    top: 50%;
    transform: translateY(-50%);
    color: #94a3b8;
}

.search-box input {
    width: 100%;
    padding: 10px 15px 10px 40px;
    border: 2px solid #e2e8f0;
    border-radius: 30px;
    font-size: 0.9rem;
    transition: all 0.3s;
}

.search-box input:focus {
    outline: none;
    border-color: var(--sidebar-color);
    box-shadow: 0 0 0 4px rgba(102, 126, 234, 0.1);
}

/* Users Table Container */
.users-table-container {
    background: white;
    border-radius: 20px;
    box-shadow: 0 10px 40px rgba(0,0,0,0.08);
    overflow: hidden;
    margin-bottom: 25px;
}

.table-header {
    padding: 20px 25px;
    border-bottom: 1px solid #eef2f6;
    display: flex;
    align-items: center;
    justify-content: space-between;
    flex-wrap: wrap;
    gap: 15px;
}

.table-header h4 {
    margin: 0;
    font-size: 1.2rem;
    font-weight: 600;
    color: #1e293b;
    display: flex;
    align-items: center;
    gap: 10px;
}

.table-header h4 i {
    color: var(--sidebar-color);
}

.btn-add-user {
    background: var(--primary-gradient);
    color: white;
    border: none;
    padding: 10px 20px;
    border-radius: 30px;
    font-weight: 600;
    transition: all 0.3s;
}

.btn-add-user:hover {
    transform: translateY(-2px);
    box-shadow: 0 5px 15px rgba(102, 126, 234, 0.4);
    color: white;
}

.table-responsive {
    padding: 0 25px;
    overflow-x: auto;
}

.table {
    width: 100%;
    border-collapse: collapse;
}

.table th {
    background: #f8fafc;
    padding: 15px 12px;
    font-size: 0.85rem;
    font-weight: 600;
    color: #475569;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    border-bottom: 2px solid #e2e8f0;
}

.table td {
    padding: 15px 12px;
    border-bottom: 1px solid #eef2f6;
    color: #1e293b;
    vertical-align: middle;
}

.table tbody tr:hover {
    background: #f8fafc;
}

/* Pagination */
.pagination-container {
    padding: 20px 25px;
    border-top: 1px solid #eef2f6;
    display: flex;
    align-items: center;
    justify-content: space-between;
    flex-wrap: wrap;
    gap: 15px;
}

.pagination-info {
    color: #64748b;
    font-size: 0.9rem;
}

.pagination-buttons {
    display: flex;
    gap: 8px;
    flex-wrap: wrap;
}

.pagination-btn {
    padding: 8px 14px;
    border: 1px solid #e2e8f0;
    background: white;
    border-radius: 8px;
    cursor: pointer;
    transition: all 0.3s;
    color: #475569;
}

.pagination-btn:hover {
    background: #f8fafc;
    border-color: var(--sidebar-color);
    color: var(--sidebar-color);
}

.pagination-btn.active {
    background: var(--primary-gradient);
    color: white;
    border-color: var(--sidebar-color);
}

.pagination-btn.disabled {
    opacity: 0.5;
    cursor: not-allowed;
}

/* Status Badges */
.status-badge {
    padding: 5px 12px;
    border-radius: 30px;
    font-size: 0.8rem;
    font-weight: 600;
    display: inline-block;
}

.status-active {
    background: #d1fae5;
    color: #065f46;
}

.status-suspended {
    background: #fee2e2;
    color: #991b1b;
}

.status-pending {
    background: #fff3cd;
    color: #856404;
}

/* Role Badges */
.role-badge {
    padding: 5px 12px;
    border-radius: 30px;
    font-size: 0.8rem;
    font-weight: 600;
    display: inline-block;
}

.role-admin {
    background: #dbeafe;
    color: #1e40af;
}

.role-user {
    background: #e9d5ff;
    color: #6b21a8;
}

/* Action Buttons */
.action-btn {
    padding: 8px 12px;
    border-radius: 8px;
    border: none;
    cursor: pointer;
    transition: all 0.3s;
    margin: 0 3px;
    font-size: 0.85rem;
    display: inline-flex;
    align-items: center;
    gap: 5px;
}

.action-btn.view {
    background: #dbeafe;
    color: #1e40af;
}

.action-btn.view:hover {
    background: #1e40af;
    color: white;
}

.action-btn.edit {
    background: #d1fae5;
    color: #065f46;
}

.action-btn.edit:hover {
    background: #065f46;
    color: white;
}

.action-btn.suspend {
    background: #fee2e2;
    color: #991b1b;
}

.action-btn.suspend:hover {
    background: #991b1b;
    color: white;
}

.action-btn.activate {
    background: #d1fae5;
    color: #065f46;
}

.action-btn.activate:hover {
    background: #065f46;
    color: white;
}

.action-btn.delete {
    background: #fee2e2;
    color: #991b1b;
}

.action-btn.delete:hover {
    background: #991b1b;
    color: white;
}

.action-btn.logs {
    background: #fff3cd;
    color: #856404;
}

.action-btn.logs:hover {
    background: #856404;
    color: white;
}

/* Activity Section */
.activity-section {
    margin-top: 25px;
}

.section-header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    margin-bottom: 20px;
}

.section-header h4 {
    margin: 0;
    font-size: 1.2rem;
    font-weight: 600;
    color: #1e293b;
    display: flex;
    align-items: center;
    gap: 10px;
}

.section-header h4 i {
    color: var(--sidebar-color);
}

.section-header .badge {
    padding: 5px 12px;
    border-radius: 30px;
    font-size: 0.8rem;
}

.activity-grid {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: 20px;
}

.activity-card {
    background: white;
    border-radius: 16px;
    padding: 20px;
    box-shadow: 0 5px 20px rgba(0,0,0,0.05);
    border: 1px solid rgba(0,0,0,0.05);
}

.activity-card h5 {
    margin: 0 0 15px 0;
    font-size: 1rem;
    font-weight: 600;
    color: #1e293b;
    display: flex;
    align-items: center;
    gap: 8px;
}

.activity-card h5 i {
    color: var(--sidebar-color);
}

.activity-list {
    max-height: 300px;
    overflow-y: auto;
}

.activity-item {
    display: flex;
    align-items: center;
    gap: 10px;
    padding: 10px 0;
    border-bottom: 1px solid #eef2f6;
}

.activity-item:last-child {
    border-bottom: none;
}

.activity-avatar {
    width: 32px;
    height: 32px;
    background: var(--primary-gradient);
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    color: white;
    font-size: 14px;
}

.activity-details {
    flex: 1;
}

.activity-title {
    font-weight: 500;
    color: #1e293b;
    margin-bottom: 2px;
}

.activity-meta {
    font-size: 0.75rem;
    color: #64748b;
    display: flex;
    align-items: center;
    gap: 10px;
}

.activity-time {
    display: flex;
    align-items: center;
    gap: 3px;
}

/* Logs Section */
.logs-section {
    margin-top: 25px;
}

.logs-list {
    background: white;
    border-radius: 16px;
    padding: 20px;
    box-shadow: 0 5px 20px rgba(0,0,0,0.05);
    border: 1px solid rgba(0,0,0,0.05);
    max-height: 400px;
    overflow-y: auto;
}

.log-item {
    display: flex;
    align-items: center;
    gap: 15px;
    padding: 12px;
    border-bottom: 1px solid #eef2f6;
}

.log-item:last-child {
    border-bottom: none;
}

.log-icon {
    width: 36px;
    height: 36px;
    background: #f1f5f9;
    border-radius: 10px;
    display: flex;
    align-items: center;
    justify-content: center;
    color: var(--sidebar-color);
    font-size: 1.1rem;
}

.log-content {
    flex: 1;
}

.log-message {
    font-weight: 500;
    color: #1e293b;
    margin-bottom: 3px;
}

.log-details {
    font-size: 0.75rem;
    color: #64748b;
    display: flex;
    align-items: center;
    gap: 15px;
}

.log-type {
    padding: 2px 8px;
    border-radius: 30px;
    font-size: 0.7rem;
    font-weight: 600;
}

.log-type.info { background: #dbeafe; color: #1e40af; }
.log-type.warning { background: #fff3cd; color: #856404; }
.log-type.error { background: #fee2e2; color: #991b1b; }
.log-type.success { background: #d1fae5; color: #065f46; }

/* Modal Styles */
.modal-content {
    border-radius: 20px;
    border: none;
    box-shadow: 0 20px 60px rgba(0,0,0,0.3);
}

.modal-header {
    background: var(--primary-gradient);
    color: white;
    border-radius: 20px 20px 0 0;
    padding: 20px 25px;
    border: none;
}

.modal-header .btn-close {
    filter: brightness(0) invert(1);
}

.modal-body {
    padding: 25px;
}

.modal-footer {
    padding: 15px 25px;
    border-top: 1px solid #eef2f6;
}

/* Toast Notifications */
.toast-notification {
    position: fixed;
    top: 20px;
    right: 20px;
    z-index: 9999;
    min-width: 300px;
    background: white;
    border-radius: 12px;
    box-shadow: 0 10px 30px rgba(0,0,0,0.2);
    overflow: hidden;
    animation: slideIn 0.3s ease;
}

@keyframes slideIn {
    from {
        transform: translateX(100%);
        opacity: 0;
    }
    to {
        transform: translateX(0);
        opacity: 1;
    }
}

.toast-header {
    padding: 12px 15px;
    color: white;
    font-weight: 600;
}

.toast-header.success { background: #10b981; }
.toast-header.error { background: #ef4444; }
.toast-header.warning { background: #f59e0b; }
.toast-header.info { background: var(--sidebar-color); }

.toast-body {
    padding: 15px;
    color: #1e293b;
}

/* Responsive */
@media (max-width: 991px) {
    .main-content {
        margin-left: 0;
        padding: 20px;
    }
    
    .activity-grid {
        grid-template-columns: 1fr;
    }
}

@media (max-width: 768px) {
    .filter-section {
        flex-direction: column;
        align-items: flex-start;
    }
    
    .search-box {
        width: 100%;
    }
    
    .table-header {
        flex-direction: column;
        align-items: flex-start;
    }
    
    .pagination-container {
        flex-direction: column;
        align-items: center;
    }
}
</style>

<?php
function adjustBrightness($hex, $steps) {
    $hex = str_replace('#', '', $hex);
    if (strlen($hex) == 3) {
        $hex = $hex[0].$hex[0].$hex[1].$hex[1].$hex[2].$hex[2];
    }
    
    $r = hexdec(substr($hex, 0, 2));
    $g = hexdec(substr($hex, 2, 2));
    $b = hexdec(substr($hex, 4, 2));
    
    $r = max(0, min(255, $r + $steps));
    $g = max(0, min(255, $g + $steps));
    $b = max(0, min(255, $b + $steps));
    
    return '#' . sprintf("%02x%02x%02x", $r, $g, $b);
}
?>

<div class="users-wrapper">
    <?php require_once 'includes/sidebar.php'; ?>
    
    <div class="main-content">
        <!-- Stats Cards -->
        <div class="stats-grid">
            <div class="stat-card">
                <div class="stat-icon">
                    <i class="bi bi-people-fill"></i>
                </div>
                <div class="stat-content">
                    <h3 id="totalUsers">0</h3>
                    <p>Total Users</p>
                </div>
            </div>
            <div class="stat-card">
                <div class="stat-icon">
                    <i class="bi bi-person-check-fill"></i>
                </div>
                <div class="stat-content">
                    <h3 id="activeUsers">0</h3>
                    <p>Active</p>
                </div>
            </div>
            <div class="stat-card">
                <div class="stat-icon">
                    <i class="bi bi-person-slash"></i>
                </div>
                <div class="stat-content">
                    <h3 id="suspendedUsers">0</h3>
                    <p>Suspended</p>
                </div>
            </div>
            <div class="stat-card">
                <div class="stat-icon">
                    <i class="bi bi-person-plus-fill"></i>
                </div>
                <div class="stat-content">
                    <h3 id="newToday">0</h3>
                    <p>New Today</p>
                </div>
            </div>
        </div>

        <!-- Filter Section -->
        <div class="filter-section">
            <div class="filter-tabs">
                <button class="filter-tab active" data-filter="all">
                    <i class="bi bi-people"></i> All Users
                </button>
                <button class="filter-tab" data-filter="active">
                    <i class="bi bi-person-check"></i> Active
                </button>
                <button class="filter-tab" data-filter="suspended">
                    <i class="bi bi-person-slash"></i> Suspended
                </button>
                <button class="filter-tab" data-filter="pending">
                    <i class="bi bi-clock"></i> Pending
                </button>
                <button class="filter-tab" data-filter="admins">
                    <i class="bi bi-shield-shaded"></i> Admins
                </button>
            </div>
            <div class="search-box">
                <i class="bi bi-search"></i>
                <input type="text" id="searchInput" placeholder="Search by name or email...">
            </div>
        </div>

        <!-- Users Table -->
        <div class="users-table-container">
            <div class="table-header">
                <h4>
                    <i class="bi bi-table"></i>
                    User Management
                </h4>
                <div>
                    <button class="btn-add-user" id="addUserBtn">
                        <i class="bi bi-person-plus-fill"></i> Add New User
                    </button>
                    <button class="btn-add-user" style="background: #64748b; margin-left: 10px;" onclick="exportUsers()">
                        <i class="bi bi-download"></i> Export
                    </button>
                </div>
            </div>
            <div class="table-responsive">
                <table class="table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>User</th>
                            <th>Contact</th>
                            <th>Role</th>
                            <th>Status</th>
                            <th>Last Login</th>
                            <th>Registered</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody id="usersTable">
                        <tr>
                            <td colspan="8" class="text-center py-4">
                                <div class="spinner-border text-primary" role="status">
                                    <span class="visually-hidden">Loading...</span>
                                </div>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
            <div class="pagination-container" id="paginationContainer">
                <div class="pagination-info" id="paginationInfo">Showing 0 to 0 of 0 entries</div>
                <div class="pagination-buttons" id="paginationButtons"></div>
            </div>
        </div>

        <!-- Activity Section -->
        <div class="activity-section">
            <div class="section-header">
                <h4>
                    <i class="bi bi-graph-up"></i>
                    User Activity
                </h4>
                <span class="badge bg-primary" id="activityCount">0 active</span>
            </div>
            <div class="activity-grid">
                <div class="activity-card">
                    <h5><i class="bi bi-trophy-fill" style="color: #fbbf24;"></i> Most Active Users</h5>
                    <div class="activity-list" id="mostActiveList">
                        <div class="text-center py-3"><div class="spinner-border spinner-border-sm text-primary"></div></div>
                    </div>
                </div>
                <div class="activity-card">
                    <h5><i class="bi bi-clock"></i> Least Active</h5>
                    <div class="activity-list" id="leastActiveList">
                        <div class="text-center py-3"><div class="spinner-border spinner-border-sm text-primary"></div></div>
                    </div>
                </div>
            </div>
        </div>

        <!-- System Logs -->
        <div class="logs-section">
            <div class="section-header">
                <h4><i class="bi bi-clock-history"></i> System Logs</h4>
                <button class="btn btn-sm btn-outline-secondary" onclick="refreshLogs()">
                    <i class="bi bi-arrow-clockwise"></i> Refresh
                </button>
            </div>
            <div class="logs-list" id="systemLogs">
                <div class="text-center py-4"><div class="spinner-border text-primary"></div></div>
            </div>
        </div>
    </div>
</div>

<!-- Add User Modal -->
<div class="modal fade" id="addUserModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title"><i class="bi bi-person-plus-fill me-2"></i> Add New User</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <form id="addUserForm">
                    <div class="mb-3">
                        <label class="form-label">Full Name *</label>
                        <input type="text" class="form-control" name="fullname" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Email *</label>
                        <input type="email" class="form-control" name="email" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Password *</label>
                        <input type="password" class="form-control" name="password" required>
                        <small class="text-muted">Minimum 6 characters</small>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Role *</label>
                        <select class="form-select" name="role">
                            <option value="user">User (Regular)</option>
                            <option value="admin">Admin</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Status</label>
                        <select class="form-select" name="status">
                            <option value="active">Active</option>
                            <option value="pending">Pending (Email verification required)</option>
                            <option value="suspended">Suspended</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <!--
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" name="send_email" value="1" checked>
                            <label class="form-check-label">Send welcome email with login credentials</label>
                        </div>
                        -->
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                <button type="submit" form="addUserForm" class="btn" style="background: var(--sidebar-color); color: white;">
                    <i class="bi bi-check-lg"></i> Create User
                </button>
            </div>
        </div>
    </div>
</div>

<!-- View User Modal -->
<div class="modal fade" id="viewUserModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title"><i class="bi bi-person-circle me-2"></i> User Details</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body" id="userDetails"></div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>

<!-- Edit User Modal -->
<div class="modal fade" id="editUserModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title"><i class="bi bi-pencil-square me-2"></i> Edit User</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <form id="editUserForm">
                    <input type="hidden" id="editUserId" name="id">
                    <div class="mb-3">
                        <label class="form-label">Full Name</label>
                        <input type="text" class="form-control" id="editFullname" name="fullname" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Email</label>
                        <input type="email" class="form-control" id="editEmail" name="email" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Role</label>
                        <select class="form-select" id="editRole" name="role">
                            <option value="user">User</option>
                            <option value="admin">Admin</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Status</label>
                        <select class="form-select" id="editStatus" name="status">
                            <option value="active">Active</option>
                            <option value="suspended">Suspended</option>
                            <option value="pending">Pending</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">New Password (leave blank to keep current)</label>
                        <input type="password" class="form-control" name="new_password" placeholder="Enter new password to change">
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                <button type="submit" form="editUserForm" class="btn" style="background: var(--sidebar-color); color: white;">
                    <i class="bi bi-save"></i> Save Changes
                </button>
            </div>
        </div>
    </div>
</div>

<!-- Suspend User Modal -->
<div class="modal fade" id="suspendUserModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header bg-warning text-white">
                <h5 class="modal-title"><i class="bi bi-exclamation-triangle-fill me-2"></i> Suspend User</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <p>Are you sure you want to suspend <strong id="suspendUserName"></strong>?</p>
                <form id="suspendUserForm">
                    <input type="hidden" id="suspendUserId" name="id">
                    <div class="mb-3">
                        <label class="form-label">Reason for suspension</label>
                        <textarea class="form-control" name="reason" rows="2" required></textarea>
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                <button type="submit" form="suspendUserForm" class="btn btn-warning">
                    <i class="bi bi-person-slash"></i> Suspend User
                </button>
            </div>
        </div>
    </div>
</div>

<!-- Activate User Modal -->
<div class="modal fade" id="activateUserModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header bg-success text-white">
                <h5 class="modal-title"><i class="bi bi-check-circle-fill me-2"></i> Activate User</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <p>Are you sure you want to activate <strong id="activateUserName"></strong>?</p>
                <form id="activateUserForm">
                    <input type="hidden" id="activateUserId" name="id">
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                <button type="submit" form="activateUserForm" class="btn btn-success">
                    <i class="bi bi-person-check"></i> Activate User
                </button>
            </div>
        </div>
    </div>
</div>

<!-- Delete User Modal -->
<div class="modal fade" id="deleteUserModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header bg-danger text-white">
                <h5 class="modal-title"><i class="bi bi-trash-fill me-2"></i> Delete User</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <p>Are you sure you want to delete <strong id="deleteUserName"></strong>?</p>
                <p class="text-danger small"><i class="bi bi-exclamation-triangle-fill"></i> This action cannot be undone.</p>
                <form id="deleteUserForm">
                    <input type="hidden" id="deleteUserId" name="id">
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                <button type="submit" form="deleteUserForm" class="btn btn-danger">
                    <i class="bi bi-trash"></i> Delete User
                </button>
            </div>
        </div>
    </div>
</div>

<!-- User Logs Modal -->
<div class="modal fade" id="userLogsModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title"><i class="bi bi-clock-history me-2"></i> <span id="logsUserName"></span> - Activity Logs</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <div class="logs-list" id="userLogsList" style="max-height: 400px;"></div>
            </div>
        </div>
    </div>
</div>

<!-- Load Bootstrap Icons -->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">

<script>
let currentFilter = 'all';
let searchTerm = '';
let currentPage = 1;
let totalPages = 1;
let itemsPerPage = 10;

$(document).ready(function() {
    loadAllData();
    setupEventListeners();
    
    setInterval(loadAllData, 30000);
});

function setupEventListeners() {
    $('.filter-tab').click(function() {
        $('.filter-tab').removeClass('active');
        $(this).addClass('active');
        currentFilter = $(this).data('filter');
        currentPage = 1;
        loadAllData();
    });
    
    $('#searchInput').on('keyup', function() {
        searchTerm = $(this).val();
        currentPage = 1;
        loadAllData();
    });
    
    $('#addUserBtn').click(function() {
        $('#addUserForm')[0].reset();
        $('#addUserModal').modal('show');
    });
    
    $('#addUserForm').on('submit', function(e) {
        e.preventDefault();
        addUser();
    });
    
    $('#editUserForm').on('submit', function(e) {
        e.preventDefault();
        editUser();
    });
    
    $('#suspendUserForm').on('submit', function(e) {
        e.preventDefault();
        suspendUser();
    });
    
    $('#activateUserForm').on('submit', function(e) {
        e.preventDefault();
        activateUser();
    });
    
    $('#deleteUserForm').on('submit', function(e) {
        e.preventDefault();
        deleteUser();
    });
}

function loadAllData() {
    $.ajax({
        url: 'api/users_api.php',
        type: 'POST',
        data: {
            action: 'getAllData',
            filter: currentFilter,
            search: searchTerm,
            page: currentPage,
            limit: itemsPerPage
        },
        dataType: 'json',
        success: function(response) {
            if (response.success) {
                displayUsers(response.data.users);
                updateStats(response.data.stats);
                updatePagination(response.data.pagination);
                displayMostActive(response.data.most_active);
                displayLeastActive(response.data.least_active);
                displaySystemLogs(response.data.system_logs);
            } else {
                showNotification('Error loading data', 'error');
            }
        },
        error: function() {
            showNotification('Connection error. Please refresh the page.', 'error');
        }
    });
}

function displayUsers(users) {
    let html = '';
    
    if (!users || users.length === 0) {
        html = '<tr><td colspan="8" class="text-center py-4">No users found</td></tr>';
    } else {
        users.forEach(function(user) {
            let statusClass = user.status === 'active' ? 'status-active' : (user.status === 'suspended' ? 'status-suspended' : 'status-pending');
            let statusText = user.status === 'active' ? 'Active' : (user.status === 'suspended' ? 'Suspended' : 'Pending');
            let roleClass = user.role === 'admin' ? 'role-admin' : 'role-user';
            let lastLogin = user.last_login ? new Date(user.last_login).toLocaleString() : 'Never';
            let registered = new Date(user.created_at).toLocaleDateString();
            
            html += '<tr>';
            html += '<td><span class="fw-bold">#' + user.id + '</span></td>';
            html += '<td><div class="d-flex align-items-center gap-2"><div class="activity-avatar" style="width: 32px; height: 32px;">' + (user.fullname ? user.fullname.charAt(0) : '?') + '</div><div><strong>' + escapeHtml(user.fullname || 'Unknown') + '</strong></div></div></td>';
            html += '<td>' + escapeHtml(user.email || 'N/A') + '</td>';
            html += '<td><span class="role-badge ' + roleClass + '">' + (user.role || 'user') + '</span></td>';
            html += '<td><span class="status-badge ' + statusClass + '">' + statusText + '</span></td>';
            html += '<td><small>' + lastLogin + '</small></td>';
            html += '<td><small>' + registered + '</small></td>';
            html += '<td>';
            html += '<button class="action-btn view" onclick="viewUser(' + user.id + ')" title="View"><i class="bi bi-eye"></i></button>';
            html += '<button class="action-btn edit" onclick="editUser(' + user.id + ')" title="Edit"><i class="bi bi-pencil"></i></button>';
            
            if (user.status === 'active') {
                html += '<button class="action-btn suspend" onclick="showSuspendModal(' + user.id + ', \'' + escapeHtml(user.fullname || '').replace(/'/g, "\\'") + '\')" title="Suspend"><i class="bi bi-person-slash"></i></button>';
            } else if (user.status === 'suspended') {
                html += '<button class="action-btn activate" onclick="showActivateModal(' + user.id + ', \'' + escapeHtml(user.fullname || '').replace(/'/g, "\\'") + '\')" title="Activate"><i class="bi bi-person-check"></i></button>';
            }
            
            html += '<button class="action-btn logs" onclick="viewUserLogs(' + user.id + ', \'' + escapeHtml(user.fullname || '').replace(/'/g, "\\'") + '\')" title="Logs"><i class="bi bi-clock-history"></i></button>';
            html += '<button class="action-btn delete" onclick="showDeleteModal(' + user.id + ', \'' + escapeHtml(user.fullname || '').replace(/'/g, "\\'") + '\')" title="Delete"><i class="bi bi-trash"></i></button>';
            html += '</td>';
            html += '</tr>';
        });
    }
    
    $('#usersTable').html(html);
}

function updatePagination(pagination) {
    if (pagination) {
        totalPages = pagination.total_pages;
        currentPage = pagination.current_page;
        
        let start = (pagination.current_page - 1) * pagination.per_page + 1;
        let end = Math.min(pagination.current_page * pagination.per_page, pagination.total);
        
        $('#paginationInfo').text(`Showing ${start} to ${end} of ${pagination.total} entries`);
        
        let buttons = '';
        buttons += `<button class="pagination-btn ${pagination.current_page === 1 ? 'disabled' : ''}" onclick="changePage(${pagination.current_page - 1})" ${pagination.current_page === 1 ? 'disabled' : ''}><i class="bi bi-chevron-left"></i></button>`;
        
        for (let i = 1; i <= pagination.total_pages; i++) {
            if (i === 1 || i === pagination.total_pages || (i >= pagination.current_page - 2 && i <= pagination.current_page + 2)) {
                buttons += `<button class="pagination-btn ${i === pagination.current_page ? 'active' : ''}" onclick="changePage(${i})">${i}</button>`;
            } else if (i === pagination.current_page - 3 || i === pagination.current_page + 3) {
                buttons += `<button class="pagination-btn disabled" disabled>...</button>`;
            }
        }
        
        buttons += `<button class="pagination-btn ${pagination.current_page === pagination.total_pages ? 'disabled' : ''}" onclick="changePage(${pagination.current_page + 1})" ${pagination.current_page === pagination.total_pages ? 'disabled' : ''}><i class="bi bi-chevron-right"></i></button>`;
        
        $('#paginationButtons').html(buttons);
    }
}

function changePage(page) {
    if (page >= 1 && page <= totalPages) {
        currentPage = page;
        loadAllData();
    }
}

function updateStats(stats) {
    if (stats) {
        $('#totalUsers').text(stats.total || 0);
        $('#activeUsers').text(stats.active || 0);
        $('#suspendedUsers').text(stats.suspended || 0);
        $('#newToday').text(stats.new_today || 0);
        $('#activityCount').text((stats.active_today || 0) + ' active today');
    }
}

function displayMostActive(users) {
    if (!users) return;
    let html = '';
    users.forEach((user, index) => {
        let medal = index === 0 ? '🥇' : (index === 1 ? '🥈' : '🥉');
        html += `<div class="activity-item"><div class="activity-avatar">${user.fullname ? user.fullname.charAt(0) : '?'}</div><div class="activity-details"><div class="activity-title">${medal} ${escapeHtml(user.fullname || 'Unknown')}</div><div class="activity-meta"><span><i class="bi bi-graph-up"></i> ${user.activity_count || 0} actions</span><span class="activity-time"><i class="bi bi-clock"></i> Last: ${user.last_action || 'Never'}</span></div></div></div>`;
    });
    $('#mostActiveList').html(html || '<p class="text-muted text-center py-3">No activity data</p>');
}

function displayLeastActive(users) {
    if (!users) return;
    let html = '';
    users.forEach(user => {
        html += `<div class="activity-item"><div class="activity-avatar">${user.fullname ? user.fullname.charAt(0) : '?'}</div><div class="activity-details"><div class="activity-title">${escapeHtml(user.fullname || 'Unknown')}</div><div class="activity-meta"><span><i class="bi bi-graph-up"></i> ${user.activity_count || 0} actions</span><span class="activity-time"><i class="bi bi-clock"></i> Last: ${user.last_action || 'Never'}</span></div></div></div>`;
    });
    $('#leastActiveList').html(html || '<p class="text-muted text-center py-3">No inactive users</p>');
}

function displaySystemLogs(logs) {
    if (!logs) return;
    let html = '';
    if (logs.length === 0) {
        html = '<p class="text-muted text-center py-3">No logs found</p>';
    } else {
        logs.forEach(log => {
            let icon = log.log_type === 'warning' ? 'exclamation-triangle' : (log.log_type === 'error' ? 'x-circle' : (log.log_type === 'success' ? 'check-circle' : 'info-circle'));
            let typeClass = log.log_type || 'info';
            html += `<div class="log-item"><div class="log-icon"><i class="bi bi-${icon}"></i></div><div class="log-content"><div class="log-message">${escapeHtml(log.message || '')}</div><div class="log-details"><span class="log-type ${typeClass}">${log.log_type || 'info'}</span><span><i class="bi bi-person"></i> ${log.created_by || 'System'}</span><span><i class="bi bi-clock"></i> ${log.created_at || ''}</span></div></div></div>`;
        });
    }
    $('#systemLogs').html(html);
}

function addUser() {
    let formData = $('#addUserForm').serialize();
    
    $.ajax({
        url: 'api/users_api.php',
        type: 'POST',
        data: formData + '&action=addUser',
        dataType: 'json',
        success: function(response) {
            if (response.success) {
                $('#addUserModal').modal('hide');
                loadAllData();
                showNotification(response.message, 'success');
            } else {
                showNotification(response.message, 'error');
            }
        },
        error: function() {
            showNotification('Error adding user', 'error');
        }
    });
}

function viewUser(id) {
    $.ajax({
        url: 'api/users_api.php',
        type: 'POST',
        data: { action: 'getUserDetails', id: id },
        dataType: 'json',
        success: function(response) {
            if (response.success) {
                let user = response.data;
                let html = `<div class="text-center mb-3"><div class="activity-avatar mx-auto" style="width: 60px; height: 60px; font-size: 24px;">${user.fullname ? user.fullname.charAt(0) : '?'}</div><h5 class="mt-2">${escapeHtml(user.fullname || 'Unknown')}</h5></div>
                <table class="table table-sm"><tr><th>ID:</th><td>#${user.id}</td></tr><tr><th>Email:</th><td>${escapeHtml(user.email || 'N/A')}</td></tr>
                <tr><th>Role:</th><td><span class="role-badge ${user.role === 'admin' ? 'role-admin' : 'role-user'}">${user.role || 'user'}</span></td></tr>
                <tr><th>Status:</th><td><span class="status-badge status-${user.status || 'pending'}">${user.status || 'pending'}</span></td></tr>
                <tr><th>Email Verified:</th><td>${user.email_verified ? '<span class="text-success"><i class="bi bi-check-circle-fill"></i> Yes</span>' : '<span class="text-danger"><i class="bi bi-x-circle-fill"></i> No</span>'}</td></tr>
                <tr><th>Last Login:</th><td>${user.last_login || 'Never'}</td></tr><tr><th>Last IP:</th><td>${user.last_ip || 'N/A'}</td></tr>
                <tr><th>Registered:</th><td>${user.created_at || 'N/A'}</td></tr><tr><th>Activity Count:</th><td>${user.activity_count || 0} actions</td></tr></table>`;
                $('#userDetails').html(html);
                $('#viewUserModal').modal('show');
            } else {
                showNotification('Error loading user details', 'error');
            }
        }
    });
}

function editUser(id) {
    $.ajax({
        url: 'api/users_api.php',
        type: 'POST',
        data: { action: 'getUserDetails', id: id },
        dataType: 'json',
        success: function(response) {
            if (response.success) {
                let user = response.data;
                $('#editUserId').val(user.id);
                $('#editFullname').val(user.fullname || '');
                $('#editEmail').val(user.email || '');
                $('#editRole').val(user.role || 'user');
                $('#editStatus').val(user.status || 'pending');
                $('#editUserModal').modal('show');
            }
        }
    });
}

function editUserSubmit() {
    let formData = $('#editUserForm').serialize();
    
    $.ajax({
        url: 'api/users_api.php',
        type: 'POST',
        data: formData + '&action=editUser',
        dataType: 'json',
        success: function(response) {
            if (response.success) {
                $('#editUserModal').modal('hide');
                loadAllData();
                showNotification(response.message, 'success');
            } else {
                showNotification(response.message, 'error');
            }
        }
    });
}

function showSuspendModal(id, name) {
    $('#suspendUserId').val(id);
    $('#suspendUserName').text(name);
    $('#suspendUserModal').modal('show');
}

function suspendUser() {
    let formData = $('#suspendUserForm').serialize();
    
    $.ajax({
        url: 'api/users_api.php',
        type: 'POST',
        data: formData + '&action=suspendUser',
        dataType: 'json',
        success: function(response) {
            if (response.success) {
                $('#suspendUserModal').modal('hide');
                loadAllData();
                showNotification(response.message, 'warning');
            } else {
                showNotification(response.message, 'error');
            }
        }
    });
}

function showActivateModal(id, name) {
    $('#activateUserId').val(id);
    $('#activateUserName').text(name);
    $('#activateUserModal').modal('show');
}

function activateUser() {
    $.ajax({
        url: 'api/users_api.php',
        type: 'POST',
        data: { action: 'activateUser', id: $('#activateUserId').val() },
        dataType: 'json',
        success: function(response) {
            if (response.success) {
                $('#activateUserModal').modal('hide');
                loadAllData();
                showNotification(response.message, 'success');
            } else {
                showNotification(response.message, 'error');
            }
        }
    });
}

function showDeleteModal(id, name) {
    $('#deleteUserId').val(id);
    $('#deleteUserName').text(name);
    $('#deleteUserModal').modal('show');
}

function deleteUser() {
    $.ajax({
        url: 'api/users_api.php',
        type: 'POST',
        data: { action: 'deleteUser', id: $('#deleteUserId').val() },
        dataType: 'json',
        success: function(response) {
            if (response.success) {
                $('#deleteUserModal').modal('hide');
                loadAllData();
                showNotification(response.message, 'danger');
            } else {
                showNotification(response.message, 'error');
            }
        }
    });
}

function viewUserLogs(id, name) {
    $('#logsUserName').text(name);
    
    $.ajax({
        url: 'api/users_api.php',
        type: 'POST',
        data: { action: 'getUserLogs', id: id },
        dataType: 'json',
        success: function(response) {
            if (response.success) {
                let html = '';
                if (response.data.length === 0) {
                    html = '<p class="text-muted text-center py-3">No activity logs found</p>';
                } else {
                    response.data.forEach(log => {
                        let icon = log.action === 'login' ? 'box-arrow-in-right' : (log.action === 'logout' ? 'box-arrow-right' : 'gear');
                        html += `<div class="log-item"><div class="log-icon"><i class="bi bi-${icon}"></i></div><div class="log-content"><div class="log-message">${log.action || 'action'} - ${log.details || 'No details'}</div><div class="log-details"><span><i class="bi bi-clock"></i> ${log.created_at || ''}</span><span><i class="bi bi-globe"></i> ${log.ip_address || 'N/A'}</span></div></div></div>`;
                    });
                }
                $('#userLogsList').html(html);
                $('#userLogsModal').modal('show');
            }
        }
    });
}

function exportUsers() {
    window.location.href = 'api/users_api.php?action=export';
}

function refreshLogs() {
    loadAllData();
}

function showNotification(message, type) {
    let toast = $(`
        <div class="toast-notification">
            <div class="toast-header ${type}">
                <i class="bi bi-${type === 'success' ? 'check-circle' : (type === 'error' ? 'x-circle' : 'info-circle')} me-2"></i>
                ${type.charAt(0).toUpperCase() + type.slice(1)}
            </div>
            <div class="toast-body">${escapeHtml(message)}</div>
        </div>
    `);
    
    $('body').append(toast);
    
    setTimeout(() => {
        toast.fadeOut(300, function() { $(this).remove(); });
    }, 3000);
}

function escapeHtml(text) {
    if (!text) return '';
    let div = document.createElement('div');
    div.appendChild(document.createTextNode(text));
    return div.innerHTML;
}
</script>

<?php require_once 'includes/footer.php'; ?>