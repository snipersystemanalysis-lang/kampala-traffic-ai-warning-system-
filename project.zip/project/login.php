<?php
session_start();
require_once 'config/database.php';
require_once 'includes/header.php';

if (isset($_SESSION['user_id'])) {
    header("Location: dashboard.php");
    exit();
}

// Function to get user IP address
function getUserIP() {
    if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
        return $_SERVER['HTTP_CLIENT_IP'];
    } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        return $_SERVER['HTTP_X_FORWARDED_FOR'];
    } else {
        return $_SERVER['REMOTE_ADDR'];
    }
}

// Fetch system settings for colors
$settings_query = "SELECT * FROM system_settings LIMIT 1";
$settings_result = mysqli_query($conn, $settings_query);
$settings = mysqli_fetch_object($settings_result);

$sidebar_color = $settings ? htmlspecialchars($settings->sidebar_color) : '#4361ee';
$font_family = $settings ? htmlspecialchars($settings->font_family) : 'Inter, sans-serif';
$font_size = $settings ? htmlspecialchars($settings->font_size) : '16px';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover">
    <title>Sign In | Kampala Traffic Predictor</title>
    <!-- Bootstrap 5 CSS + Icons -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:opsz,wght@14..32,300;14..32,400;14..32,500;14..32,600;14..32,700&display=swap" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        html, body {
            height: 100%;
            overflow: hidden;
            font-family: 'Inter', sans-serif;
        }

        body {
            overflow: hidden;
            position: fixed;
            width: 100%;
            height: 100%;
        }

        /* Main container - fixed viewport */
        .login-container {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            width: 100%;
            height: 100vh;
            overflow: hidden;
        }

        .row-full {
            height: 100vh;
            margin: 0;
            overflow: hidden;
        }

        /* Left Panel - Image Background + Gradient Overlay (hidden on mobile) */
        .hero-panel {
            position: relative;
            background-image: url('images/logo.jpg');
            background-size: cover;
            background-position: center center;
            background-repeat: no-repeat;
            height: 100vh;
            overflow-y: auto;
            overflow-x: hidden;
        }

        .hero-overlay {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: linear-gradient(135deg, <?php echo $sidebar_color; ?>cc 0%, <?php echo $sidebar_color; ?> 100%);
            backdrop-filter: brightness(0.92);
        }

        .hero-content {
            position: relative;
            z-index: 2;
            height: 100%;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            text-align: center;
            padding: 2rem;
            color: white;
            overflow-y: auto;
        }

        /* Right Panel - Form with internal scroll */
        .form-panel {
            height: 100vh;
            background: linear-gradient(135deg, #f8fafc 0%, #f1f5f9 100%);
            overflow-y: auto;
            overflow-x: hidden;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 1.5rem;
        }

        /* Form card styling */
        .form-card {
            background: white;
            border-radius: 2rem;
            padding: 2rem 2rem;
            box-shadow: 0 25px 45px -12px rgba(0,0,0,0.15);
            width: 100%;
            max-width: 460px;
            margin: auto;
        }

        /* Mobile logo container - only visible on small screens */
        .mobile-logo-container {
            display: none;
            text-align: center;
            margin-bottom: 1.5rem;
        }

        .mobile-logo {
            width: 80px;
            height: 80px;
            object-fit: cover;
            border-radius: 50%;
            box-shadow: 0 10px 25px -5px rgba(0,0,0,0.1);
            border: 3px solid white;
        }

        /* Input group styling */
        .input-group-custom {
            border: 1px solid #e2e8f0;
            border-radius: 1rem;
            transition: all 0.2s;
            background: white;
        }

        .input-group-custom:focus-within {
            border-color: <?php echo $sidebar_color; ?>;
            box-shadow: 0 0 0 3px <?php echo $sidebar_color; ?>20;
        }

        .input-group-custom .input-group-text {
            background: transparent;
            border: none;
            color: #94a3b8;
            padding-left: 1rem;
        }

        .input-group-custom input {
            border: none;
            box-shadow: none;
            padding: 0.75rem 0.5rem 0.75rem 0;
            font-size: 0.95rem;
        }

        .input-group-custom input:focus {
            outline: none;
            box-shadow: none;
        }

        .btn-login {
            background: linear-gradient(105deg, <?php echo $sidebar_color; ?> 0%, <?php echo $sidebar_color; ?>dd 100%);
            border: none;
            border-radius: 1rem;
            padding: 0.85rem;
            font-weight: 600;
            font-size: 1rem;
            transition: all 0.2s;
            color: white;
        }

        .btn-login:hover {
            transform: translateY(-2px);
            box-shadow: 0 12px 20px -12px <?php echo $sidebar_color; ?>80;
            filter: brightness(1.02);
        }

        .toggle-pwd {
            background: transparent;
            border: none;
            color: #94a3b8;
            padding-right: 1rem;
        }

        .toggle-pwd:hover {
            color: <?php echo $sidebar_color; ?>;
        }

        .auth-link {
            color: <?php echo $sidebar_color; ?>;
            font-weight: 600;
            text-decoration: none;
        }

        .auth-link:hover {
            text-decoration: underline;
        }

        /* Responsive: Hide left panel on small screens, show mobile logo */
        @media (max-width: 992px) {
            .hero-panel {
                display: none;
            }
            
            .mobile-logo-container {
                display: block;
            }
            
            .form-panel {
                padding: 1rem;
            }
            
            .form-card {
                padding: 1.5rem;
                margin: 0 auto;
            }
        }

        /* For very small screens */
        @media (max-width: 576px) {
            .form-card {
                padding: 1.25rem;
            }
            
            .mobile-logo {
                width: 70px;
                height: 70px;
            }
        }

        /* Custom scrollbar for form panel */
        .form-panel::-webkit-scrollbar {
            width: 6px;
        }

        .form-panel::-webkit-scrollbar-track {
            background: #e2e8f0;
            border-radius: 10px;
        }

        .form-panel::-webkit-scrollbar-thumb {
            background: <?php echo $sidebar_color; ?>;
            border-radius: 10px;
        }

        .hero-panel::-webkit-scrollbar {
            width: 4px;
        }

        .hero-panel::-webkit-scrollbar-track {
            background: rgba(255,255,255,0.2);
            border-radius: 10px;
        }

        .hero-panel::-webkit-scrollbar-thumb {
            background: rgba(255,255,255,0.5);
            border-radius: 10px;
        }
    </style>
</head>
<body>
    <div class="login-container">
        <div class="row row-full g-0">
            <!-- LEFT SIDE: Hero Panel (hidden on mobile) -->
            <div class="col-lg-7 hero-panel">
                <div class="hero-overlay"></div>
                <div class="hero-content">
                    <div class="mb-4">
                        <img src="images/logo.jpg" alt="Kampala Traffic Predictor" 
                             style="width: 110px; height: 110px; object-fit: cover; border-radius: 50%; border: 3px solid rgba(255,255,255,0.5); box-shadow: 0 20px 35px -10px rgba(0,0,0,0.3);">
                    </div>
                    <h1 class="display-5 fw-bold mb-3">Kampala Traffic<br>AI Predictor</h1>
                    <p class="fs-5 opacity-90 mb-4">Real‑time intelligence & machine learning<br>to beat the city's congestion.</p>
                    
                    <div class="d-flex flex-wrap justify-content-center gap-3 mt-2">
                        <div class="stat-circle" style="background: rgba(255,255,255,0.12); backdrop-filter: blur(4px); border-radius: 2rem; padding: 0.8rem 1.5rem;">
                            <i class="bi bi-people-fill fs-4 me-2"></i>
                            <span class="fw-bold fs-5">10K+</span>
                            <small class="d-block opacity-75">Active users</small>
                        </div>
                        <div class="stat-circle" style="background: rgba(255,255,255,0.12); backdrop-filter: blur(4px); border-radius: 2rem; padding: 0.8rem 1.5rem;">
                            <i class="bi bi-pin-map-fill fs-4 me-2"></i>
                            <span class="fw-bold fs-5">50+</span>
                            <small class="d-block opacity-75">Hotspots</small>
                        </div>
                        <div class="stat-circle" style="background: rgba(255,255,255,0.12); backdrop-filter: blur(4px); border-radius: 2rem; padding: 0.8rem 1.5rem;">
                            <i class="bi bi-graph-up fs-4 me-2"></i>
                            <span class="fw-bold fs-5">24/7</span>
                            <small class="d-block opacity-75">Predictive AI</small>
                        </div>
                    </div>
                    
                    <div class="mt-5 pt-3">
                        <span class="stats-badge" style="background: rgba(255,255,255,0.15); backdrop-filter: blur(8px); border-radius: 1.5rem; padding: 0.5rem 1.2rem; font-weight: 500; font-size: 0.9rem;">
                            <i class="bi bi-shield-check me-1"></i> Trusted by KCCA & traffic authorities
                        </span>
                    </div>
                </div>
            </div>

            <!-- RIGHT SIDE: Login Form Panel -->
            <div class="col-lg-5 form-panel">
                <div class="form-card">
                    <!-- Mobile Logo - Only visible on small screens -->
                    <div class="mobile-logo-container">
                        <img src="images/logo.jpg" alt="Logo" class="mobile-logo">
                        <h5 class="mt-2 fw-bold" style="color: <?php echo $sidebar_color; ?>;">Welcome Back</h5>
                        <p class="text-muted small mb-0">Sign in to continue</p>
                    </div>

                    <!-- Desktop welcome text (hidden on mobile) -->
                    <div class="d-none d-lg-block">
                        <h3 class="fw-bold mb-1" style="color: #1e293b;">Welcome back</h3>
                        <p class="text-muted mb-4">Enter your credentials to access your account</p>
                    </div>

                    <div id="loginMessage"></div>

                    <form id="loginForm">
                        <!-- Email field with Bootstrap Icon -->
                        <div class="mb-3">
                            <label class="form-label fw-semibold small text-secondary">Email address</label>
                            <div class="input-group-custom d-flex align-items-center">
                                <span class="input-group-text"><i class="bi bi-envelope-fill"></i></span>
                                <input type="email" class="form-control" id="email" name="email" 
                                       placeholder="michael@example.com" required>
                            </div>
                        </div>

                        <!-- Password field with eye toggle -->
                        <div class="mb-3">
                            <div class="d-flex justify-content-between">
                                <label class="form-label fw-semibold small text-secondary">Password</label>
                                <a href="forgot_password.php" class="small text-decoration-none" style="color: <?php echo $sidebar_color; ?>;">Forgot?</a>
                            </div>
                            <div class="input-group-custom d-flex align-items-center">
                                <span class="input-group-text"><i class="bi bi-lock-fill"></i></span>
                                <input type="password" class="form-control" id="password" name="password" 
                                       placeholder="••••••••" required>
                                <button class="toggle-pwd" type="button" id="togglePassword">
                                    <i class="bi bi-eye-slash"></i>
                                </button>
                            </div>
                        </div>

                        <!-- Remember me checkbox -->
                        <div class="mb-4 d-flex justify-content-between align-items-center">
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" id="remember" name="remember" style="border-color: #cbd5e1;">
                                <label class="form-check-label small text-secondary" for="remember">
                                    Keep me signed in
                                </label>
                            </div>
                        </div>

                        <button type="submit" class="btn-login w-100">
                            <i class="bi bi-box-arrow-in-right me-2"></i>Sign In
                        </button>
                    </form>

                    <div class="mt-4 text-center">
                        <p class="mb-1 small text-secondary">Don't have an account? 
                            <a href="register_user.php" class="auth-link">Create account</a>
                        </p>
                        <p class="mt-2">
                            <a href="register_admin.php" class="small text-muted text-decoration-none">Admin registration</a>
                        </p>
                        <hr class="my-4">
                        <div class="d-flex justify-content-center gap-3 text-muted small">
                            <i class="bi bi-shield-lock-fill"></i> Secure login 
                            <i class="bi bi-cloud-check-fill"></i> Real‑time AI
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- MODAL: Suspended Account (KEPT) -->
    <div class="modal fade" id="suspendedModal" tabindex="-1">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content border-0 shadow-lg">
                <div class="modal-header border-0 bg-danger text-white">
                    <h5 class="modal-title"><i class="bi bi-exclamation-triangle-fill me-2"></i>Account Suspended</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body text-center p-4">
                    <div class="bg-danger bg-opacity-10 rounded-circle d-inline-flex p-4 mb-3">
                        <i class="bi bi-person-x-fill fs-1 text-danger"></i>
                    </div>
                    <h5 class="mb-3">Access denied</h5>
                    <p class="text-muted mb-0" id="suspendedMessage">Please contact the administrator.</p>
                </div>
                <div class="modal-footer border-0 justify-content-center">
                    <button type="button" class="btn btn-outline-secondary px-4" data-bs-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>

    <!-- ✅ VERIFICATION MODAL REMOVED -->

    <!-- jQuery + Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
    
    <script>
        // Toggle password visibility with Bootstrap Icons
        const togglePwd = document.getElementById('togglePassword');
        const passwordField = document.getElementById('password');
        const toggleIcon = togglePwd.querySelector('i');

        togglePwd.addEventListener('click', function() {
            const type = passwordField.getAttribute('type') === 'password' ? 'text' : 'password';
            passwordField.setAttribute('type', type);
            toggleIcon.classList.toggle('bi-eye');
            toggleIcon.classList.toggle('bi-eye-slash');
        });

        // Login AJAX handler (SIMPLIFIED - No verification logic)
        $('#loginForm').on('submit', function(e) {
            e.preventDefault();
            const $btn = $(this).find('button[type="submit"]');
            $btn.prop('disabled', true).html('<span class="spinner-border spinner-border-sm me-2"></span>Signing in...');
            
            $.ajax({
                url: 'api/login.php',
                type: 'POST',
                data: $(this).serialize(),
                dataType: 'json',
                success: function(response) {
                    if (response.success) {
                        window.location.href = 'dashboard.php';
                    } else {
                        if (response.suspended) {
                            $('#suspendedMessage').text(response.message || 'Your account has been suspended. Contact support.');
                            $('#suspendedModal').modal('show');
                        } 
                        else {
                            $('#loginMessage').html('<div class="alert alert-danger"><i class="bi bi-x-circle-fill me-2"></i>' + response.message + '</div>');
                        }
                    }
                    $btn.prop('disabled', false).html('<i class="bi bi-box-arrow-in-right me-2"></i>Sign In');
                },
                error: function() {
                    $('#loginMessage').html('<div class="alert alert-danger"><i class="bi bi-wifi-off me-2"></i>Server error. Please try again later.</div>');
                    $btn.prop('disabled', false).html('<i class="bi bi-box-arrow-in-right me-2"></i>Sign In');
                }
            });
        });

        // Auto-dismiss alerts after 5 seconds
        $(document).on('click', '.alert .btn-close', function() {
            $(this).closest('.alert').fadeOut();
        });
    </script>
</body>
</html>