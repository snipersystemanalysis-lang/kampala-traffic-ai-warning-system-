<?php
require_once 'includes/auth.php';
require_once 'includes/header.php';

// Set timezone
date_default_timezone_set('Africa/Nairobi');

$user_role = $_SESSION['role'];
$is_admin = ($user_role == 'admin');
$user_id = $_SESSION['user_id'];
$user_name = $_SESSION['user_name'];
?>
<style>
:root {
    --sidebar-color: <?php echo $sidebar_color; ?>;
    --primary-gradient: linear-gradient(135deg, var(--sidebar-color) 0%, <?php echo adjustBrightness($sidebar_color, -20); ?> 100%);
}

/* Main Layout */
.reports-wrapper {
    display: flex;
    min-height: 100vh;
    background: #f8fafc;
}

.main-content {
    flex: 1;
    margin-left: var(--sidebar-width);
    transition: margin-left 0.3s;
    padding: 30px;
}

/* Stats Cards */
.stats-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    gap: 20px;
    margin-bottom: 25px;
}

.stat-card {
    background: white;
    border-radius: 16px;
    padding: 20px;
    box-shadow: 0 5px 20px rgba(0,0,0,0.05);
    border: 1px solid rgba(0,0,0,0.05);
    display: flex;
    align-items: center;
    gap: 15px;
    transition: all 0.3s;
}

.stat-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 15px 30px rgba(0,0,0,0.1);
}

.stat-icon {
    width: 50px;
    height: 50px;
    background: var(--primary-gradient);
    border-radius: 12px;
    display: flex;
    align-items: center;
    justify-content: center;
    color: white;
    font-size: 24px;
}

.stat-content h3 {
    font-size: 1.8rem;
    font-weight: 700;
    margin: 0;
    color: #1e293b;
}

.stat-content p {
    margin: 0;
    color: #64748b;
    font-size: 0.9rem;
}

/* Filter Section */
.filter-section {
    background: white;
    border-radius: 20px;
    padding: 20px;
    margin-bottom: 25px;
    box-shadow: 0 5px 20px rgba(0,0,0,0.05);
}

.filter-header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    margin-bottom: 20px;
    flex-wrap: wrap;
    gap: 15px;
}

.filter-header h5 {
    margin: 0;
    font-size: 1.1rem;
    font-weight: 600;
    color: #1e293b;
    display: flex;
    align-items: center;
    gap: 8px;
}

.filter-header h5 i {
    color: var(--sidebar-color);
}

.filter-actions {
    display: flex;
    gap: 10px;
    flex-wrap: wrap;
}

.filter-btn {
    padding: 8px 16px;
    border: 1px solid #e2e8f0;
    background: white;
    border-radius: 30px;
    font-size: 0.85rem;
    cursor: pointer;
    transition: all 0.3s;
    color: #475569;
    display: flex;
    align-items: center;
    gap: 5px;
}

.filter-btn:hover {
    background: #f8fafc;
    border-color: var(--sidebar-color);
    color: var(--sidebar-color);
}

.filter-btn.active {
    background: var(--primary-gradient);
    color: white;
    border-color: var(--sidebar-color);
}

.filter-btn i {
    font-size: 0.8rem;
}

/* Custom Date Range */
.custom-date-range {
    display: none;
    margin-top: 20px;
    padding: 20px;
    background: #f8fafc;
    border-radius: 12px;
    border: 1px solid #e2e8f0;
}

.custom-date-range.show {
    display: block;
    animation: slideDown 0.3s ease;
}

@keyframes slideDown {
    from {
        opacity: 0;
        transform: translateY(-10px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

.date-inputs {
    display: flex;
    gap: 15px;
    flex-wrap: wrap;
    align-items: flex-end;
}

.date-group {
    flex: 1;
    min-width: 200px;
}

.date-group label {
    display: block;
    margin-bottom: 5px;
    font-size: 0.85rem;
    color: #64748b;
    font-weight: 500;
}

.date-group input {
    width: 100%;
    padding: 10px 12px;
    border: 2px solid #e2e8f0;
    border-radius: 10px;
    font-size: 0.9rem;
}

.date-group input:focus {
    border-color: var(--sidebar-color);
    outline: none;
}

.apply-date-btn {
    padding: 10px 25px;
    background: var(--primary-gradient);
    color: white;
    border: none;
    border-radius: 10px;
    font-weight: 600;
    cursor: pointer;
    height: 42px;
    display: flex;
    align-items: center;
    gap: 8px;
}

.apply-date-btn:hover {
    transform: translateY(-2px);
    box-shadow: 0 5px 15px rgba(102, 126, 234, 0.3);
}

/* Charts Grid */
.charts-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(400px, 1fr));
    gap: 20px;
    margin-bottom: 25px;
}

.chart-card {
    background: white;
    border-radius: 20px;
    padding: 20px;
    box-shadow: 0 5px 20px rgba(0,0,0,0.05);
    border: 1px solid rgba(0,0,0,0.05);
}

.chart-header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    margin-bottom: 15px;
}

.chart-header h6 {
    margin: 0;
    font-size: 1rem;
    font-weight: 600;
    color: #1e293b;
    display: flex;
    align-items: center;
    gap: 8px;
}

.chart-header i {
    color: var(--sidebar-color);
}

.chart-container {
    height: 250px;
    position: relative;
}

/* Tables Section */
.reports-table-container {
    background: white;
    border-radius: 20px;
    box-shadow: 0 10px 40px rgba(0,0,0,0.08);
    overflow: hidden;
}

.table-header {
    padding: 20px 25px;
    border-bottom: 1px solid #eef2f6;
    display: flex;
    align-items: center;
    justify-content: space-between;
    flex-wrap: wrap;
    gap: 15px;
}

.table-header h4 {
    margin: 0;
    font-size: 1.2rem;
    font-weight: 600;
    color: #1e293b;
    display: flex;
    align-items: center;
    gap: 10px;
}

.table-header h4 i {
    color: var(--sidebar-color);
}

.table-actions {
    display: flex;
    gap: 10px;
    flex-wrap: wrap;
}

.export-btn {
    padding: 10px 20px;
    background: var(--primary-gradient);
    color: white;
    border: none;
    border-radius: 10px;
    font-weight: 500;
    cursor: pointer;
    display: flex;
    align-items: center;
    gap: 8px;
    transition: all 0.3s;
}

.export-btn:hover {
    transform: translateY(-2px);
    box-shadow: 0 5px 15px rgba(102, 126, 234, 0.3);
}

.print-btn {
    padding: 10px 20px;
    background: white;
    color: #475569;
    border: 1px solid #e2e8f0;
    border-radius: 10px;
    font-weight: 500;
    cursor: pointer;
    display: flex;
    align-items: center;
    gap: 8px;
    transition: all 0.3s;
}

.print-btn:hover {
    background: #f8fafc;
    border-color: var(--sidebar-color);
    color: var(--sidebar-color);
}

.table-responsive {
    padding: 0 25px 25px 25px;
    overflow-x: auto;
}

.table {
    width: 100%;
    border-collapse: collapse;
}

.table th {
    background: #f8fafc;
    padding: 15px 12px;
    font-size: 0.85rem;
    font-weight: 600;
    color: #475569;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    border-bottom: 2px solid #e2e8f0;
    white-space: nowrap;
}

.table td {
    padding: 15px 12px;
    border-bottom: 1px solid #eef2f6;
    color: #1e293b;
    vertical-align: middle;
}

.table tbody tr:hover {
    background: #f8fafc;
}

/* Status Badges */
.status-badge {
    padding: 5px 12px;
    border-radius: 30px;
    font-size: 0.8rem;
    font-weight: 600;
    display: inline-block;
}

.status-approved {
    background: #d1fae5;
    color: #065f46;
}

.status-pending {
    background: #fff3cd;
    color: #856404;
}

.status-rejected {
    background: #fee2e2;
    color: #991b1b;
}

/* Traffic Level Badges */
.level-heavy {
    background: #fee2e2;
    color: #991b1b;
}

.level-moderate {
    background: #fff3cd;
    color: #856404;
}

.level-light {
    background: #d1fae5;
    color: #065f46;
}

/* Action Buttons */
.action-btn {
    padding: 6px 12px;
    border-radius: 8px;
    border: none;
    cursor: pointer;
    transition: all 0.3s;
    margin: 0 3px;
    font-size: 0.85rem;
}

.approve-btn {
    background: #d1fae5;
    color: #065f46;
}

.approve-btn:hover {
    background: #065f46;
    color: white;
}

.reject-btn {
    background: #fee2e2;
    color: #991b1b;
}

.reject-btn:hover {
    background: #991b1b;
    color: white;
}

.view-btn {
    background: #e6f0ff;
    color: #2563eb;
}

.view-btn:hover {
    background: #2563eb;
    color: white;
}

/* User Activity Section */
.activity-section {
    margin-top: 25px;
}

.activity-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
    gap: 20px;
}

.activity-card {
    background: white;
    border-radius: 16px;
    padding: 20px;
    box-shadow: 0 5px 20px rgba(0,0,0,0.05);
    border: 1px solid rgba(0,0,0,0.05);
}

.activity-header {
    display: flex;
    align-items: center;
    gap: 10px;
    margin-bottom: 15px;
    padding-bottom: 10px;
    border-bottom: 1px solid #eef2f6;
}

.activity-header i {
    width: 30px;
    height: 30px;
    background: var(--primary-gradient);
    border-radius: 8px;
    display: flex;
    align-items: center;
    justify-content: center;
    color: white;
    font-size: 14px;
}

.activity-header h6 {
    margin: 0;
    font-weight: 600;
    color: #1e293b;
}

.activity-list {
    max-height: 200px;
    overflow-y: auto;
}

.activity-item {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 8px 0;
    border-bottom: 1px dashed #eef2f6;
}

.activity-item:last-child {
    border-bottom: none;
}

.activity-item .user-name {
    font-weight: 500;
    color: #1e293b;
}

.activity-item .report-count {
    background: #f1f5f9;
    padding: 2px 8px;
    border-radius: 30px;
    font-size: 0.8rem;
    font-weight: 600;
}

/* Hotspot Popularity */
.hotspot-rank {
    display: flex;
    align-items: center;
    gap: 10px;
    padding: 8px 0;
    border-bottom: 1px dashed #eef2f6;
}

.rank-number {
    width: 24px;
    height: 24px;
    background: var(--primary-gradient);
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    color: white;
    font-size: 0.8rem;
    font-weight: 600;
}

.hotspot-info {
    flex: 1;
}

.hotspot-name {
    font-weight: 500;
    color: #1e293b;
}

.hotspot-stats {
    display: flex;
    gap: 10px;
    font-size: 0.75rem;
    color: #64748b;
}

/* Modal Styles */
.modal-content {
    border-radius: 20px;
    border: none;
    box-shadow: 0 20px 60px rgba(0,0,0,0.3);
}

.modal-header {
    background: var(--primary-gradient);
    color: white;
    border-radius: 20px 20px 0 0;
    padding: 20px 25px;
    border: none;
}

.modal-header .btn-close {
    filter: brightness(0) invert(1);
}

.modal-body {
    padding: 25px;
}

.modal-footer {
    padding: 15px 25px;
    border-top: 1px solid #eef2f6;
}

.form-label {
    font-weight: 600;
    color: #2d3748;
    margin-bottom: 8px;
    font-size: 0.9rem;
}

.form-control, .form-select {
    border: 2px solid #e2e8f0;
    border-radius: 12px;
    padding: 10px 15px;
}

.form-control:focus, .form-select:focus {
    border-color: var(--sidebar-color);
    box-shadow: 0 0 0 4px rgba(102, 126, 234, 0.1);
    outline: none;
}

/* Loading State */
.loading-spinner {
    text-align: center;
    padding: 40px;
}

.spinner {
    width: 40px;
    height: 40px;
    border: 3px solid #f3f3f3;
    border-top: 3px solid var(--sidebar-color);
    border-radius: 50%;
    animation: spin 1s linear infinite;
    margin: 0 auto 15px;
}

@keyframes spin {
    0% { transform: rotate(0deg); }
    100% { transform: rotate(360deg); }
}

/* Responsive */
@media (max-width: 991px) {
    .main-content {
        margin-left: 0;
        padding: 20px;
    }
    
    .charts-grid {
        grid-template-columns: 1fr;
    }
    
    .date-inputs {
        flex-direction: column;
    }
    
    .date-group {
        width: 100%;
    }
    
    .apply-date-btn {
        width: 100%;
        justify-content: center;
    }
}

@media (max-width: 768px) {
    .stats-grid {
        grid-template-columns: 1fr;
    }
    
    .filter-actions {
        justify-content: flex-start;
    }
    
    .table-header {
        flex-direction: column;
        align-items: flex-start;
    }
    
    .table-actions {
        width: 100%;
    }
    
    .export-btn, .print-btn {
        flex: 1;
        justify-content: center;
    }
}
</style>

<?php
function adjustBrightness($hex, $steps) {
    $hex = str_replace('#', '', $hex);
    if (strlen($hex) == 3) {
        $hex = $hex[0].$hex[0].$hex[1].$hex[1].$hex[2].$hex[2];
    }
    
    $r = hexdec(substr($hex, 0, 2));
    $g = hexdec(substr($hex, 2, 2));
    $b = hexdec(substr($hex, 4, 2));
    
    $r = max(0, min(255, $r + $steps));
    $g = max(0, min(255, $g + $steps));
    $b = max(0, min(255, $b + $steps));
    
    return '#' . sprintf("%02x%02x%02x", $r, $g, $b);
}
?>

<div class="reports-wrapper">
    <?php require_once 'includes/sidebar.php'; ?>
    
    <div class="main-content">
        <!-- Welcome Banner -->
        <div class="ai-header-section mb-4" style="background: var(--primary-gradient); border-radius: 20px; padding: 20px; color: white;">
            <div class="d-flex align-items-center">
                <div class="ai-icon me-3" style="width: 50px; height: 50px; background: rgba(255,255,255,0.2); border-radius: 12px; display: flex; align-items: center; justify-content: center;">
                    <i class="bi bi-flag-fill fs-3"></i>
                </div>
                <div>
                    <h4 class="mb-1">Traffic Reports Management</h4>
                    <p class="mb-0 opacity-75">View and manage all traffic reports from users across Kampala</p>
                </div>
                <div class="ms-auto">
                    <span class="badge bg-white text-dark">
                        <i class="bi bi-person-fill me-1"></i> <?php echo htmlspecialchars($user_name); ?>
                    </span>
                </div>
            </div>
        </div>

        <!-- Stats Cards -->
        <div class="stats-grid" id="statsGrid">
            <div class="stat-card">
                <div class="stat-icon">
                    <i class="bi bi-flag-fill"></i>
                </div>
                <div class="stat-content">
                    <h3 id="totalReports">0</h3>
                    <p>Total Reports</p>
                </div>
            </div>
            <div class="stat-card">
                <div class="stat-icon">
                    <i class="bi bi-check-circle-fill"></i>
                </div>
                <div class="stat-content">
                    <h3 id="approvedReports">0</h3>
                    <p>Approved</p>
                </div>
            </div>
            <div class="stat-card">
                <div class="stat-icon">
                    <i class="bi bi-hourglass-split"></i>
                </div>
                <div class="stat-content">
                    <h3 id="pendingReports">0</h3>
                    <p>Pending</p>
                </div>
            </div>
            <div class="stat-card">
                <div class="stat-icon">
                    <i class="bi bi-x-circle-fill"></i>
                </div>
                <div class="stat-content">
                    <h3 id="rejectedReports">0</h3>
                    <p>Rejected</p>
                </div>
            </div>
            <div class="stat-card">
                <div class="stat-icon">
                    <i class="bi bi-people-fill"></i>
                </div>
                <div class="stat-content">
                    <h3 id="activeUsers">0</h3>
                    <p>Active Users</p>
                </div>
            </div>
            <div class="stat-card">
                <div class="stat-icon">
                    <i class="bi bi-geo-alt-fill"></i>
                </div>
                <div class="stat-content">
                    <h3 id="activeHotspots">0</h3>
                    <p>Hotspots</p>
                </div>
            </div>
        </div>

        <!-- Filter Section -->
        <div class="filter-section">
            <div class="filter-header">
                <h5>
                    <i class="bi bi-funnel-fill"></i>
                    Filter Reports
                </h5>
                <div class="filter-actions">
                    <button class="filter-btn active" onclick="setDateFilter('today')">
                        <i class="bi bi-calendar-day"></i> Today
                    </button>
                    <button class="filter-btn" onclick="setDateFilter('yesterday')">
                        <i class="bi bi-calendar-day"></i> Yesterday
                    </button>
                    <button class="filter-btn" onclick="setDateFilter('thisWeek')">
                        <i class="bi bi-calendar-week"></i> This Week
                    </button>
                    <button class="filter-btn" onclick="setDateFilter('thisMonth')">
                        <i class="bi bi-calendar-month"></i> This Month
                    </button>
                    <button class="filter-btn" onclick="setDateFilter('lastMonth')">
                        <i class="bi bi-calendar-month"></i> Last Month
                    </button>
                    <button class="filter-btn" onclick="setDateFilter('thisYear')">
                        <i class="bi bi-calendar"></i> This Year
                    </button>
                    <button class="filter-btn" onclick="setDateFilter('lastYear')">
                        <i class="bi bi-calendar"></i> Last Year
                    </button>
                    <button class="filter-btn" id="customRangeBtn" onclick="toggleCustomRange()">
                        <i class="bi bi-sliders2"></i> Custom Range
                    </button>
                </div>
            </div>

            <!-- Custom Date Range -->
            <div class="custom-date-range" id="customDateRange">
                <div class="date-inputs">
                    <div class="date-group">
                        <label>From Date</label>
                        <input type="date" id="dateFrom" class="form-control">
                    </div>
                    <div class="date-group">
                        <label>To Date</label>
                        <input type="date" id="dateTo" class="form-control">
                    </div>
                    <button class="apply-date-btn" onclick="applyCustomDateRange()">
                        <i class="bi bi-check-lg"></i> Apply Range
                    </button>
                </div>
            </div>
        </div>

        <!-- Charts Grid (Admin Only) -->
        <?php if ($is_admin): ?>
        <div class="charts-grid">
            <div class="chart-card">
                <div class="chart-header">
                    <h6>
                        <i class="bi bi-pie-chart-fill"></i>
                        Reports by Status
                    </h6>
                </div>
                <div class="chart-container">
                    <canvas id="statusChart"></canvas>
                </div>
            </div>
            <div class="chart-card">
                <div class="chart-header">
                    <h6>
                        <i class="bi bi-graph-up-arrow"></i>
                        Reports Over Time
                    </h6>
                </div>
                <div class="chart-container">
                    <canvas id="timelineChart"></canvas>
                </div>
            </div>
            <div class="chart-card">
                <div class="chart-header">
                    <h6>
                        <i class="bi bi-bar-chart-fill"></i>
                        Traffic Levels
                    </h6>
                </div>
                <div class="chart-container">
                    <canvas id="trafficLevelChart"></canvas>
                </div>
            </div>
            <div class="chart-card">
                <div class="chart-header">
                    <h6>
                        <i class="bi bi-bar-chart-steps"></i>
                        Top Hotspots
                    </h6>
                </div>
                <div class="chart-container">
                    <canvas id="hotspotChart"></canvas>
                </div>
            </div>
        </div>
        <?php endif; ?>

        <!-- Reports Table -->
        <div class="reports-table-container">
            <div class="table-header">
                <h4>
                    <i class="bi bi-list-ul"></i>
                    Traffic Reports
                </h4>
                <div class="table-actions">
                    <?php if (!$is_admin): ?>
                    <button class="export-btn" data-bs-toggle="modal" data-bs-target="#submitReportModal">
                        <i class="bi bi-plus-circle-fill"></i>
                        Submit Report
                    </button>
                    <?php endif; ?>
                    <button class="export-btn" onclick="exportToPDF()">
                        <i class="bi bi-file-pdf-fill"></i>
                        Export PDF
                    </button>
                    <button class="export-btn" onclick="exportToCSV()">
                        <i class="bi bi-file-spreadsheet-fill"></i>
                        Export CSV
                    </button>
                    <button class="print-btn" onclick="window.print()">
                        <i class="bi bi-printer-fill"></i>
                        Print
                    </button>
                </div>
            </div>

            <div class="table-responsive">
                <table class="table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>User</th>
                            <th>Location</th>
                            <th>Traffic Level</th>
                            <th>Description</th>
                            <th>Status</th>
                            <th>Date</th>
                            <?php if ($is_admin): ?>
                            <th>Actions</th>
                            <?php endif; ?>
                        </tr>
                    </thead>
                    <tbody id="reportsTable">
                        <tr>
                            <td colspan="<?php echo $is_admin ? '8' : '7'; ?>" class="text-center">
                                <div class="loading-spinner">
                                    <div class="spinner"></div>
                                    <p>Loading reports from database...</p>
                                </div>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- Admin Activity Section -->
        <?php if ($is_admin): ?>
        <div class="activity-section">
            <div class="activity-grid">
                <!-- Top Users -->
                <div class="activity-card">
                    <div class="activity-header">
                        <i class="bi bi-trophy-fill"></i>
                        <h6>Most Active Users</h6>
                    </div>
                    <div class="activity-list" id="topUsersList">
                        <div class="text-center py-3">
                            <div class="spinner-border spinner-border-sm text-primary"></div>
                            <p class="mt-2 mb-0 small">Loading top users...</p>
                        </div>
                    </div>
                </div>

                <!-- Popular Hotspots -->
                <div class="activity-card">
                    <div class="activity-header">
                        <i class="bi bi-map-fill"></i>
                        <h6>Most Reported Hotspots</h6>
                    </div>
                    <div class="activity-list" id="topHotspotsList">
                        <div class="text-center py-3">
                            <div class="spinner-border spinner-border-sm text-primary"></div>
                            <p class="mt-2 mb-0 small">Loading hotspots...</p>
                        </div>
                    </div>
                </div>

                <!-- Recent Activity -->
                <div class="activity-card">
                    <div class="activity-header">
                        <i class="bi bi-clock-history"></i>
                        <h6>Recent Activity</h6>
                    </div>
                    <div class="activity-list" id="recentActivityList">
                        <div class="text-center py-3">
                            <div class="spinner-border spinner-border-sm text-primary"></div>
                            <p class="mt-2 mb-0 small">Loading activity...</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php endif; ?>
    </div>
</div>

<!-- Submit Report Modal -->
<div class="modal fade" id="submitReportModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">
                    <i class="bi bi-flag-fill me-2"></i>
                    Submit Traffic Report
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <form id="submitReportForm">
                    <div class="mb-3">
                        <label class="form-label">Select Hotspot <span class="text-danger">*</span></label>
                        <select class="form-select" name="hotspot_id" id="hotspotSelect" required>
                            <option value="">-- Choose a location --</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Traffic Level <span class="text-danger">*</span></label>
                        <select class="form-select" name="traffic_level" required>
                            <option value="">-- Select level --</option>
                            <option value="Light">Light Traffic</option>
                            <option value="Moderate">Moderate Traffic</option>
                            <option value="Heavy">Heavy Traffic</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Description <span class="text-danger">*</span></label>
                        <textarea class="form-control" name="description" rows="4" placeholder="Describe the traffic situation..." required></textarea>
                    </div>
                    <button type="submit" class="btn w-100" style="background: var(--primary-gradient); color: white; padding: 12px;">
                        <i class="bi bi-send-fill me-2"></i>
                        Submit Report
                    </button>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- View Report Modal -->
<div class="modal fade" id="viewReportModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">
                    <i class="bi bi-eye-fill me-2"></i>
                    Report Details
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body" id="reportDetails">
                <!-- Populated by JavaScript -->
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>

<!-- Include required libraries -->
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.4.1/html2canvas.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>

<script>
// Global variables
let currentFilter = 'today';
let statusChart, timelineChart, trafficLevelChart, hotspotChart;
let dateFrom = '';
let dateTo = '';

$(document).ready(function() {
    // Load all data on page load
    loadReports();
    loadStats();
    loadHotspotsForSelect();
    
    <?php if ($is_admin): ?>
    loadChartsData();
    loadTopUsers();
    loadTopHotspots();
    loadRecentActivity();
    <?php endif; ?>
    
    // Set today's date in custom range inputs
    const today = new Date().toISOString().split('T')[0];
    $('#dateTo').val(today);
    
    const thirtyDaysAgo = new Date();
    thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);
    $('#dateFrom').val(thirtyDaysAgo.toISOString().split('T')[0]);
});

// Load reports from database
function loadReports() {
    let params = { action: 'get_reports', filter: currentFilter };
    
    if (currentFilter === 'custom' && dateFrom && dateTo) {
        params.date_from = dateFrom;
        params.date_to = dateTo;
    }
    
    $.ajax({
        url: 'api/report_api.php',
        type: 'GET',
        data: params,
        dataType: 'json',
        success: function(response) {
            if (response.success) {
                displayReports(response.data);
            } else {
                $('#reportsTable').html('<tr><td colspan="<?php echo $is_admin ? '8' : '7'; ?>" class="text-center py-4 text-danger">Error loading reports</td></tr>');
            }
        },
        error: function() {
            $('#reportsTable').html('<tr><td colspan="<?php echo $is_admin ? '8' : '7'; ?>" class="text-center py-4 text-danger">Failed to connect to server</td></tr>');
        }
    });
}

// Load statistics
function loadStats() {
    let params = { action: 'get_stats', filter: currentFilter };
    
    if (currentFilter === 'custom' && dateFrom && dateTo) {
        params.date_from = dateFrom;
        params.date_to = dateTo;
    }
    
    $.ajax({
        url: 'api/report_api.php',
        type: 'GET',
        data: params,
        dataType: 'json',
        success: function(response) {
            if (response.success) {
                $('#totalReports').text(response.data.total);
                $('#approvedReports').text(response.data.approved);
                $('#pendingReports').text(response.data.pending);
                $('#rejectedReports').text(response.data.rejected);
                $('#activeUsers').text(response.data.active_users);
                $('#activeHotspots').text(response.data.active_hotspots);
            }
        }
    });
}

// Load charts data (admin only)
function loadChartsData() {
    let params = { action: 'get_charts_data', filter: currentFilter };
    
    if (currentFilter === 'custom' && dateFrom && dateTo) {
        params.date_from = dateFrom;
        params.date_to = dateTo;
    }
    
    $.ajax({
        url: 'api/report_api.php',
        type: 'GET',
        data: params,
        dataType: 'json',
        success: function(response) {
            if (response.success) {
                initCharts(response.data);
            }
        }
    });
}

// Load top users (admin only)
function loadTopUsers() {
    $.ajax({
        url: 'api/report_api.php',
        type: 'GET',
        data: { action: 'get_top_users' },
        dataType: 'json',
        success: function(response) {
            if (response.success) {
                displayTopUsers(response.data);
            }
        }
    });
}

// Load top hotspots (admin only)
function loadTopHotspots() {
    $.ajax({
        url: 'api/report_api.php',
        type: 'GET',
        data: { action: 'get_top_hotspots' },
        dataType: 'json',
        success: function(response) {
            if (response.success) {
                displayTopHotspots(response.data);
            }
        }
    });
}

// Load recent activity (admin only)
function loadRecentActivity() {
    $.ajax({
        url: 'api/report_api.php',
        type: 'GET',
        data: { action: 'get_recent_activity' },
        dataType: 'json',
        success: function(response) {
            if (response.success) {
                displayRecentActivity(response.data);
            }
        }
    });
}

// Load hotspots for select dropdown
function loadHotspotsForSelect() {
    $.ajax({
        url: 'api/report_api.php',
        type: 'GET',
        data: { action: 'get_hotspots_for_select' },
        dataType: 'json',
        success: function(response) {
            if (response.success) {
                let options = '<option value="">-- Choose a location --</option>';
                response.data.forEach(function(hotspot) {
                    options += '<option value="' + hotspot.id + '">' + hotspot.location_name + '</option>';
                });
                $('#hotspotSelect').html(options);
            }
        }
    });
}

// Display reports in table
function displayReports(reports) {
    let html = '';
    const isAdmin = <?php echo $is_admin ? 'true' : 'false'; ?>;
    
    if (reports.length === 0) {
        html = '<tr><td colspan="' + (isAdmin ? '8' : '7') + '" class="text-center py-5">';
        html += '<i class="bi bi-inbox fs-1 d-block text-muted mb-3"></i>';
        html += '<p class="text-muted">No reports found for the selected period</p>';
        html += '</td></tr>';
    } else {
        reports.forEach(function(report) {
            // Status class
            let statusClass = 'status-pending';
            if (report.status === 'approved') statusClass = 'status-approved';
            if (report.status === 'rejected') statusClass = 'status-rejected';
            
            // Level class
            let levelClass = 'level-light';
            if (report.traffic_level === 'Heavy') levelClass = 'level-heavy';
            if (report.traffic_level === 'Moderate') levelClass = 'level-moderate';
            
            html += '<tr>';
            html += '<td><span class="fw-bold">#' + report.id + '</span></td>';
            html += '<td>' + report.user_name + '</td>';
            html += '<td>' + report.location_name + '</td>';
            html += '<td><span class="status-badge ' + levelClass + '">' + report.traffic_level + '</span></td>';
            html += '<td>' + report.short_description + '</td>';
            html += '<td><span class="status-badge ' + statusClass + '">' + report.status_display + '</span></td>';
            html += '<td><span title="' + report.created_at + '">' + report.time_ago + '</span></td>';
            
            if (isAdmin) {
                html += '<td>';
                if (report.status === 'pending') {
                    html += '<button class="action-btn approve-btn" onclick="updateReportStatus(' + report.id + ', \'approve\')" title="Approve"><i class="bi bi-check-lg"></i></button> ';
                    html += '<button class="action-btn reject-btn" onclick="updateReportStatus(' + report.id + ', \'reject\')" title="Reject"><i class="bi bi-x-lg"></i></button> ';
                }
                html += '<button class="action-btn view-btn" onclick="viewReport(' + report.id + ')" title="View Details"><i class="bi bi-eye-fill"></i></button>';
                html += '</td>';
            }
            
            html += '</tr>';
        });
    }
    
    $('#reportsTable').html(html);
}

// Display top users
function displayTopUsers(users) {
    if (users.length === 0) {
        $('#topUsersList').html('<p class="text-center text-muted py-3">No user activity yet</p>');
        return;
    }
    
    let html = '';
    users.forEach(function(user, index) {
        let medal = index === 0 ? '🥇' : (index === 1 ? '🥈' : (index === 2 ? '🥉' : ''));
        html += `
            <div class="activity-item">
                <span class="user-name">${medal} ${user.name}</span>
                <span class="report-count">${user.count} report${user.count != 1 ? 's' : ''}</span>
            </div>
        `;
    });
    $('#topUsersList').html(html);
}

// Display top hotspots
function displayTopHotspots(hotspots) {
    if (hotspots.length === 0) {
        $('#topHotspotsList').html('<p class="text-center text-muted py-3">No hotspot data yet</p>');
        return;
    }
    
    let html = '';
    hotspots.forEach(function(hotspot, index) {
        let levelClass = hotspot.avg_level === 'Heavy' ? 'level-heavy' : (hotspot.avg_level === 'Moderate' ? 'level-moderate' : 'level-light');
        html += `
            <div class="hotspot-rank">
                <span class="rank-number">${index + 1}</span>
                <div class="hotspot-info">
                    <div class="hotspot-name">${hotspot.name}</div>
                    <div class="hotspot-stats">
                        <span><i class="bi bi-flag-fill"></i> ${hotspot.count} reports</span>
                        <span class="${levelClass}" style="padding: 2px 6px; border-radius: 12px;">${hotspot.avg_level}</span>
                    </div>
                </div>
            </div>
        `;
    });
    $('#topHotspotsList').html(html);
}

// Display recent activity
function displayRecentActivity(activities) {
    if (activities.length === 0) {
        $('#recentActivityList').html('<p class="text-center text-muted py-3">No recent activity</p>');
        return;
    }
    
    let html = '';
    activities.forEach(function(activity) {
        html += `
            <div class="activity-item">
                <span class="user-name">${activity.user}</span>
                <span class="report-count">${activity.time}</span>
            </div>
            <div class="small text-muted mb-2">${activity.action}</div>
        `;
    });
    $('#recentActivityList').html(html);
}

// Initialize charts
function initCharts(data) {
    // Status Chart
    if (statusChart) statusChart.destroy();
    const statusCtx = document.getElementById('statusChart').getContext('2d');
    statusChart = new Chart(statusCtx, {
        type: 'doughnut',
        data: {
            labels: ['Approved', 'Pending', 'Rejected'],
            datasets: [{
                data: [data.status.approved, data.status.pending, data.status.rejected],
                backgroundColor: ['#10b981', '#f59e0b', '#ef4444'],
                borderWidth: 0
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            cutout: '70%',
            plugins: {
                legend: { position: 'bottom' }
            }
        }
    });

    // Timeline Chart
    if (timelineChart) timelineChart.destroy();
    const timelineCtx = document.getElementById('timelineChart').getContext('2d');
    timelineChart = new Chart(timelineCtx, {
        type: 'line',
        data: {
            labels: data.timeline.labels,
            datasets: [{
                label: 'Reports',
                data: data.timeline.values,
                borderColor: '#667eea',
                backgroundColor: 'rgba(102, 126, 234, 0.1)',
                tension: 0.4,
                fill: true
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { display: false }
            },
            scales: {
                y: { beginAtZero: true, ticks: { stepSize: 1 } }
            }
        }
    });

    // Traffic Level Chart
    if (trafficLevelChart) trafficLevelChart.destroy();
    const levelCtx = document.getElementById('trafficLevelChart').getContext('2d');
    trafficLevelChart = new Chart(levelCtx, {
        type: 'pie',
        data: {
            labels: ['Heavy', 'Moderate', 'Light'],
            datasets: [{
                data: [data.levels.heavy, data.levels.moderate, data.levels.light],
                backgroundColor: ['#ef4444', '#f59e0b', '#10b981'],
                borderWidth: 0
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { position: 'bottom' }
            }
        }
    });

    // Hotspot Chart
    if (hotspotChart) hotspotChart.destroy();
    const hotspotCtx = document.getElementById('hotspotChart').getContext('2d');
    hotspotChart = new Chart(hotspotCtx, {
        type: 'bar',
        data: {
            labels: data.hotspots.labels,
            datasets: [{
                label: 'Number of Reports',
                data: data.hotspots.values,
                backgroundColor: '#667eea',
                borderRadius: 6
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { display: false }
            },
            scales: {
                y: { beginAtZero: true, ticks: { stepSize: 1 } }
            }
        }
    });
}

// Set date filter
function setDateFilter(filter) {
    currentFilter = filter;
    
    // Update active button
    $('.filter-btn').removeClass('active');
    $(`.filter-btn[onclick*="${filter}"]`).addClass('active');
    
    // Hide custom range
    $('#customDateRange').removeClass('show');
    
    // Reload data with new filter
    loadReports();
    loadStats();
    <?php if ($is_admin): ?>loadChartsData();<?php endif; ?>
}

// Toggle custom date range
function toggleCustomRange() {
    $('#customDateRange').toggleClass('show');
    if ($('#customDateRange').hasClass('show')) {
        $('.filter-btn').removeClass('active');
        $('#customRangeBtn').addClass('active');
        currentFilter = 'custom';
    }
}

// Apply custom date range
function applyCustomDateRange() {
    dateFrom = $('#dateFrom').val();
    dateTo = $('#dateTo').val();
    
    if (!dateFrom || !dateTo) {
        alert('Please select both dates');
        return;
    }
    
    if (dateFrom > dateTo) {
        alert('From date cannot be after To date');
        return;
    }
    
    loadReports();
    loadStats();
    <?php if ($is_admin): ?>loadChartsData();<?php endif; ?>
}

// Submit report form
$('#submitReportForm').on('submit', function(e) {
    e.preventDefault();
    
    $.ajax({
        url: 'api/report_api.php',
        type: 'POST',
        data: {
            action: 'submit_report',
            hotspot_id: $('select[name="hotspot_id"]').val(),
            traffic_level: $('select[name="traffic_level"]').val(),
            description: $('textarea[name="description"]').val()
        },
        dataType: 'json',
        success: function(response) {
            if (response.success) {
                alert('✅ Report submitted successfully!');
                $('#submitReportModal').modal('hide');
                $('#submitReportForm')[0].reset();
                loadReports();
                loadStats();
                <?php if ($is_admin): ?>
                loadChartsData();
                loadTopUsers();
                loadTopHotspots();
                loadRecentActivity();
                <?php endif; ?>
            } else {
                alert('❌ Error: ' + response.message);
            }
        },
        error: function() {
            alert('❌ Failed to connect to server');
        }
    });
});

// Update report status (approve/reject)
function updateReportStatus(id, action) {
    let actionText = action === 'approve' ? 'approve' : 'reject';
    if (confirm('Are you sure you want to ' + actionText + ' this report?')) {
        $.ajax({
            url: 'api/report_api.php',
            type: 'POST',
            data: {
                action: 'update_status',
                id: id,
                status: action
            },
            dataType: 'json',
            success: function(response) {
                if (response.success) {
                    loadReports();
                    loadStats();
                    loadChartsData();
                    loadTopUsers();
                    loadTopHotspots();
                    loadRecentActivity();
                } else {
                    alert('Error updating status');
                }
            }
        });
    }
}

// View report details
function viewReport(id) {
    $.ajax({
        url: 'api/report_api.php',
        type: 'GET',
        data: {
            action: 'get_report_details',
            id: id
        },
        dataType: 'json',
        success: function(response) {
            if (response.success) {
                let report = response.data;
                let statusClass = 'status-pending';
                if (report.status === 'approved') statusClass = 'status-approved';
                if (report.status === 'rejected') statusClass = 'status-rejected';
                
                let levelClass = 'level-light';
                if (report.traffic_level === 'Heavy') levelClass = 'level-heavy';
                if (report.traffic_level === 'Moderate') levelClass = 'level-moderate';
                
                let html = `
                    <div class="mb-4">
                        <div class="d-flex justify-content-between align-items-center mb-3">
                            <h5 class="mb-0">Report #${report.id}</h5>
                            <span class="status-badge ${statusClass}">${report.status_display}</span>
                        </div>
                        <hr>
                    </div>
                    <div class="mb-3">
                        <label class="fw-bold text-muted small">USER INFORMATION</label>
                        <p class="mb-1"><i class="bi bi-person-fill me-2"></i> ${report.user_name}</p>
                        <p class="mb-0"><i class="bi bi-envelope-fill me-2"></i> ${report.user_email}</p>
                    </div>
                    <div class="mb-3">
                        <label class="fw-bold text-muted small">LOCATION</label>
                        <p><i class="bi bi-geo-alt-fill me-2"></i> ${report.location_name}</p>
                    </div>
                    <div class="mb-3">
                        <label class="fw-bold text-muted small">TRAFFIC LEVEL</label>
                        <p><span class="status-badge ${levelClass}">${report.traffic_level}</span></p>
                    </div>
                    <div class="mb-3">
                        <label class="fw-bold text-muted small">DESCRIPTION</label>
                        <p class="border rounded p-3 bg-light">${report.description}</p>
                    </div>
                    <div class="mb-3">
                        <label class="fw-bold text-muted small">SUBMITTED</label>
                        <p><i class="bi bi-clock me-2"></i> ${report.created_at} (${report.time_ago})</p>
                    </div>
                `;
                
                $('#reportDetails').html(html);
                $('#viewReportModal').modal('show');
            } else {
                alert('Report not found');
            }
        }
    });
}

// Export to PDF
function exportToPDF() {
    const { jsPDF } = window.jspdf;
    
    html2canvas(document.querySelector('.main-content')).then(canvas => {
        const imgData = canvas.toDataURL('image/png');
        const pdf = new jsPDF({
            orientation: 'landscape',
            unit: 'px',
            format: [canvas.width, canvas.height]
        });
        
        pdf.addImage(imgData, 'PNG', 0, 0, canvas.width, canvas.height);
        pdf.save('traffic-reports-' + new Date().toISOString().split('T')[0] + '.pdf');
    });
}

// Export to CSV
function exportToCSV() {
    let url = 'api/report_api.php?action=export_csv&filter=' + currentFilter;
    if (currentFilter === 'custom' && dateFrom && dateTo) {
        url += '&date_from=' + dateFrom + '&date_to=' + dateTo;
    }
    window.location.href = url;
}

// Auto-refresh every 30 seconds
setInterval(function() {
    loadReports();
    loadStats();
    <?php if ($is_admin): ?>
    loadChartsData();
    <?php endif; ?>
}, 30000);
</script>

<?php require_once 'includes/footer.php'; ?>