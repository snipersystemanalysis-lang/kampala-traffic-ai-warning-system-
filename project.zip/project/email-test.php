<?php
// Professional PHPMailer Test - phpmailer-test.php
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Load PHPMailer from emailphp in root folder
require_once 'emailphp/PHPMailer-master/src/Exception.php';
require_once 'emailphp/PHPMailer-master/src/PHPMailer.php';
require_once 'emailphp/PHPMailer-master/src/SMTP.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

$result = '';
$resultClass = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $testEmail = $_POST['email'] ?? '';
    $customMessage = $_POST['message'] ?? '';
    
    try {
        // Create PHPMailer instance
        $mail = new PHPMailer(true);
        
        // Server settings - Using PHP mail() as fallback since it works
        $mail->isMail(); // Use PHP mail() function instead of SMTP
        
        // Sender info - Professional looking
        $mail->setFrom('noreply@kampalatrafficaiwarningsystem.ugprice.com', 'Traffic Warning System');
        $mail->addReplyTo('support@kampalatrafficaiwarningsystem.ugprice.com', 'Support Team');
        $mail->addAddress($testEmail);
        
        // Generate a professional access code (ClientID-XXXX format)
        $clientId = rand(1000, 9999);
        $randomCode = str_pad(mt_rand(1, 9999), 4, '0', STR_PAD_LEFT);
        $accessCode = $clientId . '-' . $randomCode;
        $expiresAt = date('Y-m-d H:i:s', strtotime('+24 hours'));
        
        // Professional HTML Email Template
        $emailSubject = "🔐 Secure Access Code for Audit Documents";
        
        $emailBody = "
        <!DOCTYPE html>
        <html>
        <head>
            <meta charset='UTF-8'>
            <meta name='viewport' content='width=device-width, initial-scale=1.0'>
            <style>
                body { 
                    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; 
                    line-height: 1.6; 
                    color: #1e293b; 
                    margin: 0; 
                    padding: 0; 
                    background-color: #f1f5f9;
                }
                .container { 
                    max-width: 600px; 
                    margin: 20px auto; 
                    background: #ffffff; 
                    border-radius: 16px; 
                    overflow: hidden; 
                    box-shadow: 0 20px 40px rgba(0,0,0,0.08);
                }
                .header { 
                    background: linear-gradient(135deg, #2563eb 0%, #1e40af 100%);
                    padding: 40px 30px; 
                    text-align: center; 
                }
                .header h1 {
                    color: white;
                    margin: 0;
                    font-size: 28px;
                    font-weight: 600;
                    letter-spacing: -0.5px;
                }
                .header p {
                    color: rgba(255,255,255,0.9);
                    margin: 10px 0 0;
                    font-size: 16px;
                }
                .content { 
                    padding: 40px 30px; 
                    background: #ffffff;
                }
                .greeting {
                    font-size: 18px;
                    margin-bottom: 20px;
                }
                .code-container {
                    background: linear-gradient(135deg, #f8fafc 0%, #f1f5f9 100%);
                    border: 2px dashed #2563eb;
                    border-radius: 16px;
                    padding: 30px;
                    text-align: center;
                    margin: 30px 0;
                }
                .code-label {
                    color: #475569;
                    font-size: 14px;
                    text-transform: uppercase;
                    letter-spacing: 2px;
                    margin-bottom: 10px;
                }
                .access-code {
                    font-family: 'Courier New', monospace;
                    font-size: 48px;
                    font-weight: 700;
                    color: #2563eb;
                    background: white;
                    padding: 20px 30px;
                    border-radius: 12px;
                    display: inline-block;
                    box-shadow: 0 4px 6px rgba(37, 99, 235, 0.1);
                    letter-spacing: 4px;
                }
                .access-code span {
                    color: #94a3b8;
                    font-size: 24px;
                }
                .info-grid {
                    display: grid;
                    grid-template-columns: repeat(2, 1fr);
                    gap: 20px;
                    margin: 30px 0;
                    background: #f8fafc;
                    padding: 20px;
                    border-radius: 12px;
                }
                .info-item {
                    text-align: center;
                }
                .info-label {
                    color: #64748b;
                    font-size: 12px;
                    text-transform: uppercase;
                    margin-bottom: 5px;
                }
                .info-value {
                    color: #1e293b;
                    font-size: 16px;
                    font-weight: 600;
                }
                .button {
                    display: inline-block;
                    background: linear-gradient(135deg, #2563eb 0%, #1e40af 100%);
                    color: white;
                    text-decoration: none;
                    padding: 16px 32px;
                    border-radius: 50px;
                    font-weight: 600;
                    margin: 20px 0;
                    box-shadow: 0 10px 20px rgba(37, 99, 235, 0.2);
                    transition: transform 0.2s;
                }
                .button:hover {
                    transform: translateY(-2px);
                }
                .steps {
                    background: #f8fafc;
                    padding: 25px;
                    border-radius: 12px;
                    margin: 30px 0;
                }
                .steps h3 {
                    margin-top: 0;
                    color: #1e293b;
                }
                .steps ol {
                    margin: 0;
                    padding-left: 20px;
                }
                .steps li {
                    margin-bottom: 10px;
                    color: #475569;
                }
                .message-box {
                    background: #eff6ff;
                    border-left: 4px solid #2563eb;
                    padding: 20px;
                    margin: 20px 0;
                    border-radius: 0 8px 8px 0;
                    font-style: italic;
                }
                .footer {
                    background: #1e293b;
                    color: #94a3b8;
                    padding: 30px;
                    text-align: center;
                    font-size: 14px;
                }
                .footer a {
                    color: #94a3b8;
                    text-decoration: none;
                }
                .footer a:hover {
                    color: white;
                }
                .security-badge {
                    display: inline-block;
                    background: rgba(255,255,255,0.1);
                    padding: 8px 16px;
                    border-radius: 50px;
                    font-size: 12px;
                    margin-top: 15px;
                }
            </style>
        </head>
        <body>
            <div class='container'>
                <div class='header'>
                    <h1>🔐 Secure Document Access</h1>
                    <p>Your one-time access code for audit documents</p>
                </div>
                
                <div class='content'>
                    <div class='greeting'>
                        Dear Valued Client,
                    </div>
                    
                    <p>You have been granted secure access to audit documents. Please use the following access code to login to your secure portal.</p>
                    
                    <div class='code-container'>
                        <div class='code-label'>Your Access Code</div>
                        <div class='access-code'>" . $accessCode . "</div>
                        <p style='color: #64748b; margin-top: 15px; font-size: 14px;'>Format: ClientID-XXXX (4-digit code)</p>
                    </div>
                    
                    <div class='info-grid'>
                        <div class='info-item'>
                            <div class='info-label'>Access Expires</div>
                            <div class='info-value'>" . date('M d, Y H:i', strtotime($expiresAt)) . "</div>
                        </div>
                        <div class='info-item'>
                            <div class='info-label'>Session Duration</div>
                            <div class='info-value'>24 Hours</div>
                        </div>
                    </div>
                    
                    " . (!empty($customMessage) ? "
                    <div class='message-box'>
                        <strong>📝 Message from Auditor:</strong><br>
                        " . nl2br(htmlspecialchars($customMessage)) . "
                    </div>" : "") . "
                    
                    <div class='steps'>
                        <h3>📋 How to Access Your Documents:</h3>
                        <ol>
                            <li><strong>Visit the secure portal:</strong><br> 
                                <a href='https://kampalatrafficaiwarningsystem.ugprice.com/client-access.php' style='color: #2563eb;'>https://kampalatrafficaiwarningsystem.ugprice.com/client-access.php</a>
                            </li>
                            <li><strong>Enter your access code:</strong> <code style='background: #e2e8f0; padding: 2px 6px; border-radius: 4px;'>" . $accessCode . "</code></li>
                            <li><strong>You'll be automatically logged in for 24 hours</strong></li>
                            <li><strong>Upload, view, and download documents as needed</strong></li>
                        </ol>
                    </div>
                    
                    <div style='text-align: center;'>
                        <a href='https://kampalatrafficaiwarningsystem.ugprice.com/client-access.php' class='button'>
                            🚀 Access Your Documents
                        </a>
                    </div>
                    
                    <p style='color: #64748b; font-size: 14px; margin-top: 30px;'>
                        ⚠️ This access code is unique and will expire on " . date('M d, Y H:i', strtotime($expiresAt)) . ". 
                        For security reasons, please do not share this code with anyone.
                    </p>
                </div>
                
                <div class='footer'>
                    <p>© " . date('Y') . " Traffic Warning System. All rights reserved.</p>
                    <p>This is an automated message, please do not reply.</p>
                    <div class='security-badge'>
                        🔒 Secured by 256-bit Encryption
                    </div>
                </div>
            </div>
        </body>
        </html>
        ";
        
        // Plain text version
        $plainBody = "SECURE ACCESS CODE\n\n";
        $plainBody .= "Your Access Code: " . $accessCode . "\n";
        $plainBody .= "Expires: " . date('M d, Y H:i', strtotime($expiresAt)) . "\n\n";
        $plainBody .= "How to access:\n";
        $plainBody .= "1. Go to: https://kampalatrafficaiwarningsystem.ugprice.com/client-access.php\n";
        $plainBody .= "2. Enter code: " . $accessCode . "\n";
        $plainBody .= "3. You'll be logged in for 24 hours\n\n";
        if (!empty($customMessage)) {
            $plainBody .= "Message: " . $customMessage . "\n\n";
        }
        
        // Content
        $mail->isHTML(true);
        $mail->Subject = $emailSubject;
        $mail->Body = $emailBody;
        $mail->AltBody = $plainBody;
        
        // Send email
        $mail->send();
        
        $result = "✅ Professional email sent successfully!<br>
                   <strong>Access Code:</strong> $accessCode<br>
                   <strong>Expires:</strong> " . date('M d, Y H:i', strtotime($expiresAt)) . "<br>
                   <strong>Sent to:</strong> $testEmail";
        $resultClass = 'success';
        
    } catch (Exception $e) {
        $result = "❌ Email could not be sent. Error: " . $mail->ErrorInfo;
        $resultClass = 'error';
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Professional PHPMailer Test</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 40px 20px;
            display: flex;
            justify-content: center;
            align-items: center;
        }
        
        .container {
            max-width: 600px;
            width: 100%;
            background: white;
            border-radius: 20px;
            box-shadow: 0 20px 60px rgba(0,0,0,0.3);
            overflow: hidden;
        }
        
        .header {
            background: linear-gradient(135deg, #2563eb 0%, #1e40af 100%);
            color: white;
            padding: 40px 30px;
            text-align: center;
        }
        
        .header h1 {
            font-size: 32px;
            margin-bottom: 10px;
            font-weight: 600;
        }
        
        .header p {
            opacity: 0.9;
            font-size: 16px;
        }
        
        .content {
            padding: 40px 30px;
        }
        
        .info-box {
            background: #f8fafc;
            border-radius: 12px;
            padding: 20px;
            margin-bottom: 30px;
            border-left: 4px solid #2563eb;
        }
        
        .info-box p {
            margin: 5px 0;
            color: #475569;
        }
        
        .form-group {
            margin-bottom: 25px;
        }
        
        label {
            display: block;
            margin-bottom: 8px;
            color: #1e293b;
            font-weight: 600;
            font-size: 14px;
        }
        
        input, textarea {
            width: 100%;
            padding: 14px 16px;
            border: 2px solid #e2e8f0;
            border-radius: 10px;
            font-size: 16px;
            transition: all 0.3s;
            font-family: inherit;
        }
        
        input:focus, textarea:focus {
            outline: none;
            border-color: #2563eb;
            box-shadow: 0 0 0 3px rgba(37, 99, 235, 0.1);
        }
        
        button {
            background: linear-gradient(135deg, #2563eb 0%, #1e40af 100%);
            color: white;
            border: none;
            padding: 16px 32px;
            font-size: 18px;
            font-weight: 600;
            border-radius: 50px;
            cursor: pointer;
            width: 100%;
            transition: transform 0.2s, box-shadow 0.2s;
            box-shadow: 0 10px 20px rgba(37, 99, 235, 0.2);
        }
        
        button:hover {
            transform: translateY(-2px);
            box-shadow: 0 15px 30px rgba(37, 99, 235, 0.3);
        }
        
        .result {
            margin-top: 30px;
            padding: 20px;
            border-radius: 12px;
            display: <?php echo isset($result) ? 'block' : 'none'; ?>;
        }
        
        .result.success {
            background: #f0fdf4;
            border: 1px solid #86efac;
            color: #166534;
        }
        
        .result.error {
            background: #fef2f2;
            border: 1px solid #fecaca;
            color: #991b1b;
        }
        
        .badge {
            display: inline-block;
            background: #e2e8f0;
            color: #475569;
            padding: 6px 12px;
            border-radius: 50px;
            font-size: 12px;
            font-weight: 600;
            margin-top: 10px;
        }
        
        .footer {
            background: #f1f5f9;
            padding: 20px 30px;
            text-align: center;
            color: #64748b;
            font-size: 14px;
            border-top: 1px solid #e2e8f0;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>📧 Professional Email Test</h1>
            <p>PHPMailer with Professional Templates</p>
        </div>
        
        <div class="content">
            <div class="info-box">
                <p><strong>Domain:</strong> kampalatrafficaiwarningsystem.ugprice.com</p>
                <p><strong>Method:</strong> PHPMailer with professional HTML template</p>
                <p><strong>Status:</strong> ✅ Basic mail() working, now testing PHPMailer</p>
            </div>
            
            <?php if (!empty($result)): ?>
                <div class="result <?php echo $resultClass; ?>">
                    <?php echo $result; ?>
                </div>
            <?php endif; ?>
            
            <form method="POST">
                <div class="form-group">
                    <label>📧 Email Address</label>
                    <input type="email" name="email" required placeholder="Enter recipient email" value="<?php echo htmlspecialchars($_POST['email'] ?? ''); ?>">
                </div>
                
                <div class="form-group">
                    <label>📝 Custom Message (Optional)</label>
                    <textarea name="message" rows="4" placeholder="Enter any additional instructions..."><?php echo htmlspecialchars($_POST['message'] ?? ''); ?></textarea>
                </div>
                
                <button type="submit">
                    🚀 Send Professional Email
                </button>
            </form>
            
            <div style="margin-top: 20px; text-align: center;">
                <span class="badge">PHPMailer</span>
                <span class="badge">Professional Template</span>
                <span class="badge">Access Code Format: ClientID-XXXX</span>
            </div>
        </div>
        
        <div class="footer">
            <p>© <?php echo date('Y'); ?> Traffic Warning System. All rights reserved.</p>
            <p style="font-size: 12px; margin-top: 5px;">Using PHPMailer with professional email templates</p>
        </div>
    </div>
</body>
</html>