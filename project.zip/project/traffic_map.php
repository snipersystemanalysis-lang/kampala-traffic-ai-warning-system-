<?php
require_once 'includes/auth.php';
require_once 'includes/header.php';

// Get user role for permissions
$user_role = $_SESSION['role'] ?? 'user';
?>
<style>
:root {
    --sidebar-color: <?php echo $sidebar_color ?? '#343a40'; ?>;
    --primary-gradient: linear-gradient(135deg, var(--sidebar-color) 0%, <?php echo adjustBrightness($sidebar_color ?? '#343a40', -20); ?> 100%);
}

.map-wrapper {
    display: flex;
    min-height: 100vh;
    background: #f0f2f5;
}

.main-content {
    flex: 1;
    margin-left: var(--sidebar-width);
    transition: margin-left 0.3s;
    padding: 30px;
}

/* Modern Card Design */
.modern-card {
    background: white;
    border-radius: 24px;
    box-shadow: 0 10px 40px rgba(0,0,0,0.08);
    overflow: hidden;
    transition: all 0.3s ease;
    border: 1px solid rgba(0,0,0,0.05);
}

/* Header Section */
.map-header {
    padding: 25px;
    border-bottom: 1px solid #eef2f6;
    display: flex;
    align-items: center;
    justify-content: space-between;
    flex-wrap: wrap;
    gap: 20px;
    background: white;
}

.header-title {
    display: flex;
    align-items: center;
    gap: 15px;
}

.header-title i {
    font-size: 32px;
    color: var(--sidebar-color);
    background: rgba(102, 126, 234, 0.1);
    padding: 12px;
    border-radius: 16px;
}

.header-title h1 {
    margin: 0;
    font-size: 28px;
    font-weight: 700;
    background: var(--primary-gradient);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
}

/* Voice Control Button */
.voice-btn {
    background: var(--primary-gradient);
    color: white;
    border: none;
    width: 50px;
    height: 50px;
    border-radius: 50%;
    cursor: pointer;
    transition: all 0.3s;
    box-shadow: 0 4px 15px rgba(102, 126, 234, 0.3);
}

.voice-btn:hover {
    transform: scale(1.1);
}

.voice-btn.listening {
    animation: pulse-voice 1.5s infinite;
    background: #dc2626;
}

@keyframes pulse-voice {
    0%, 100% { transform: scale(1); }
    50% { transform: scale(1.1); }
}

/* Real-time Status Bar */
.realtime-bar {
    background: linear-gradient(135deg, #f8fafc 0%, #f1f5f9 100%);
    padding: 20px 25px;
    border-bottom: 1px solid #eef2f6;
}

.location-display {
    background: white;
    border-radius: 16px;
    padding: 15px 20px;
    box-shadow: 0 4px 15px rgba(0,0,0,0.03);
    display: flex;
    align-items: center;
    gap: 20px;
    flex-wrap: wrap;
}

.location-icon {
    width: 50px;
    height: 50px;
    background: var(--primary-gradient);
    border-radius: 12px;
    display: flex;
    align-items: center;
    justify-content: center;
    color: white;
    font-size: 24px;
}

.location-details {
    flex: 1;
}

.location-name {
    font-size: 1.4rem;
    font-weight: 700;
    color: #1e293b;
    margin-bottom: 5px;
    display: flex;
    align-items: center;
    gap: 10px;
    flex-wrap: wrap;
}

.location-badge {
    background: #f1f5f9;
    color: #475569;
    padding: 4px 12px;
    border-radius: 30px;
    font-size: 0.8rem;
}

.location-coords {
    font-family: 'Courier New', monospace;
    color: #64748b;
    font-size: 0.9rem;
    display: flex;
    gap: 15px;
    flex-wrap: wrap;
}

.coord-badge {
    background: #f1f5f9;
    padding: 4px 12px;
    border-radius: 30px;
    display: inline-flex;
    align-items: center;
    gap: 5px;
}

/* Traffic Status Badge */
.traffic-status-badge {
    padding: 8px 16px;
    border-radius: 40px;
    font-weight: 600;
    font-size: 0.9rem;
    display: inline-flex;
    align-items: center;
    gap: 8px;
}

.traffic-heavy {
    background: #fee2e2;
    color: #dc2626;
    border-left: 4px solid #dc2626;
}

.traffic-moderate {
    background: #fff3cd;
    color: #f59e0b;
    border-left: 4px solid #f59e0b;
}

.traffic-light {
    background: #d1fae5;
    color: #10b981;
    border-left: 4px solid #10b981;
}

.pulse-dot {
    width: 12px;
    height: 12px;
    background: #10b981;
    border-radius: 50%;
    animation: pulse 2s infinite;
    display: inline-block;
    margin-right: 8px;
}

@keyframes pulse {
    0%, 100% { opacity: 1; }
    50% { opacity: 0.5; }
}

/* Weather Widget */
.weather-widget {
    background: linear-gradient(135deg, #1e293b 0%, #0f172a 100%);
    border-radius: 16px;
    padding: 12px 20px;
    display: flex;
    align-items: center;
    gap: 15px;
    color: white;
    box-shadow: 0 5px 15px rgba(0,0,0,0.1);
    min-width: 200px;
    cursor: pointer;
}

.weather-icon {
    font-size: 2rem;
}

.weather-info {
    display: flex;
    flex-direction: column;
}

.weather-temp {
    font-size: 1.2rem;
    font-weight: 700;
}

.weather-desc {
    font-size: 0.8rem;
    opacity: 0.8;
}

/* Search Section */
.search-section {
    padding: 25px;
    border-bottom: 1px solid #eef2f6;
    background: white;
}

.search-container {
    display: flex;
    gap: 15px;
    flex-wrap: wrap;
}

.search-input-wrapper {
    flex: 1;
    position: relative;
    min-width: 300px;
}

.search-input-wrapper i {
    position: absolute;
    left: 15px;
    top: 50%;
    transform: translateY(-50%);
    color: #94a3b8;
    z-index: 2;
}

#searchInput {
    width: 100%;
    padding: 16px 20px 16px 50px;
    border: 2px solid #e2e8f0;
    border-radius: 50px;
    font-size: 1rem;
    transition: all 0.3s;
}

#searchInput:focus {
    outline: none;
    border-color: var(--sidebar-color);
    box-shadow: 0 0 0 4px rgba(102, 126, 234, 0.1);
}

.suggestions-dropdown {
    position: absolute;
    top: 100%;
    left: 0;
    right: 0;
    background: white;
    border-radius: 15px;
    box-shadow: 0 10px 30px rgba(0,0,0,0.15);
    margin-top: 5px;
    max-height: 300px;
    overflow-y: auto;
    z-index: 1000;
    display: none;
}

.suggestions-dropdown.show {
    display: block;
}

.suggestion-item {
    padding: 15px 20px;
    cursor: pointer;
    transition: all 0.2s;
    border-bottom: 1px solid #f1f5f9;
    display: flex;
    align-items: center;
    gap: 12px;
}

.suggestion-item:hover {
    background: #f8fafc;
}

.suggestion-item i {
    color: var(--sidebar-color);
    width: 20px;
}

.suggestion-name {
    font-weight: 500;
    color: #1e293b;
    flex: 1;
}

.suggestion-address {
    font-size: 0.8rem;
    color: #64748b;
}

.suggestion-traffic {
    font-size: 0.75rem;
    padding: 3px 8px;
    border-radius: 20px;
    font-weight: 600;
}

.search-btn {
    padding: 16px 35px;
    background: var(--primary-gradient);
    color: white;
    border: none;
    border-radius: 50px;
    font-weight: 600;
    cursor: pointer;
    display: flex;
    align-items: center;
    gap: 10px;
}

.recent-searches {
    margin-top: 15px;
    display: flex;
    align-items: center;
    gap: 10px;
    flex-wrap: wrap;
}

.recent-label {
    font-size: 0.85rem;
    color: #64748b;
}

.recent-tag {
    padding: 5px 15px;
    background: #f1f5f9;
    border-radius: 30px;
    font-size: 0.85rem;
    cursor: pointer;
    transition: all 0.2s;
    display: flex;
    align-items: center;
    gap: 5px;
}

.recent-tag:hover {
    background: var(--sidebar-color);
    color: white;
}

/* Map Container */
.map-container {
    padding: 0 25px 25px 25px;
    background: white;
    position: relative;
}

#map {
    height: 450px;
    width: 100%;
    border-radius: 20px;
    border: 2px solid white;
    box-shadow: 0 10px 30px rgba(0,0,0,0.1);
    z-index: 1;
}

/* Traffic Legend */
.traffic-legend {
    position: absolute;
    top: 40px;
    right: 40px;
    background: white;
    padding: 15px;
    border-radius: 12px;
    box-shadow: 0 5px 20px rgba(0,0,0,0.15);
    z-index: 10;
}

.legend-item {
    display: flex;
    align-items: center;
    gap: 10px;
    margin-bottom: 8px;
    font-size: 0.85rem;
}

.legend-color {
    width: 20px;
    height: 20px;
    border-radius: 4px;
}

.legend-red { background: #dc2626; }
.legend-orange { background: #f59e0b; }
.legend-green { background: #10b981; }

/* AI Response Section */
.ai-response-section {
    padding: 25px;
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    margin: 0 25px 25px 25px;
    border-radius: 20px;
    color: white;
}

.ai-header {
    display: flex;
    align-items: center;
    gap: 15px;
    margin-bottom: 20px;
}

.ai-header i {
    font-size: 28px;
    background: rgba(255,255,255,0.2);
    padding: 12px;
    border-radius: 16px;
}

.ai-message {
    font-size: 1.1rem;
    line-height: 1.6;
    margin-bottom: 20px;
}

.ai-actions {
    display: flex;
    gap: 15px;
    margin-top: 15px;
    flex-wrap: wrap;
}

.ai-action-btn {
    background: rgba(255,255,255,0.2);
    border: 1px solid rgba(255,255,255,0.3);
    color: white;
    padding: 8px 20px;
    border-radius: 30px;
    cursor: pointer;
    display: flex;
    align-items: center;
    gap: 8px;
}

.ai-confidence {
    display: flex;
    align-items: center;
    gap: 15px;
    background: rgba(255,255,255,0.1);
    padding: 15px;
    border-radius: 15px;
    margin-top: 15px;
    flex-wrap: wrap;
}

.confidence-bar {
    flex: 1;
    height: 8px;
    background: rgba(255,255,255,0.2);
    border-radius: 4px;
    overflow: hidden;
}

.confidence-fill {
    height: 100%;
    background: #ffd700;
    border-radius: 4px;
    width: 0%;
    transition: width 1s ease;
}

/* Charts Grid */
.charts-grid {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: 25px;
    margin: 0 25px 25px 25px;
}

.chart-card {
    background: white;
    border-radius: 20px;
    padding: 20px;
    box-shadow: 0 5px 20px rgba(0,0,0,0.05);
    height: 300px;
}

.chart-header {
    display: flex;
    align-items: center;
    gap: 10px;
    margin-bottom: 15px;
}

.chart-header i {
    font-size: 20px;
    color: var(--sidebar-color);
    background: rgba(102, 126, 234, 0.1);
    padding: 10px;
    border-radius: 12px;
}

.chart-card canvas {
    width: 100% !important;
    height: 220px !important;
}

/* Hotspot Grid */
.hotspot-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
    gap: 20px;
    margin: 0 25px 25px 25px;
}

.hotspot-card {
    background: white;
    border-radius: 16px;
    padding: 20px;
    box-shadow: 0 5px 15px rgba(0,0,0,0.05);
    cursor: pointer;
    transition: all 0.3s;
    border-left: 5px solid transparent;
}

.hotspot-card.red { border-left-color: #dc2626; }
.hotspot-card.orange { border-left-color: #f59e0b; }
.hotspot-card.green { border-left-color: #10b981; }

.hotspot-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 15px 30px rgba(0,0,0,0.1);
}

.hotspot-title {
    display: flex;
    align-items: center;
    justify-content: space-between;
    margin-bottom: 15px;
}

.hotspot-title h5 {
    margin: 0;
    font-weight: 600;
}

.traffic-badge {
    padding: 5px 12px;
    border-radius: 30px;
    font-size: 0.8rem;
    font-weight: 600;
}

.traffic-heavy-badge { background: #fee2e2; color: #991b1b; }
.traffic-moderate-badge { background: #fff3cd; color: #856404; }
.traffic-light-badge { background: #d1fae5; color: #065f46; }

.hotspot-details {
    display: flex;
    justify-content: space-between;
    margin-bottom: 10px;
    font-size: 0.85rem;
    color: #64748b;
}

.hotspot-details span {
    display: flex;
    align-items: center;
    gap: 5px;
}

.hotspot-progress {
    height: 4px;
    background: #e2e8f0;
    border-radius: 2px;
    overflow: hidden;
}

.progress-fill {
    height: 100%;
    background: var(--sidebar-color);
    border-radius: 2px;
    transition: width 0.3s;
}

@media (max-width: 991px) {
    .main-content { margin-left: 0; padding: 20px; }
    .charts-grid { grid-template-columns: 1fr; }
}

@media (max-width: 768px) {
    .traffic-legend { top: 10px; right: 10px; padding: 8px; }
    .legend-item { gap: 5px; margin-bottom: 4px; }
    .legend-color { width: 15px; height: 15px; }
    .hotspot-grid { grid-template-columns: 1fr; }
}
</style>

<?php
function adjustBrightness($hex, $steps) {
    $hex = str_replace('#', '', $hex);
    if (strlen($hex) == 3) {
        $hex = $hex[0].$hex[0].$hex[1].$hex[1].$hex[2].$hex[2];
    }
    $r = hexdec(substr($hex, 0, 2));
    $g = hexdec(substr($hex, 2, 2));
    $b = hexdec(substr($hex, 4, 2));
    $r = max(0, min(255, $r + $steps));
    $g = max(0, min(255, $g + $steps));
    $b = max(0, min(255, $b + $steps));
    return '#' . sprintf("%02x%02x%02x", $r, $g, $b);
}
?>

<div class="map-wrapper">
    <?php require_once 'includes/sidebar.php'; ?>
    
    <div class="main-content">
        <div class="modern-card">
            <!-- Header -->
            <div class="map-header">
                <div class="header-title">
                    <i class="fas fa-map-marked-alt"></i>
                    <h1>AI Traffic Intelligence</h1>
                </div>
                <div class="d-flex align-items-center gap-3">
                    <button class="voice-btn" id="voiceBtn">
                        <i class="fas fa-microphone"></i>
                    </button>
                    <span class="badge bg-success">
                        <i class="fas fa-circle me-1" style="font-size: 8px;"></i>
                        LIVE
                    </span>
                </div>
            </div>
            
            <!-- Real-time Location Display with Traffic Status -->
            <div class="realtime-bar">
                <div class="location-display">
                    <div class="location-icon">
                        <i class="fas fa-location-dot"></i>
                    </div>
                    <div class="location-details">
                        <div class="location-name">
                            <span class="pulse-dot"></span>
                            <span id="locationText">Detecting your location...</span>
                            <span class="location-badge" id="accuracyBadge">High accuracy</span>
                        </div>
                        <div class="location-coords">
                            <span class="coord-badge">
                                <i class="fas fa-map-pin"></i>
                                <span id="coordinates">0.0000, 0.0000</span>
                            </span>
                            <span class="coord-badge">
                                <i class="fas fa-crosshairs"></i>
                                <span id="updateTime">Live</span>
                            </span>
                        </div>
                    </div>
                    <!-- Current Location Traffic Status -->
                    <div class="traffic-status-badge" id="currentTrafficBadge">
                        <i class="fas fa-car"></i>
                        <span id="currentTrafficText">Analyzing...</span>
                    </div>
                    <!-- Weather Widget -->
                    <div class="weather-widget" id="weatherWidget">
                        <div class="weather-icon" id="weatherIcon">
                            <i class="fas fa-cloud-sun"></i>
                        </div>
                        <div class="weather-info">
                            <div class="weather-temp" id="weatherTemp">--°C</div>
                            <div class="weather-desc" id="weatherDesc">Loading...</div>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Search Section -->
            <div class="search-section">
                <div class="search-container">
                    <div class="search-input-wrapper">
                        <i class="fas fa-search"></i>
                        <input type="text" id="searchInput" 
                               placeholder="Search any location... e.g., 'Kampala Road', 'Jinja', 'Entebbe Airport'">
                        <div class="suggestions-dropdown" id="suggestions"></div>
                    </div>
                    <button class="search-btn" id="searchBtn">
                        <i class="fas fa-robot"></i>
                        Ask AI
                    </button>
                </div>
                
                <div class="recent-searches" id="recentSearches">
                    <span class="recent-label">Recent:</span>
                </div>
            </div>
            
            <!-- AI Response Section -->
            <div class="ai-response-section" id="aiResponseSection">
                <div class="ai-header">
                    <i class="fas fa-brain"></i>
                    <h3>AI Traffic Assistant</h3>
                </div>
                <div class="ai-message" id="aiMessage">
                    Hello! I'm your AI traffic assistant. Search any location, and I'll analyze traffic conditions, show you the route, and tell you if it's safe to travel.
                </div>
                <div class="ai-actions" id="aiActions" style="display: none;">
                    <button class="ai-action-btn" onclick="speakResponse()">
                        <i class="fas fa-volume-up"></i> Listen
                    </button>
                    <button class="ai-action-btn" onclick="showRoute()">
                        <i class="fas fa-route"></i> Show Route
                    </button>
                </div>
                <div class="ai-confidence">
                    <i class="fas fa-chart-line"></i>
                    <span>Confidence:</span>
                    <div class="confidence-bar">
                        <div class="confidence-fill" id="aiConfidence" style="width: 95%"></div>
                    </div>
                    <span id="confidenceValue">95%</span>
                </div>
            </div>
            
            <!-- Map Container -->
            <div class="map-container">
                <div class="traffic-legend">
                    <div class="legend-item">
                        <span class="legend-color legend-red"></span>
                        <span>Heavy Traffic - Avoid</span>
                    </div>
                    <div class="legend-item">
                        <span class="legend-color legend-orange"></span>
                        <span>Moderate Traffic - Caution</span>
                    </div>
                    <div class="legend-item">
                        <span class="legend-color legend-green"></span>
                        <span>Light Traffic - Safe</span>
                    </div>
                </div>
                <div id="map"></div>
            </div>
            
            <!-- Charts Grid -->
            <div class="charts-grid">
                <div class="chart-card">
                    <div class="chart-header">
                        <i class="fas fa-chart-bar"></i>
                        <h4>Traffic Volume by Hour</h4>
                    </div>
                    <canvas id="trafficChart"></canvas>
                </div>
                <div class="chart-card">
                    <div class="chart-header">
                        <i class="fas fa-chart-pie"></i>
                        <h4>Congestion Distribution</h4>
                    </div>
                    <canvas id="congestionChart"></canvas>
                </div>
            </div>
            
            <!-- Hotspots Grid -->
            <div class="hotspot-grid" id="hotspotGrid">
                <!-- Populated by JavaScript -->
            </div>
        </div>
    </div>
</div>

<!-- Load Libraries -->
<link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />
<link rel="stylesheet" href="https://unpkg.com/leaflet-routing-machine@3.2.12/dist/leaflet-routing-machine.css" />
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
<script src="https://unpkg.com/leaflet-routing-machine@3.2.12/dist/leaflet-routing-machine.js"></script>
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>

<script>
// Global variables
let map;
let userMarker;
let routingControl;
let currentLocation = { lat: 0.3476, lng: 32.5825 };
let destinationLocation = null;
let destinationMarker = null;
let trafficChart, congestionChart;
let speechSynthesis = window.speechSynthesis;
let speechUtterance = null;
let searchTimeout;
let recentSearches = JSON.parse(localStorage.getItem('recentSearches') || '[]');
let locationWatchId = null;
let allMarkers = []; // Store all markers for traffic status updates

// Traffic data for different areas (simulated real-time data)
const trafficDatabase = {
    // Format: { lat_range, lng_range, baseTraffic, peakHourMultiplier }
    kampalaCentral: { latMin: 0.30, latMax: 0.35, lngMin: 32.57, lngMax: 32.60, base: 'heavy', peakMultiplier: 1.3 },
    kampalaRoad: { latMin: 0.312, latMax: 0.315, lngMin: 32.580, lngMax: 32.583, base: 'heavy', peakMultiplier: 1.5 },
    jinjaRoad: { latMin: 0.320, latMax: 0.330, lngMin: 32.585, lngMax: 32.595, base: 'moderate', peakMultiplier: 1.2 },
    northernBypass: { latMin: 0.345, latMax: 0.355, lngMin: 32.590, lngMax: 32.600, base: 'heavy', peakMultiplier: 1.4 },
    entebbeRoad: { latMin: 0.280, latMax: 0.295, lngMin: 32.555, lngMax: 32.570, base: 'light', peakMultiplier: 1.1 },
    kiu: { latMin: 0.328, latMax: 0.335, lngMin: 32.575, lngMax: 32.582, base: 'moderate', peakMultiplier: 1.2 },
    suburbs: { latMin: 0.36, latMax: 0.40, lngMin: 32.55, lngMax: 32.65, base: 'light', peakMultiplier: 1.0 },
    industrial: { latMin: 0.31, latMax: 0.34, lngMin: 32.60, lngMax: 32.63, base: 'moderate', peakMultiplier: 1.25 }
};

// Weather API simulation
function getWeatherForLocation(lat, lng) {
    const weatherConditions = [
        { main: 'Clear', description: 'clear sky', temp: 28, feels_like: 27, humidity: 65, wind_speed: 12 },
        { main: 'Clouds', description: 'scattered clouds', temp: 26, feels_like: 25, humidity: 70, wind_speed: 15 },
        { main: 'Rain', description: 'light rain', temp: 23, feels_like: 24, humidity: 85, wind_speed: 18 }
    ];
    let hash = Math.abs(Math.floor((lat * lng * 1000) % weatherConditions.length));
    let weather = { ...weatherConditions[hash] };
    let hour = new Date().getHours();
    if (hour > 19 || hour < 6) weather.temp -= 5;
    return weather;
}

// Get traffic level for any location (based on coordinates and time)
function getTrafficLevel(lat, lng) {
    let hour = new Date().getHours();
    let isPeakHour = (hour >= 7 && hour <= 9) || (hour >= 17 && hour <= 19);
    
    // Check which zone the location falls into
    let zone = null;
    for (let z in trafficDatabase) {
        let zData = trafficDatabase[z];
        if (lat >= zData.latMin && lat <= zData.latMax && 
            lng >= zData.lngMin && lng <= zData.lngMax) {
            zone = zData;
            break;
        }
    }
    
    if (!zone) {
        // Default for unknown areas
        return Math.random() > 0.6 ? 'light' : (Math.random() > 0.5 ? 'moderate' : 'heavy');
    }
    
    let baseLevel = zone.base;
    
    // Adjust based on peak hour
    if (isPeakHour) {
        if (baseLevel === 'light') return Math.random() > 0.7 ? 'moderate' : 'light';
        if (baseLevel === 'moderate') return Math.random() > 0.6 ? 'heavy' : 'moderate';
        return 'heavy';
    }
    
    // Add some randomness for realism
    let random = Math.random();
    if (baseLevel === 'heavy') {
        if (random < 0.2) return 'moderate';
        return 'heavy';
    } else if (baseLevel === 'moderate') {
        if (random < 0.3) return 'light';
        if (random > 0.7) return 'heavy';
        return 'moderate';
    } else {
        if (random < 0.2) return 'moderate';
        return 'light';
    }
}

// Get congestion percentage from traffic level
function getCongestionFromTraffic(trafficLevel) {
    switch(trafficLevel) {
        case 'heavy': return Math.floor(Math.random() * 20) + 75;
        case 'moderate': return Math.floor(Math.random() * 25) + 45;
        default: return Math.floor(Math.random() * 25) + 15;
    }
}

// Get color for traffic level
function getTrafficColor(trafficLevel) {
    switch(trafficLevel) {
        case 'heavy': return '#dc2626';
        case 'moderate': return '#f59e0b';
        default: return '#10b981';
    }
}

// Create a traffic marker for any location
function createTrafficMarker(lat, lng, locationName, showPopup = true) {
    let trafficLevel = getTrafficLevel(lat, lng);
    let congestion = getCongestionFromTraffic(trafficLevel);
    let color = getTrafficColor(trafficLevel);
    let weather = getWeatherForLocation(lat, lng);
    
    // Determine icon based on traffic level
    let trafficIconHtml = '';
    if (trafficLevel === 'heavy') {
        trafficIconHtml = '<i class="fas fa-exclamation-triangle" style="font-size: 12px;"></i>';
    } else if (trafficLevel === 'moderate') {
        trafficIconHtml = '<i class="fas fa-clock" style="font-size: 12px;"></i>';
    } else {
        trafficIconHtml = '<i class="fas fa-check-circle" style="font-size: 12px;"></i>';
    }
    
    const markerIcon = L.divIcon({
        className: 'traffic-marker',
        html: `<div style="background: ${color}; width: 28px; height: 28px; border-radius: 50%; border: 3px solid white; box-shadow: 0 0 15px ${color}; display: flex; align-items: center; justify-content: center; color: white; font-size: 12px;">${trafficIconHtml}</div>`,
        iconSize: [28, 28],
        iconAnchor: [14, 14],
        popupAnchor: [0, -14]
    });
    
    const marker = L.marker([lat, lng], { icon: markerIcon }).addTo(map);
    
    if (showPopup) {
        let trafficText = trafficLevel === 'heavy' ? '🔴 Heavy Traffic' : (trafficLevel === 'moderate' ? '🟠 Moderate Traffic' : '🟢 Light Traffic');
        let adviceText = trafficLevel === 'heavy' ? '⚠️ Avoid if possible' : (trafficLevel === 'moderate' ? '⚠️ Expect delays' : '✅ Safe to travel');
        
        const popupContent = `
            <div style="min-width: 200px;">
                <strong><i class="fas fa-map-marker-alt"></i> ${locationName}</strong><br>
                <div style="margin-top: 8px;">
                    <span style="color: ${color}; font-weight: bold;">${trafficText}</span><br>
                    <span>📊 Congestion: ${congestion}%</span><br>
                    <span>🌡️ Weather: ${Math.round(weather.temp)}°C, ${weather.description}</span><br>
                    <span>💡 ${adviceText}</span>
                </div>
            </div>
        `;
        marker.bindPopup(popupContent);
    }
    
    // Store traffic data on marker for updates
    marker.trafficData = { trafficLevel, congestion, locationName };
    allMarkers.push(marker);
    
    return marker;
}

// Update traffic status on all markers (simulate real-time changes)
function updateAllTrafficStatuses() {
    allMarkers.forEach(marker => {
        if (marker.getLatLng) {
            let latlng = marker.getLatLng();
            let newTraffic = getTrafficLevel(latlng.lat, latlng.lng);
            let newCongestion = getCongestionFromTraffic(newTraffic);
            let newColor = getTrafficColor(newTraffic);
            
            // Update marker appearance
            let trafficIconHtml = '';
            if (newTraffic === 'heavy') {
                trafficIconHtml = '<i class="fas fa-exclamation-triangle" style="font-size: 12px;"></i>';
            } else if (newTraffic === 'moderate') {
                trafficIconHtml = '<i class="fas fa-clock" style="font-size: 12px;"></i>';
            } else {
                trafficIconHtml = '<i class="fas fa-check-circle" style="font-size: 12px;"></i>';
            }
            
            const newIcon = L.divIcon({
                className: 'traffic-marker',
                html: `<div style="background: ${newColor}; width: 28px; height: 28px; border-radius: 50%; border: 3px solid white; box-shadow: 0 0 15px ${newColor}; display: flex; align-items: center; justify-content: center; color: white; font-size: 12px;">${trafficIconHtml}</div>`,
                iconSize: [28, 28],
                iconAnchor: [14, 14]
            });
            marker.setIcon(newIcon);
            
            // Update popup content if popup is open
            let locationName = marker.trafficData?.locationName || 'Location';
            let trafficText = newTraffic === 'heavy' ? '🔴 Heavy Traffic' : (newTraffic === 'moderate' ? '🟠 Moderate Traffic' : '🟢 Light Traffic');
            let adviceText = newTraffic === 'heavy' ? '⚠️ Avoid if possible' : (newTraffic === 'moderate' ? '⚠️ Expect delays' : '✅ Safe to travel');
            let weather = getWeatherForLocation(latlng.lat, latlng.lng);
            
            marker._popup?.setContent(`
                <div style="min-width: 200px;">
                    <strong><i class="fas fa-map-marker-alt"></i> ${locationName}</strong><br>
                    <div style="margin-top: 8px;">
                        <span style="color: ${newColor}; font-weight: bold;">${trafficText}</span><br>
                        <span>📊 Congestion: ${newCongestion}%</span><br>
                        <span>🌡️ Weather: ${Math.round(weather.temp)}°C, ${weather.description}</span><br>
                        <span>💡 ${adviceText}</span>
                    </div>
                </div>
            `);
            
            marker.trafficData = { trafficLevel: newTraffic, congestion: newCongestion, locationName };
        }
    });
}

$(document).ready(function() {
    initMap();
    initCharts();
    startLocationTracking();
    loadHotspots();
    displayRecentSearches();
    
    // Update traffic status every 30 seconds (simulate real-time)
    setInterval(updateAllTrafficStatuses, 30000);
    
    $('#searchBtn').click(function() {
        let query = $('#searchInput').val();
        if (query.trim()) searchLocation(query);
    });
    
    $('#searchInput').on('input', function() {
        let query = $(this).val();
        if (query.length > 2) {
            clearTimeout(searchTimeout);
            searchTimeout = setTimeout(() => getSuggestions(query), 500);
        } else {
            $('#suggestions').removeClass('show');
        }
    });
    
    $('#searchInput').keypress(function(e) {
        if (e.which == 13 && $('#searchInput').val().trim()) {
            searchLocation($('#searchInput').val());
        }
    });
    
    $('#voiceBtn').click(function() {
        if (window.SpeechRecognition || window.webkitSpeechRecognition) {
            const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
            const recognition = new SpeechRecognition();
            recognition.continuous = false;
            recognition.lang = 'en-US';
            $(this).addClass('listening');
            recognition.start();
            recognition.onresult = function(event) {
                $('#searchInput').val(event.results[0][0].transcript);
                $('#voiceBtn').removeClass('listening');
                searchLocation(event.results[0][0].transcript);
            };
            recognition.onerror = function() {
                $('#voiceBtn').removeClass('listening');
                alert('Could not understand. Please type your question.');
            };
        } else {
            alert('Voice recognition not supported. Please type your question.');
        }
    });
});

// Initialize map
function initMap() {
    map = L.map('map').setView([currentLocation.lat, currentLocation.lng], 13);
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '&copy; OpenStreetMap'
    }).addTo(map);
}

// Start location tracking with traffic status for current location
function startLocationTracking() {
    if (navigator.geolocation) {
        locationWatchId = navigator.geolocation.watchPosition(
            function(position) {
                currentLocation = {
                    lat: position.coords.latitude,
                    lng: position.coords.longitude
                };
                
                updateLocationUI();
                getPlaceName(currentLocation.lat, currentLocation.lng);
                
                // Update current location marker with traffic status
                if (userMarker) map.removeLayer(userMarker);
                
                let trafficLevel = getTrafficLevel(currentLocation.lat, currentLocation.lng);
                let trafficColor = getTrafficColor(trafficLevel);
                let congestion = getCongestionFromTraffic(trafficLevel);
                
                // Update UI traffic badge
                let badgeClass = trafficLevel === 'heavy' ? 'traffic-heavy' : (trafficLevel === 'moderate' ? 'traffic-moderate' : 'traffic-light');
                let trafficText = trafficLevel === 'heavy' ? 'Heavy Traffic' : (trafficLevel === 'moderate' ? 'Moderate Traffic' : 'Light Traffic');
                let trafficIcon = trafficLevel === 'heavy' ? 'fa-exclamation-triangle' : (trafficLevel === 'moderate' ? 'fa-clock' : 'fa-check-circle');
                $('#currentTrafficBadge').removeClass('traffic-heavy traffic-moderate traffic-light').addClass(badgeClass);
                $('#currentTrafficText').html(`<i class="fas ${trafficIcon}"></i> ${trafficText} (${congestion}%)`);
                
                const userIcon = L.divIcon({
                    className: 'user-marker',
                    html: `<div style="background: ${trafficColor}; width: 20px; height: 20px; border-radius: 50%; border: 3px solid white; box-shadow: 0 0 20px ${trafficColor};"></div>`,
                    iconSize: [20, 20],
                    iconAnchor: [10, 10]
                });
                
                userMarker = L.marker([currentLocation.lat, currentLocation.lng], { icon: userIcon }).addTo(map);
                
                let weather = getWeatherForLocation(currentLocation.lat, currentLocation.lng);
                $('#weatherIcon').html(`<i class="fas ${weather.main === 'Clear' ? 'fa-sun' : (weather.main === 'Rain' ? 'fa-cloud-rain' : 'fa-cloud')}"></i>`);
                $('#weatherTemp').text(`${Math.round(weather.temp)}°C`);
                $('#weatherDesc').text(weather.description);
                
                map.setView([currentLocation.lat, currentLocation.lng], 15);
            },
            function(error) {
                console.log("Location error:", error);
                $('#locationText').text('Using default location (Kampala)');
                let defaultTraffic = getTrafficLevel(currentLocation.lat, currentLocation.lng);
                let defaultColor = getTrafficColor(defaultTraffic);
                const userIcon = L.divIcon({
                    html: `<div style="background: ${defaultColor}; width: 20px; height: 20px; border-radius: 50%; border: 3px solid white; box-shadow: 0 0 20px ${defaultColor};"></div>`,
                    iconSize: [20, 20],
                    iconAnchor: [10, 10]
                });
                userMarker = L.marker([currentLocation.lat, currentLocation.lng], { icon: userIcon }).addTo(map);
            }
        );
    } else {
        $('#locationText').text('Geolocation not supported');
    }
}

// Get place name from coordinates
function getPlaceName(lat, lng) {
    $.ajax({
        url: 'https://nominatim.openstreetmap.org/reverse',
        data: { format: 'json', lat: lat, lon: lng, zoom: 18, addressdetails: 1 },
        success: function(data) {
            if (data && data.address) {
                let locationName = data.address.road || data.address.suburb || data.address.city || data.display_name.split(',')[0];
                $('#locationText').text(locationName);
                
                // Update user marker popup with traffic info
                let trafficLevel = getTrafficLevel(lat, lng);
                let trafficText = trafficLevel === 'heavy' ? 'Heavy Traffic' : (trafficLevel === 'moderate' ? 'Moderate Traffic' : 'Light Traffic');
                let weather = getWeatherForLocation(lat, lng);
                userMarker.bindPopup(`
                    <b>Your Location</b><br>
                    ${locationName}<br><br>
                    <b>🚦 Traffic:</b> ${trafficText}<br>
                    <b>🌡️ Weather:</b> ${Math.round(weather.temp)}°C, ${weather.description}
                `);
            }
        }
    });
}

// Update location UI
function updateLocationUI() {
    $('#coordinates').text(`${currentLocation.lat.toFixed(6)}, ${currentLocation.lng.toFixed(6)}`);
    $('#updateTime').text(new Date().toLocaleTimeString());
}

// Get location suggestions with traffic prediction
function getSuggestions(query) {
    $.ajax({
        url: 'https://nominatim.openstreetmap.org/search',
        data: { format: 'json', q: query, limit: 5, countrycodes: 'ug', addressdetails: 1, dedupe: 1 },
        timeout: 10000,
        success: function(data) {
            if (data && data.length > 0) {
                let html = '';
                data.forEach(item => {
                    let lat = parseFloat(item.lat);
                    let lng = parseFloat(item.lon);
                    let trafficLevel = getTrafficLevel(lat, lng);
                    let trafficClass = trafficLevel === 'heavy' ? 'traffic-heavy-badge' : (trafficLevel === 'moderate' ? 'traffic-moderate-badge' : 'traffic-light-badge');
                    let trafficIcon = trafficLevel === 'heavy' ? '🔴' : (trafficLevel === 'moderate' ? '🟠' : '🟢');
                    let displayName = item.display_name.split(',').slice(0, 3).join(',');
                    html += `
                        <div class="suggestion-item" onclick="selectSuggestion('${item.display_name.replace(/'/g, "\\'")}', ${lat}, ${lng})">
                            <i class="fas fa-map-marker-alt"></i>
                            <span class="suggestion-name">${item.display_name.split(',')[0]}</span>
                            <span class="suggestion-address">${displayName}</span>
                            <span class="suggestion-traffic ${trafficClass}">${trafficIcon} ${trafficLevel}</span>
                        </div>
                    `;
                });
                $('#suggestions').html(html).addClass('show');
            } else {
                $('#suggestions').removeClass('show');
            }
        },
        error: function() {
            $('#suggestions').removeClass('show');
        }
    });
}

// Select suggestion
function selectSuggestion(name, lat, lng) {
    $('#searchInput').val(name.split(',')[0]);
    $('#suggestions').removeClass('show');
    addRecentSearch(name.split(',')[0], lat, lng);
    searchLocation(name);
}

// Add to recent searches
function addRecentSearch(name, lat, lng) {
    recentSearches.unshift({ name, lat, lng, time: new Date().getTime() });
    recentSearches = recentSearches.slice(0, 5);
    localStorage.setItem('recentSearches', JSON.stringify(recentSearches));
    displayRecentSearches();
}

// Display recent searches
function displayRecentSearches() {
    if (recentSearches.length > 0) {
        let html = '<span class="recent-label">Recent:</span>';
        recentSearches.forEach(search => {
            let trafficLevel = getTrafficLevel(search.lat, search.lng);
            let trafficIcon = trafficLevel === 'heavy' ? '🔴' : (trafficLevel === 'moderate' ? '🟠' : '🟢');
            html += `
                <span class="recent-tag" onclick="quickSearch('${search.name}', ${search.lat}, ${search.lng})">
                    <i class="fas fa-history"></i> ${search.name} ${trafficIcon}
                </span>
            `;
        });
        $('#recentSearches').html(html);
    }
}

// Quick search from recent
function quickSearch(name, lat, lng) {
    $('#searchInput').val(name);
    selectSuggestion(name, lat, lng);
}

// Search location and show traffic status
function searchLocation(query) {
    $('#aiMessage').html('<i class="fas fa-spinner fa-spin me-2"></i> Analyzing traffic conditions...');
    $('#aiActions').hide();
    
    if (routingControl) map.removeControl(routingControl);
    if (destinationMarker) map.removeLayer(destinationMarker);
    
    $.ajax({
        url: 'https://nominatim.openstreetmap.org/search',
        data: { format: 'json', q: query, limit: 1, addressdetails: 1, countrycodes: 'ug' },
        timeout: 10000,
        success: function(data) {
            if (data && data.length > 0) {
                let location = data[0];
                destinationLocation = {
                    lat: parseFloat(location.lat),
                    lng: parseFloat(location.lon),
                    name: location.display_name.split(',')[0],
                    fullName: location.display_name
                };
                
                // Create traffic marker for destination
                destinationMarker = createTrafficMarker(destinationLocation.lat, destinationLocation.lng, destinationLocation.name, true);
                
                addRecentSearch(destinationLocation.name, destinationLocation.lat, destinationLocation.lng);
                
                setTimeout(() => {
                    let response = generateAIResponse();
                    $('#aiMessage').html(response.message);
                    $('#aiConfidence').css('width', response.confidence + '%');
                    $('#confidenceValue').text(response.confidence + '%');
                    $('#aiActions').show();
                    showRoute();
                }, 500);
            } else {
                $('#aiMessage').html('❌ Location not found. Please try a different search term.');
            }
        },
        error: function() {
            $('#aiMessage').html('❌ Network error. Please check your connection.');
        }
    });
}

// Generate AI response with traffic analysis
function generateAIResponse() {
    if (!destinationLocation) {
        return { message: '❌ Please search for a location first.', confidence: 0 };
    }
    
    let distance = calculateDistance(currentLocation.lat, currentLocation.lng, destinationLocation.lat, destinationLocation.lng);
    let trafficLevel = getTrafficLevel(destinationLocation.lat, destinationLocation.lng);
    let congestion = getCongestionFromTraffic(trafficLevel);
    let weather = getWeatherForLocation(destinationLocation.lat, destinationLocation.lng);
    
    let baseTime = distance * 2;
    let trafficMultiplier = trafficLevel === 'heavy' ? 3 : (trafficLevel === 'moderate' ? 2 : 1.5);
    let travelTime = Math.round(baseTime * trafficMultiplier);
    
    let message = `<strong>📍 Destination:</strong> ${destinationLocation.name}<br>`;
    message += `<strong>📏 Distance:</strong> ${distance} km<br>`;
    message += `<strong>⏱️ Estimated travel time:</strong> ${travelTime} minutes<br>`;
    message += `<strong>🌡️ Weather at destination:</strong> ${Math.round(weather.temp)}°C, ${weather.description}<br><br>`;
    
    let confidence = 0;
    
    if (trafficLevel === 'heavy') {
        message += `<strong>🚦 Traffic Alert:</strong> 🔴 HEAVY TRAFFIC detected at this location!<br>`;
        message += `<strong>📊 Congestion level:</strong> ${congestion}%<br>`;
        message += `<strong>⚠️ Recommendation:</strong> NOT RECOMMENDED to travel to this area now. Consider alternative times.`;
        confidence = 92;
    } else if (trafficLevel === 'moderate') {
        message += `<strong>🚦 Traffic Update:</strong> 🟠 MODERATE TRAFFIC conditions<br>`;
        message += `<strong>📊 Congestion level:</strong> ${congestion}%<br>`;
        message += `<strong>⚠️ Recommendation:</strong> Safe to travel but expect some delays.`;
        confidence = 88;
    } else {
        message += `<strong>🚦 Traffic Update:</strong> 🟢 LIGHT TRAFFIC conditions<br>`;
        message += `<strong>📊 Congestion level:</strong> ${congestion}%<br>`;
        message += `<strong>✅ Recommendation:</strong> Safe to travel - Good driving conditions.`;
        confidence = 95;
    }
    
    return { message, confidence };
}

// Calculate distance between two points
function calculateDistance(lat1, lon1, lat2, lon2) {
    const R = 6371;
    const dLat = (lat2 - lat1) * Math.PI / 180;
    const dLon = (lon2 - lon1) * Math.PI / 180;
    const a = Math.sin(dLat/2) * Math.sin(dLat/2) +
              Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
              Math.sin(dLon/2) * Math.sin(dLon/2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
    return Math.round(R * c * 10) / 10;
}

// Show route with traffic-based color
function showRoute() {
    if (!destinationLocation) {
        alert('Please search for a destination first');
        return;
    }
    
    if (routingControl) map.removeControl(routingControl);
    
    let trafficColor = getTrafficColor(getTrafficLevel(destinationLocation.lat, destinationLocation.lng));
    
    routingControl = L.Routing.control({
        waypoints: [L.latLng(currentLocation.lat, currentLocation.lng), L.latLng(destinationLocation.lat, destinationLocation.lng)],
        routeWhileDragging: false,
        showAlternatives: true,
        lineOptions: {
            styles: [{color: trafficColor, opacity: 1, weight: 5}]
        },
        createMarker: function() { return null; }
    }).addTo(map);
    
    let bounds = L.latLngBounds([currentLocation, destinationLocation]);
    map.fitBounds(bounds, { padding: [50, 50] });
}

// Speak response
function speakResponse() {
    let message = $('#aiMessage').html();
    let tempDiv = document.createElement('div');
    tempDiv.innerHTML = message;
    let plainText = tempDiv.textContent || tempDiv.innerText || '';
    
    if (speechSynthesis) {
        if (speechUtterance) speechSynthesis.cancel();
        speechUtterance = new SpeechSynthesisUtterance(plainText);
        speechUtterance.rate = 0.9;
        speechSynthesis.speak(speechUtterance);
    } else {
        alert('Text-to-speech not supported');
    }
}

// Initialize charts
function initCharts() {
    const trafficCtx = document.getElementById('trafficChart').getContext('2d');
    trafficChart = new Chart(trafficCtx, {
        type: 'line',
        data: {
            labels: ['6 AM', '8 AM', '10 AM', '12 PM', '2 PM', '4 PM', '6 PM', '8 PM'],
            datasets: [{ label: 'Traffic Volume', data: [25, 85, 55, 52, 62, 75, 92, 35], borderColor: '#667eea', backgroundColor: 'rgba(102, 126, 234, 0.1)', tension: 0.4, fill: true }]
        },
        options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { display: false } } }
    });
    
    const congCtx = document.getElementById('congestionChart').getContext('2d');
    congestionChart = new Chart(congCtx, {
        type: 'doughnut',
        data: { labels: ['Heavy', 'Moderate', 'Light'], datasets: [{ data: [35, 45, 20], backgroundColor: ['#dc2626', '#f59e0b', '#10b981'], borderWidth: 0 }] },
        options: { responsive: true, maintainAspectRatio: false, cutout: '70%', plugins: { legend: { position: 'bottom' } } }
    });
}

// Load hotspots with traffic markers
function loadHotspots() {
    let hotspots = [
        { name: 'Kampala Road', lat: 0.3136, lng: 32.5811 },
        { name: 'Jinja Road', lat: 0.3248, lng: 32.5919 },
        { name: 'Northern Bypass', lat: 0.3502, lng: 32.5967 },
        { name: 'Entebbe Road', lat: 0.2890, lng: 32.5624 },
        { name: 'Kampala International University (KIU)', lat: 0.3312, lng: 32.5789 }
    ];
    
    let html = '';
    hotspots.forEach(hotspot => {
        let trafficLevel = getTrafficLevel(hotspot.lat, hotspot.lng);
        let congestion = getCongestionFromTraffic(trafficLevel);
        let color = getTrafficColor(trafficLevel);
        let cardClass = trafficLevel === 'heavy' ? 'red' : (trafficLevel === 'moderate' ? 'orange' : 'green');
        let badgeClass = trafficLevel === 'heavy' ? 'traffic-heavy-badge' : (trafficLevel === 'moderate' ? 'traffic-moderate-badge' : 'traffic-light-badge');
        let weather = getWeatherForLocation(hotspot.lat, hotspot.lng);
        
        // Create traffic marker on map
        createTrafficMarker(hotspot.lat, hotspot.lng, hotspot.name, true);
        
        html += `
            <div class="hotspot-card ${cardClass}" onclick="quickSearch('${hotspot.name}', ${hotspot.lat}, ${hotspot.lng})">
                <div class="hotspot-title">
                    <h5><i class="fas fa-map-pin me-2" style="color: ${color}"></i>${hotspot.name}</h5>
                    <span class="traffic-badge ${badgeClass}">${trafficLevel}</span>
                </div>
                <div class="hotspot-details">
                    <span><i class="fas fa-chart-line"></i> ${congestion}% congestion</span>
                    <span><i class="fas ${weather.main === 'Clear' ? 'fa-sun' : 'fa-cloud'}"></i> ${Math.round(weather.temp)}°C</span>
                </div>
                <div class="hotspot-progress">
                    <div class="progress-fill" style="width: ${congestion}%"></div>
                </div>
            </div>
        `;
    });
    
    $('#hotspotGrid').html(html);
}

// Clean up
$(window).on('beforeunload', function() {
    if (locationWatchId) navigator.geolocation.clearWatch(locationWatchId);
});
</script>

<?php require_once 'includes/footer.php'; ?>