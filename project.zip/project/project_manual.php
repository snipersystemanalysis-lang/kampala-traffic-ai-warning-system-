<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kampala Traffic Predictor - Project Manual</title>
    <style>
        @page {
            size: A4;
            margin: 20mm;
        }

        * {
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            line-height: 1.6;
            color: #333;
            max-width: 210mm;
            margin: 0 auto;
            padding: 20px;
            background: #fff;
        }

        h1 {
            color: #0d6efd;
            border-bottom: 3px solid #0d6efd;
            padding-bottom: 10px;
            margin-top: 30px;
            page-break-after: avoid;
        }

        h2 {
            color: #198754;
            border-bottom: 2px solid #198754;
            padding-bottom: 5px;
            margin-top: 25px;
            page-break-after: avoid;
        }

        h3 {
            color: #0dcaf0;
            margin-top: 20px;
            page-break-after: avoid;
        }

        h4 {
            color: #6c757d;
            margin-top: 15px;
        }

        .cover-page {
            text-align: center;
            padding: 100px 20px;
            page-break-after: always;
        }

        .cover-page h1 {
            font-size: 48px;
            border: none;
            margin: 40px 0;
        }

        .cover-page h2 {
            font-size: 24px;
            border: none;
            color: #6c757d;
            font-weight: normal;
        }

        .cover-page .version {
            margin-top: 50px;
            font-size: 18px;
            color: #6c757d;
        }

        code {
            background: #f4f4f4;
            padding: 2px 6px;
            border-radius: 3px;
            font-family: 'Courier New', monospace;
            font-size: 0.9em;
        }

        pre {
            background: #f4f4f4;
            padding: 15px;
            border-left: 4px solid #0d6efd;
            overflow-x: auto;
            page-break-inside: avoid;
        }

        pre code {
            background: transparent;
            padding: 0;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin: 15px 0;
            page-break-inside: avoid;
        }

        th, td {
            border: 1px solid #ddd;
            padding: 10px;
            text-align: left;
        }

        th {
            background: #0d6efd;
            color: white;
            font-weight: bold;
        }

        tr:nth-child(even) {
            background: #f9f9f9;
        }

        .diagram {
            background: #f8f9fa;
            padding: 20px;
            border: 2px solid #dee2e6;
            border-radius: 5px;
            margin: 20px 0;
            font-family: monospace;
            white-space: pre;
            overflow-x: auto;
            page-break-inside: avoid;
        }

        .alert {
            padding: 15px;
            margin: 15px 0;
            border-radius: 5px;
            page-break-inside: avoid;
        }

        .alert-info {
            background: #d1ecf1;
            border-left: 4px solid #0dcaf0;
        }

        .alert-success {
            background: #d1e7dd;
            border-left: 4px solid #198754;
        }

        .alert-warning {
            background: #fff3cd;
            border-left: 4px solid #ffc107;
        }

        ul, ol {
            margin: 10px 0;
            padding-left: 30px;
        }

        li {
            margin: 5px 0;
        }

        .toc {
            background: #f8f9fa;
            padding: 20px;
            border-radius: 5px;
            margin: 30px 0;
            page-break-after: always;
        }

        .toc h2 {
            margin-top: 0;
        }

        .toc ul {
            list-style: none;
            padding-left: 0;
        }

        .toc li {
            margin: 8px 0;
        }

        .toc a {
            color: #0d6efd;
            text-decoration: none;
        }

        .section {
            page-break-before: auto;
            margin: 30px 0;
        }

        @media print {
            body {
                padding: 0;
            }

            .no-print {
                display: none;
            }

            h1, h2, h3, h4 {
                page-break-after: avoid;
            }

            pre, table, .diagram, .alert {
                page-break-inside: avoid;
            }
        }
    </style>
</head>
<body>
    <div class="cover-page">
        <h1>Kampala Traffic Predictor</h1>
        <h2>Professional Project Manual & Technical Blueprint</h2>
        <div class="version">
            <p><strong>Version:</strong> 1.0</p>
            <p><strong>Last Updated:</strong> 2024</p>
            <p><strong>Architecture:</strong> Three-Tier Web Application</p>
        </div>
    </div>

    <div class="toc">
        <h2>Table of Contents</h2>
        <ul>
            <li>1. <a href="#executive-summary">Executive Summary</a></li>
            <li>2. <a href="#system-architecture">System Architecture Overview</a></li>
            <li>3. <a href="#technology-stack">Technology Stack</a></li>
            <li>4. <a href="#database-structure">Database Structure</a></li>
            <li>5. <a href="#security">Security Implementation</a></li>
            <li>6. <a href="#realtime">Real-Time Features</a></li>
            <li>7. <a href="#frontend">Frontend Architecture</a></li>
            <li>8. <a href="#backend">Backend Architecture</a></li>
            <li>9. <a href="#api">API Documentation</a></li>
            <li>10. <a href="#roles">User Roles & Access Control</a></li>
            <li>11. <a href="#features">System Features</a></li>
            <li>12. <a href="#installation">Installation & Setup</a></li>
            <li>13. <a href="#file-structure">File Structure</a></li>
            <li>14. <a href="#best-practices">Security Best Practices</a></li>
            <li>15. <a href="#future">Future Enhancements</a></li>
        </ul>
    </div>

    <div class="section" id="executive-summary">
        <h1>1. Executive Summary</h1>

        <p>The <strong>Kampala Traffic Predictor System</strong> is a web-based application designed to predict and manage traffic congestion in Kampala, Uganda. The system leverages real-time traffic data, historical patterns, and predictive algorithms to help users avoid congested routes and make informed travel decisions.</p>

        <h3>Key Objectives</h3>
        <ul>
            <li>Predict traffic congestion at major hotspots in Kampala</li>
            <li>Provide real-time traffic updates and alerts</li>
            <li>Suggest alternative routes during peak hours</li>
            <li>Enable user-generated traffic reports</li>
            <li>Visualize traffic patterns through interactive maps and analytics</li>
        </ul>

        <h3>Target Users</h3>
        <ul>
            <li><strong>General Users:</strong> Citizens who need traffic information for daily commutes</li>
            <li><strong>System Administrators:</strong> Manage hotspots, approve reports, and analyze traffic data</li>
        </ul>
    </div>

    <div class="section" id="system-architecture">
        <h1>2. System Architecture Overview</h1>

        <h3>Architecture Type: Three-Tier Architecture</h3>

        <div class="diagram">┌─────────────────────────────────────────────────────────────┐
│                     PRESENTATION LAYER                       │
│  (HTML, CSS, JavaScript, Bootstrap, Tailwind, jQuery)       │
└─────────────────────────────────────────────────────────────┘
                            ↕
┌─────────────────────────────────────────────────────────────┐
│                     APPLICATION LAYER                        │
│         (PHP Server-side Processing & API Endpoints)        │
└─────────────────────────────────────────────────────────────┘
                            ↕
┌─────────────────────────────────────────────────────────────┐
│                       DATA LAYER                             │
│              (MySQL Database - MariaDB/MySQL)                │
└─────────────────────────────────────────────────────────────┘</div>

        <h3>System Flow Diagram</h3>
        <div class="diagram">User Login → Authentication → Dashboard → Feature Access
                    ↓
              Session Management
                    ↓
         Role-Based Access Control
                    ↓
    ┌──────────────┴──────────────┐
    ↓                              ↓
Admin Features              User Features
- Manage Hotspots          - View Predictions
- Approve Reports          - Submit Reports
- View Analytics           - View Traffic Map
- Manage Users             - Route Suggestions
- System Settings          - Profile Management</div>
    </div>

    <div class="section" id="technology-stack">
        <h1>3. Technology Stack</h1>

        <h2>Frontend Stack</h2>

        <h3>HTML5</h3>
        <ul>
            <li>Semantic markup for structure</li>
            <li>Form validation attributes</li>
            <li>Responsive meta tags</li>
        </ul>

        <h3>CSS Frameworks</h3>
        <ul>
            <li><strong>Bootstrap 5.3.0:</strong> Component library, grid system, responsive utilities</li>
            <li><strong>Tailwind CSS 2.2.19:</strong> Utility-first styling, custom design system</li>
        </ul>

        <h3>JavaScript Libraries</h3>
        <ul>
            <li><strong>jQuery 3.6.0:</strong> DOM manipulation, AJAX requests, event handling</li>
            <li><strong>Chart.js:</strong> Data visualization for analytics</li>
            <li><strong>Google Maps API:</strong> Interactive traffic map visualization</li>
        </ul>

        <h3>Custom Assets</h3>
        <ul>
            <li><code>custom.css</code>: Application-specific styling</li>
            <li><code>validation.js</code>: Client-side form validation</li>
            <li><code>ajax_requests.js</code>: AJAX utility functions</li>
            <li><code>predictions.js</code>: Prediction formatting and display</li>
            <li><code>traffic_map.js</code>: Map initialization and marker management</li>
        </ul>

        <h2>Backend Stack</h2>

        <h3>PHP (Server-side)</h3>
        <ul>
            <li>Session management</li>
            <li>User authentication</li>
            <li>Database operations</li>
            <li>API endpoints</li>
            <li>Role-based access control</li>
        </ul>

        <h3>Database</h3>
        <ul>
            <li><strong>MySQL/MariaDB:</strong> Relational database management</li>
            <li><strong>Connection:</strong> MySQLi extension with prepared statements</li>
        </ul>

        <h3>Server Configuration</h3>
        <ul>
            <li><strong>Apache Web Server</strong></li>
            <li><strong>mod_rewrite:</strong> URL routing</li>
            <li><strong>mod_headers:</strong> Security headers</li>
            <li><strong>mod_deflate:</strong> Response compression</li>
            <li><strong>mod_expires:</strong> Cache control</li>
        </ul>
    </div>

    <div class="section" id="database-structure">
        <h1>4. Database Structure</h1>

        <h3>Entity Relationship Diagram</h3>
        <div class="diagram">┌─────────────┐         ┌──────────────┐         ┌─────────────────┐
│    users    │────────>│   hotspots   │<────────│  traffic_data   │
└─────────────┘         └──────────────┘         └─────────────────┘
      │                        │
      │                        │
      ↓                        ↓
┌──────────────────┐    ┌────────────────────────┐
│ traffic_reports  │    │ traffic_predictions    │
└──────────────────┘    └────────────────────────┘

┌──────────────────┐
│ system_settings  │
└──────────────────┘</div>

        <h2>Table Structures</h2>

        <h3>1. users Table</h3>
        <table>
            <tr>
                <th>Field</th>
                <th>Type</th>
                <th>Description</th>
            </tr>
            <tr>
                <td>id</td>
                <td>INT AUTO_INCREMENT PRIMARY KEY</td>
                <td>Unique user identifier</td>
            </tr>
            <tr>
                <td>fullname</td>
                <td>VARCHAR(100)</td>
                <td>User's full name</td>
            </tr>
            <tr>
                <td>email</td>
                <td>VARCHAR(120) UNIQUE</td>
                <td>Login email (unique)</td>
            </tr>
            <tr>
                <td>password</td>
                <td>VARCHAR(255)</td>
                <td>bcrypt hashed password</td>
            </tr>
            <tr>
                <td>role</td>
                <td>ENUM('admin','user')</td>
                <td>User access level</td>
            </tr>
            <tr>
                <td>created_at</td>
                <td>TIMESTAMP</td>
                <td>Registration date</td>
            </tr>
        </table>

        <h3>2. hotspots Table</h3>
        <table>
            <tr>
                <th>Field</th>
                <th>Type</th>
                <th>Description</th>
            </tr>
            <tr>
                <td>id</td>
                <td>INT AUTO_INCREMENT PRIMARY KEY</td>
                <td>Unique hotspot identifier</td>
            </tr>
            <tr>
                <td>location_name</td>
                <td>VARCHAR(150)</td>
                <td>Hotspot location name</td>
            </tr>
            <tr>
                <td>latitude</td>
                <td>DECIMAL(10,7)</td>
                <td>Geographic latitude</td>
            </tr>
            <tr>
                <td>longitude</td>
                <td>DECIMAL(10,7)</td>
                <td>Geographic longitude</td>
            </tr>
            <tr>
                <td>peak_start</td>
                <td>TIME</td>
                <td>Peak hour start time</td>
            </tr>
            <tr>
                <td>peak_end</td>
                <td>TIME</td>
                <td>Peak hour end time</td>
            </tr>
            <tr>
                <td>created_by</td>
                <td>INT</td>
                <td>Admin user ID (FK)</td>
            </tr>
            <tr>
                <td>created_at</td>
                <td>TIMESTAMP</td>
                <td>Creation date</td>
            </tr>
        </table>

        <h3>3. traffic_data Table</h3>
        <table>
            <tr>
                <th>Field</th>
                <th>Type</th>
                <th>Description</th>
            </tr>
            <tr>
                <td>id</td>
                <td>INT AUTO_INCREMENT PRIMARY KEY</td>
                <td>Unique record identifier</td>
            </tr>
            <tr>
                <td>hotspot_id</td>
                <td>INT</td>
                <td>Related hotspot (FK)</td>
            </tr>
            <tr>
                <td>congestion_level</td>
                <td>VARCHAR(50)</td>
                <td>Light/Moderate/Heavy</td>
            </tr>
            <tr>
                <td>vehicle_speed</td>
                <td>DECIMAL(5,2)</td>
                <td>Average speed (km/h)</td>
            </tr>
            <tr>
                <td>traffic_density</td>
                <td>INT</td>
                <td>Vehicles per area</td>
            </tr>
            <tr>
                <td>recorded_at</td>
                <td>TIMESTAMP</td>
                <td>Measurement timestamp</td>
            </tr>
        </table>

        <h3>4. traffic_predictions Table</h3>
        <table>
            <tr>
                <th>Field</th>
                <th>Type</th>
                <th>Description</th>
            </tr>
            <tr>
                <td>id</td>
                <td>INT AUTO_INCREMENT PRIMARY KEY</td>
                <td>Unique prediction ID</td>
            </tr>
            <tr>
                <td>hotspot_id</td>
                <td>INT</td>
                <td>Related hotspot (FK)</td>
            </tr>
            <tr>
                <td>predicted_level</td>
                <td>VARCHAR(50)</td>
                <td>Light/Moderate/Heavy</td>
            </tr>
            <tr>
                <td>prediction_time</td>
                <td>DATETIME</td>
                <td>Prediction target time</td>
            </tr>
            <tr>
                <td>confidence_score</td>
                <td>DECIMAL(5,2)</td>
                <td>Prediction confidence %</td>
            </tr>
            <tr>
                <td>created_at</td>
                <td>TIMESTAMP</td>
                <td>Prediction generated</td>
            </tr>
        </table>

        <h3>5. traffic_reports Table</h3>
        <table>
            <tr>
                <th>Field</th>
                <th>Type</th>
                <th>Description</th>
            </tr>
            <tr>
                <td>id</td>
                <td>INT AUTO_INCREMENT PRIMARY KEY</td>
                <td>Unique report ID</td>
            </tr>
            <tr>
                <td>user_id</td>
                <td>INT</td>
                <td>Submitter user (FK)</td>
            </tr>
            <tr>
                <td>hotspot_id</td>
                <td>INT</td>
                <td>Related hotspot (FK)</td>
            </tr>
            <tr>
                <td>traffic_level</td>
                <td>VARCHAR(50)</td>
                <td>Reported congestion</td>
            </tr>
            <tr>
                <td>description</td>
                <td>TEXT</td>
                <td>Report details</td>
            </tr>
            <tr>
                <td>status</td>
                <td>ENUM('pending','approved','rejected')</td>
                <td>Review status</td>
            </tr>
            <tr>
                <td>created_at</td>
                <td>TIMESTAMP</td>
                <td>Submission date</td>
            </tr>
        </table>

        <h3>6. system_settings Table</h3>
        <table>
            <tr>
                <th>Field</th>
                <th>Type</th>
                <th>Description</th>
            </tr>
            <tr>
                <td>id</td>
                <td>INT AUTO_INCREMENT PRIMARY KEY</td>
                <td>Settings record ID</td>
            </tr>
            <tr>
                <td>sidebar_color</td>
                <td>VARCHAR(50)</td>
                <td>Sidebar background color</td>
            </tr>
            <tr>
                <td>font_family</td>
                <td>VARCHAR(50)</td>
                <td>System font family</td>
            </tr>
            <tr>
                <td>font_size</td>
                <td>VARCHAR(20)</td>
                <td>Base font size</td>
            </tr>
        </table>
    </div>

    <div class="section" id="security">
        <h1>5. Security Implementation</h1>

        <h2>Authentication Security</h2>

        <h3>Password Security</h3>
        <ul>
            <li><strong>Hashing Algorithm:</strong> bcrypt (PASSWORD_DEFAULT)</li>
            <li><strong>Salt:</strong> Auto-generated per password</li>
            <li><strong>Cost Factor:</strong> PHP default (currently 10)</li>
        </ul>

        <pre><code>// Password hashing on registration
$password = password_hash($_POST['password'], PASSWORD_DEFAULT);

// Password verification on login
password_verify($password, $user->password)</code></pre>

        <h3>Session Management</h3>
        <ul>
            <li>PHP sessions with secure configuration</li>
            <li>Session variables: user_id, fullname, email, role</li>
            <li>Session validation on every protected page</li>
            <li>Automatic session destruction on logout</li>
        </ul>

        <h2>Authorization Security</h2>

        <h3>Role-Based Access Control (RBAC)</h3>
        <table>
            <tr>
                <th>Feature</th>
                <th>Admin</th>
                <th>User</th>
            </tr>
            <tr>
                <td>View Dashboard</td>
                <td>✓</td>
                <td>✓</td>
            </tr>
            <tr>
                <td>Manage Hotspots</td>
                <td>✓</td>
                <td>✗</td>
            </tr>
            <tr>
                <td>Approve Reports</td>
                <td>✓</td>
                <td>✗</td>
            </tr>
            <tr>
                <td>Submit Reports</td>
                <td>✓</td>
                <td>✓</td>
            </tr>
            <tr>
                <td>View Analytics</td>
                <td>✓</td>
                <td>✗</td>
            </tr>
            <tr>
                <td>Manage Users</td>
                <td>✓</td>
                <td>✗</td>
            </tr>
            <tr>
                <td>System Settings</td>
                <td>✓</td>
                <td>✗</td>
            </tr>
            <tr>
                <td>View Predictions</td>
                <td>✓</td>
                <td>✓</td>
            </tr>
            <tr>
                <td>View Traffic Map</td>
                <td>✓</td>
                <td>✓</td>
            </tr>
            <tr>
                <td>Route Suggestions</td>
                <td>✓</td>
                <td>✓</td>
            </tr>
        </table>

        <h2>Input Validation & Sanitization</h2>

        <h3>Server-Side Validation</h3>
        <pre><code>// Email sanitization
filter_var($_POST['email'], FILTER_SANITIZE_EMAIL)

// String sanitization
filter_var($_POST['name'], FILTER_SANITIZE_STRING)

// SQL injection prevention (Prepared Statements)
$stmt = mysqli_prepare($conn, $query);
mysqli_stmt_bind_param($stmt, "ss", $email, $password);</code></pre>

        <h3>Client-Side Validation</h3>
        <pre><code>// Email validation regex
function validateEmail(email) {
    const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return re.test(email);
}

// Password strength validation
function validatePassword(password) {
    return password.length >= 6;
}</code></pre>

        <h2>HTTP Security Headers</h2>
        <ul>
            <li><strong>X-Frame-Options:</strong> SAMEORIGIN (prevent clickjacking)</li>
            <li><strong>X-Content-Type-Options:</strong> nosniff (prevent MIME sniffing)</li>
            <li><strong>X-XSS-Protection:</strong> 1; mode=block (XSS protection)</li>
            <li><strong>Referrer-Policy:</strong> strict-origin-when-cross-origin</li>
            <li><strong>Content-Security-Policy:</strong> Restrictive CSP rules</li>
        </ul>

        <h2>Directory & File Protection</h2>
        <ul>
            <li>Directory listing disabled (Options -Indexes)</li>
            <li>Sensitive directories blocked: includes/, config/, database/</li>
            <li>Hidden files blocked (files starting with .)</li>
            <li>HTTPS enforcement with automatic redirect</li>
        </ul>
    </div>

    <div class="section" id="realtime">
        <h1>6. Real-Time Features</h1>

        <h2>Auto-Refresh Mechanisms</h2>

        <h3>Dashboard Statistics (30-second interval)</h3>
        <pre><code>$(document).ready(function() {
    loadDashboardStats();
    setInterval(loadDashboardStats, 30000); // 30 seconds
});</code></pre>

        <h3>Traffic Predictions (60-second interval)</h3>
        <pre><code>$(document).ready(function() {
    loadPredictions();
    setInterval(loadPredictions, 60000); // 1 minute
});</code></pre>

        <h2>AJAX-Based Real-Time Updates</h2>
        <ul>
            <li>Asynchronous requests using jQuery AJAX</li>
            <li>Background data updates without page refresh</li>
            <li>Dynamic DOM manipulation for seamless UX</li>
        </ul>

        <h2>Traffic Prediction Algorithm</h2>
        <div class="diagram">Input: Historical traffic data, current time, peak hours
Process:
  1. Fetch average speed and density from last hour
  2. Apply congestion thresholds:
     - Heavy: speed < 10 km/h
     - Moderate: speed < 25 km/h
     - Light: speed ≥ 25 km/h
  3. Check if current time is within peak hours
  4. Calculate confidence score (75-90%)
Output: Predicted congestion level with confidence</div>

        <h2>Real-Time Map Updates</h2>
        <ul>
            <li>Dynamic marker placement based on hotspot data</li>
            <li>Interactive info windows with real-time information</li>
            <li>Traffic layer overlay for live traffic conditions</li>
            <li>Auto-refresh of marker data</li>
        </ul>

        <h2>Instant Report Submission</h2>
        <ul>
            <li>User-submitted reports immediately stored</li>
            <li>Admin dashboard updated in real-time</li>
            <li>Status changes reflect instantly across all admin sessions</li>
        </ul>
    </div>

    <div class="section" id="frontend">
        <h1>7. Frontend Architecture</h1>

        <h2>Design System</h2>

        <h3>Color Palette</h3>
        <ul>
            <li><strong>Primary:</strong> Bootstrap Blue (#0d6efd)</li>
            <li><strong>Success:</strong> Green (#198754)</li>
            <li><strong>Warning:</strong> Yellow (#ffc107)</li>
            <li><strong>Danger:</strong> Red (#dc3545)</li>
            <li><strong>Info:</strong> Cyan (#0dcaf0)</li>
            <li><strong>Dark Sidebar:</strong> Customizable (default #343a40)</li>
        </ul>

        <h3>Typography</h3>
        <ul>
            <li><strong>Font Family:</strong> Customizable (Arial, Helvetica, Times New Roman, Georgia)</li>
            <li><strong>Font Size:</strong> Customizable (12px, 14px, 16px, 18px)</li>
            <li><strong>Line Height:</strong> Standard Bootstrap scale</li>
        </ul>

        <h3>Responsive Breakpoints</h3>
        <ul>
            <li><strong>Mobile:</strong> &lt; 768px (Sidebar becomes full-width)</li>
            <li><strong>Tablet:</strong> 768px+ (Standard sidebar)</li>
            <li><strong>Desktop:</strong> 992px+ (Optimized layout)</li>
            <li><strong>Large:</strong> 1200px+ (Maximum width utilization)</li>
        </ul>

        <h2>Component Structure</h2>

        <h3>Layout Components</h3>
        <ul>
            <li><strong>Sidebar Navigation:</strong> Fixed left sidebar with role-based menu items</li>
            <li><strong>Content Area:</strong> Flexible main content with margin-left offset</li>
            <li><strong>Header:</strong> Dynamic with system settings integration</li>
            <li><strong>Footer:</strong> Script imports and initialization</li>
        </ul>

        <h3>Data Display Components</h3>
        <ul>
            <li><strong>Statistics Cards:</strong> Dashboard metrics with color coding</li>
            <li><strong>Data Tables:</strong> Sortable, responsive tables with action buttons</li>
            <li><strong>Charts:</strong> Chart.js visualizations (bar, line, heatmap)</li>
            <li><strong>Maps:</strong> Google Maps with custom markers and info windows</li>
            <li><strong>Alerts:</strong> Bootstrap alerts for predictions and notifications</li>
        </ul>

        <h3>Form Components</h3>
        <ul>
            <li><strong>Login/Register Forms:</strong> Validation with error messaging</li>
            <li><strong>Modal Forms:</strong> Bootstrap modals for add/edit operations</li>
            <li><strong>Inline Forms:</strong> Route suggestions, profile updates</li>
        </ul>
    </div>

    <div class="section" id="backend">
        <h1>8. Backend Architecture</h1>

        <h2>PHP File Organization</h2>

        <h3>Page Controllers (Root Level)</h3>
        <ul>
            <li>login.php, register_user.php, register_admin.php</li>
            <li>dashboard.php, profile.php</li>
            <li>hotspots.php, users.php, settings.php</li>
            <li>traffic_map.php, predictions.php, routes.php</li>
            <li>traffic_reports.php, analytics.php</li>
        </ul>

        <h3>API Endpoints (api/ directory)</h3>
        <table>
            <tr>
                <th>File</th>
                <th>Purpose</th>
            </tr>
            <tr>
                <td>login.php</td>
                <td>User authentication</td>
            </tr>
            <tr>
                <td>register_user.php</td>
                <td>User registration</td>
            </tr>
            <tr>
                <td>register_admin.php</td>
                <td>Admin registration</td>
            </tr>
            <tr>
                <td>fetch_hotspots.php</td>
                <td>Get all hotspots</td>
            </tr>
            <tr>
                <td>add_hotspot.php</td>
                <td>Create new hotspot</td>
            </tr>
            <tr>
                <td>delete_hotspot.php</td>
                <td>Remove hotspot</td>
            </tr>
            <tr>
                <td>fetch_reports.php</td>
                <td>Get traffic reports</td>
            </tr>
            <tr>
                <td>submit_report.php</td>
                <td>Create new report</td>
            </tr>
            <tr>
                <td>approve_report.php</td>
                <td>Approve pending report</td>
            </tr>
            <tr>
                <td>traffic_prediction.php</td>
                <td>Generate predictions</td>
            </tr>
            <tr>
                <td>fetch_dashboard_stats.php</td>
                <td>Dashboard metrics</td>
            </tr>
            <tr>
                <td>update_profile.php</td>
                <td>User profile update</td>
            </tr>
            <tr>
                <td>update_settings.php</td>
                <td>System settings update</td>
            </tr>
        </table>

        <h2>API Response Format</h2>

        <h3>Success Response</h3>
        <pre><code>{
    "success": true,
    "message": "Operation completed successfully",
    "data": { ... }
}</code></pre>

        <h3>Error Response</h3>
        <pre><code>{
    "success": false,
    "message": "Error description",
    "data": null
}</code></pre>

        <h2>Database Access Pattern</h2>
        <ol>
            <li>Prepare statement: mysqli_prepare($conn, $query)</li>
            <li>Bind parameters: mysqli_stmt_bind_param($stmt, "types", $vars)</li>
            <li>Execute: mysqli_stmt_execute($stmt)</li>
            <li>Get result: mysqli_stmt_get_result($stmt)</li>
            <li>Fetch data: mysqli_fetch_object($result)</li>
            <li>Return JSON: json_encode(['success' => true, 'data' => $data])</li>
        </ol>
    </div>

    <div class="section" id="api">
        <h1>9. API Documentation</h1>

        <h2>Authentication APIs</h2>

        <h3>POST /api/login.php</h3>
        <p><strong>Description:</strong> Authenticate user credentials</p>
        <p><strong>Request Body:</strong></p>
        <pre><code>{
    "email": "user@example.com",
    "password": "userpassword"
}</code></pre>
        <p><strong>Response:</strong></p>
        <pre><code>{
    "success": true,
    "message": "Login successful"
}</code></pre>

        <h3>POST /api/register_user.php</h3>
        <p><strong>Description:</strong> Register new user account</p>
        <p><strong>Request Body:</strong></p>
        <pre><code>{
    "fullname": "John Doe",
    "email": "john@example.com",
    "password": "password123"
}</code></pre>

        <h2>Hotspot Management APIs</h2>

        <h3>GET /api/fetch_hotspots.php</h3>
        <p><strong>Description:</strong> Retrieve all traffic hotspots</p>
        <p><strong>Response:</strong></p>
        <pre><code>{
    "success": true,
    "data": [
        {
            "id": 1,
            "location_name": "Clock Tower",
            "latitude": "0.3136",
            "longitude": "32.5811",
            "peak_start": "07:00:00",
            "peak_end": "09:00:00"
        }
    ]
}</code></pre>

        <h3>POST /api/add_hotspot.php</h3>
        <p><strong>Authorization:</strong> Admin only</p>
        <p><strong>Request Body:</strong></p>
        <pre><code>{
    "location_name": "Ntinda",
    "latitude": "0.3555",
    "longitude": "32.6178",
    "peak_start": "17:00",
    "peak_end": "19:00"
}</code></pre>

        <h2>Traffic Report APIs</h2>

        <h3>POST /api/submit_report.php</h3>
        <p><strong>Authorization:</strong> Authenticated users</p>
        <p><strong>Request Body:</strong></p>
        <pre><code>{
    "hotspot_id": 3,
    "traffic_level": "Heavy",
    "description": "Accident at intersection"
}</code></pre>

        <h2>Prediction APIs</h2>

        <h3>GET /api/traffic_prediction.php</h3>
        <p><strong>Description:</strong> Generate and retrieve traffic predictions</p>
        <p><strong>Response:</strong></p>
        <pre><code>{
    "success": true,
    "data": [
        {
            "location_name": "Clock Tower",
            "predicted_level": "Heavy",
            "prediction_time": "2024-01-15 09:45:00",
            "confidence_score": 85.5
        }
    ]
}</code></pre>
    </div>

    <div class="section" id="roles">
        <h1>10. User Roles & Access Control</h1>

        <h2>Admin Role Capabilities</h2>
        <ul>
            <li>Dashboard Access: View all system statistics</li>
            <li>Hotspot Management: CRUD operations on traffic hotspots</li>
            <li>Report Management: Approve/reject user-submitted reports</li>
            <li>User Management: Create, update, delete user accounts</li>
            <li>Analytics Access: View traffic trends and charts</li>
            <li>System Settings: Customize UI appearance</li>
            <li>All User Features: Can perform all user-level actions</li>
        </ul>

        <h2>User Role Capabilities</h2>
        <ul>
            <li>Dashboard Access: View personal statistics</li>
            <li>Report Submission: Submit traffic reports for approval</li>
            <li>Traffic Map: View real-time traffic visualization</li>
            <li>Predictions: View AI-generated traffic forecasts</li>
            <li>Route Suggestions: Get alternative route recommendations</li>
            <li>Profile Management: Update personal information</li>
        </ul>

        <h2>Access Control Implementation</h2>
        <pre><code>// Page-level protection
&lt;?php
require_once 'includes/admin_auth.php'; // Admin pages
require_once 'includes/auth.php';       // All authenticated pages
?&gt;

// API-level protection
if ($_SESSION['role'] !== 'admin') {
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit();
}</code></pre>
    </div>

    <div class="section" id="features">
        <h1>11. System Features</h1>

        <h2>1. User Authentication System</h2>
        <ul>
            <li>Registration: Separate flows for users and admins</li>
            <li>Login: Email and password authentication</li>
            <li>Session Management: Persistent login across pages</li>
            <li>Logout: Secure session destruction</li>
        </ul>

        <h2>2. Traffic Hotspot Management</h2>
        <ul>
            <li>Create Hotspots: Define location name, coordinates, peak hours</li>
            <li>View Hotspots: Table view with all details</li>
            <li>Update Hotspots: Modify existing hotspot information</li>
            <li>Delete Hotspots: Remove outdated hotspots</li>
            <li>Map Visualization: See all hotspots on Google Maps</li>
        </ul>

        <h2>3. Traffic Prediction Engine</h2>
        <ul>
            <li>Algorithm: Statistical analysis of historical data</li>
            <li>Peak Hour Detection: Automatic heavy traffic during peak windows</li>
            <li>Confidence Scoring: 75-90% confidence levels</li>
            <li>Real-Time Updates: Predictions refresh every 60 seconds</li>
            <li>Visual Indicators: Color-coded alerts (red=heavy, yellow=moderate, green=light)</li>
        </ul>

        <h2>4. User-Generated Reports</h2>
        <ul>
            <li>Report Submission: Users describe current traffic conditions</li>
            <li>Approval Workflow: Admin review before publication</li>
            <li>Status Tracking: Pending, approved, rejected states</li>
            <li>Integration: Approved reports influence predictions</li>
        </ul>

        <h2>5. Interactive Traffic Map</h2>
        <ul>
            <li>Google Maps Integration: Full-screen interactive map</li>
            <li>Hotspot Markers: Clickable pins at each location</li>
            <li>Info Windows: Display peak hours and details</li>
            <li>Traffic Layer: Real-time Google traffic overlay</li>
        </ul>

        <h2>6. Route Suggestions</h2>
        <ul>
            <li>Input: Select congested hotspot</li>
            <li>Output: Alternative route recommendations</li>
            <li>Time Savings: Estimated time saved by avoiding congestion</li>
            <li>Multiple Options: 2-3 alternative routes per query</li>
        </ul>

        <h2>7. Analytics Dashboard</h2>
        <ul>
            <li>Chart Types: Bar charts, line graphs, trend analysis</li>
            <li>Metrics: Most congested roads, peak hours, trends</li>
            <li>Time Ranges: Daily, weekly, monthly views</li>
        </ul>

        <h2>8. System Customization</h2>
        <ul>
            <li>Sidebar Color: Admin-configurable color scheme</li>
            <li>Font Family: Choose from 4 font options</li>
            <li>Font Size: Adjustable text size (12-18px)</li>
            <li>Live Preview: Settings apply immediately after save</li>
        </ul>
    </div>

    <div class="section" id="installation">
        <h1>12. Installation & Setup</h1>

        <h2>Prerequisites</h2>
        <ul>
            <li><strong>Web Server:</strong> Apache 2.4+</li>
            <li><strong>PHP:</strong> 7.4 or higher</li>
            <li><strong>Database:</strong> MySQL 5.7+ or MariaDB 10.3+</li>
            <li><strong>Extensions:</strong> mysqli, session, json, filter</li>
        </ul>

        <h2>Step 1: Database Setup</h2>
        <pre><code># Create database and import schema
mysql -u root -p

SOURCE database/schema.sql;
SOURCE database/sample_data.sql;  -- Optional</code></pre>

        <h2>Step 2: Configure Database Connection</h2>
        <p>Edit <code>config/database.php</code>:</p>
        <pre><code>$host = 'localhost';
$username = 'your_db_username';
$password = 'your_db_password';
$database = 'kampala_traffic_predictor';</code></pre>

        <h2>Step 3: Configure Google Maps API</h2>
        <p>Edit <code>traffic_map.php</code>:</p>
        <pre><code>&lt;script src="https://maps.googleapis.com/maps/api/js?key=YOUR_API_KEY"&gt;&lt;/script&gt;</code></pre>

        <h2>Step 4: Enable Apache Modules</h2>
        <pre><code>sudo a2enmod rewrite
sudo a2enmod headers
sudo a2enmod deflate
sudo a2enmod expires
sudo systemctl restart apache2</code></pre>

        <h2>Step 5: Access the Application</h2>
        <p>Navigate to: <code>http://localhost/kampala-traffic/</code></p>

        <h3>Default Login Credentials (Sample Data)</h3>
        <ul>
            <li><strong>Admin:</strong> admin@traffic.com / password</li>
            <li><strong>User:</strong> john@example.com / password</li>
        </ul>
    </div>

    <div class="section" id="file-structure">
        <h1>13. File Structure</h1>

        <pre><code>kampala-traffic-predictor/
│
├── index.php                    # Redirects to login
├── login.php                    # User login page
├── logout.php                   # Session destruction
├── register_user.php            # User registration
├── register_admin.php           # Admin registration
├── dashboard.php                # Main dashboard
├── profile.php                  # User profile
├── hotspots.php                 # Hotspot management
├── users.php                    # User management
├── settings.php                 # System settings
├── traffic_map.php              # Interactive map
├── predictions.php              # Traffic predictions
├── routes.php                   # Route suggestions
├── traffic_reports.php          # Report management
├── analytics.php                # Traffic analytics
├── .htaccess                    # Apache config
│
├── api/                         # API endpoints
│   ├── login.php
│   ├── register_user.php
│   ├── fetch_hotspots.php
│   ├── add_hotspot.php
│   ├── submit_report.php
│   ├── traffic_prediction.php
│   └── ...
│
├── includes/                    # Reusable components
│   ├── auth.php
│   ├── admin_auth.php
│   ├── header.php
│   ├── footer.php
│   └── sidebar.php
│
├── config/                      # Configuration
│   └── database.php
│
├── database/                    # Database schema
│   ├── schema.sql
│   └── sample_data.sql
│
└── assets/                      # Frontend assets
    ├── css/
    │   └── custom.css
    └── js/
        ├── validation.js
        ├── ajax_requests.js
        ├── predictions.js
        └── traffic_map.js</code></pre>
    </div>

    <div class="section" id="best-practices">
        <h1>14. Security Best Practices</h1>

        <h2>Current Implementation</h2>
        <div class="alert alert-success">
            <ul>
                <li>✅ Password Hashing: bcrypt algorithm</li>
                <li>✅ SQL Injection Prevention: 100% prepared statements</li>
                <li>✅ XSS Protection: htmlspecialchars() on all output</li>
                <li>✅ CSRF Protection: Session-based verification</li>
                <li>✅ HTTPS Enforcement: Automatic redirect</li>
                <li>✅ Security Headers: X-Frame-Options, CSP, etc.</li>
                <li>✅ Directory Protection: Sensitive folders blocked</li>
                <li>✅ Session Security: Secure session management</li>
                <li>✅ Input Validation: Server and client-side</li>
                <li>✅ Error Suppression: No database errors exposed</li>
            </ul>
        </div>

        <h2>Recommended Enhancements</h2>
        <div class="alert alert-warning">
            <ul>
                <li>🔲 CSRF Tokens: Implement token-based CSRF protection</li>
                <li>🔲 Rate Limiting: Prevent brute force attacks</li>
                <li>🔲 2FA: Two-factor authentication for admins</li>
                <li>🔲 Password Policy: Enforce strong passwords</li>
                <li>🔲 Account Lockout: Lock after failed login attempts</li>
                <li>🔲 Audit Logging: Log all admin actions</li>
                <li>🔲 API Rate Limiting: Throttle API requests</li>
                <li>🔲 Database Encryption: Encrypt sensitive fields</li>
            </ul>
        </div>
    </div>

    <div class="section" id="future">
        <h1>15. Future Enhancements</h1>

        <h2>Phase 1: Core Improvements</h2>
        <ul>
            <li>Mobile Application: Native Android/iOS apps</li>
            <li>Real Traffic Data Integration: Government traffic API</li>
            <li>Machine Learning: Advanced prediction algorithms</li>
            <li>Notifications: Push notifications for alerts</li>
            <li>Weather Integration: Factor weather into predictions</li>
        </ul>

        <h2>Phase 2: Advanced Features</h2>
        <ul>
            <li>User Preferences: Saved routes and favorites</li>
            <li>Social Features: Share routes, comment on reports</li>
            <li>Gamification: Points for accurate reports</li>
            <li>Multi-Language: Support for local languages</li>
            <li>Offline Mode: Cache predictions for offline access</li>
        </ul>

        <h2>Phase 3: Enterprise Features</h2>
        <ul>
            <li>API for Third Parties: Public traffic data API</li>
            <li>Fleet Management: Integration with transport companies</li>
            <li>Government Dashboard: City planning insights</li>
            <li>Historical Analysis: Long-term trend reports</li>
            <li>Incident Management: Integration with emergency services</li>
        </ul>
    </div>

    <div class="section" style="text-align: center; padding: 50px 20px;">
        <h2>End of Project Manual</h2>
        <p><strong>System Name:</strong> Kampala Traffic Predictor</p>
        <p><strong>Version:</strong> 1.0</p>
        <p><strong>Last Updated:</strong> 2024</p>
        <p><strong>Architecture:</strong> Three-Tier Web Application</p>
    </div>

    <div class="no-print" style="position: fixed; bottom: 20px; right: 20px; background: #0d6efd; color: white; padding: 15px 25px; border-radius: 5px; cursor: pointer; box-shadow: 0 2px 10px rgba(0,0,0,0.2);" onclick="window.print()">
        📄 Print to PDF
    </div>

    <script>
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', function (e) {
                e.preventDefault();
                const target = document.querySelector(this.getAttribute('href'));
                if (target) {
                    target.scrollIntoView({ behavior: 'smooth' });
                }
            });
        });
    </script>
</body>
</html>
