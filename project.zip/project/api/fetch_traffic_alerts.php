<?php
session_start();
require_once '../config/database.php';

header('Content-Type: application/json');

// Fetch recent traffic alerts
$query = "SELECT 
    tr.*,
    h.location_name,
    h.latitude,
    h.longitude
    FROM traffic_reports tr
    JOIN hotspots h ON tr.hotspot_id = h.id
    WHERE tr.status = 'approved'
    AND tr.created_at >= DATE_SUB(NOW(), INTERVAL 24 HOUR)
    ORDER BY tr.created_at DESC
    LIMIT 10";

$result = mysqli_query($conn, $query);
$alerts = array();

while ($row = mysqli_fetch_assoc($result)) {
    // Determine severity based on traffic level
    $severity = 'low';
    if ($row['traffic_level'] == 'heavy') {
        $severity = 'high';
    } elseif ($row['traffic_level'] == 'moderate') {
        $severity = 'medium';
    }
    
    // Calculate time ago
    $time_ago = time_elapsed_string($row['created_at']);
    
    // Random distance for demo (you can calculate real distance if you have user location)
    $distance = rand(1, 15) . ' km away';
    
    $alerts[] = array(
        'id' => $row['id'],
        'location' => $row['location_name'],
        'congestion_level' => ucfirst($row['traffic_level']) . ' Traffic',
        'severity' => $severity,
        'time' => $time_ago,
        'distance' => $distance,
        'description' => $row['description']
    );
}

// If no real alerts, provide demo alerts
if (empty($alerts)) {
    $alerts = getDemoAlerts();
}

echo json_encode(['success' => true, 'data' => $alerts]);

// Helper function to format time
function time_elapsed_string($datetime, $full = false) {
    $now = new DateTime;
    $ago = new DateTime($datetime);
    $diff = $now->diff($ago);

    $diff->w = floor($diff->d / 7);
    $diff->d -= $diff->w * 7;

    $string = array(
        'y' => 'year',
        'm' => 'month',
        'w' => 'week',
        'd' => 'day',
        'h' => 'hour',
        'i' => 'minute',
        's' => 'second',
    );

    foreach ($string as $k => &$v) {
        if ($diff->$k) {
            $v = $diff->$k . ' ' . $v . ($diff->$k > 1 ? 's' : '');
        } else {
            unset($string[$k]);
        }
    }

    if (!$full) $string = array_slice($string, 0, 1);
    return $string ? implode(', ', $string) . ' ago' : 'just now';
}

// Demo alerts for when database is empty
function getDemoAlerts() {
    return array(
        array(
            'id' => 1,
            'location' => 'Kampala Road',
            'congestion_level' => 'Heavy Traffic',
            'severity' => 'high',
            'time' => '5 minutes ago',
            'distance' => '2 km away',
            'description' => 'Heavy congestion from Clock Tower to City Square'
        ),
        array(
            'id' => 2,
            'location' => 'Jinja Road',
            'congestion_level' => 'Moderate Traffic',
            'severity' => 'medium',
            'time' => '15 minutes ago',
            'distance' => '3.5 km away',
            'description' => 'Slow moving traffic near the industrial area'
        ),
        array(
            'id' => 3,
            'location' => 'Entebbe Road',
            'congestion_level' => 'Light Traffic',
            'severity' => 'low',
            'time' => '25 minutes ago',
            'distance' => '8 km away',
            'description' => 'Normal flow of traffic'
        ),
        array(
            'id' => 4,
            'location' => 'Northern Bypass',
            'congestion_level' => 'Heavy Traffic',
            'severity' => 'high',
            'time' => '10 minutes ago',
            'distance' => '5 km away',
            'description' => 'Accident reported near Bwaise junction'
        ),
        array(
            'id' => 5,
            'location' => 'Wampewo Avenue',
            'congestion_level' => 'Moderate Traffic',
            'severity' => 'medium',
            'time' => '20 minutes ago',
            'distance' => '1.2 km away',
            'description' => 'Slow traffic due to road works'
        )
    );
}
?>