<?php
session_start();
require_once '../config/database.php';

header('Content-Type: application/json');

$query = "SELECT h.location_name,
          AVG(td.vehicle_speed) as avg_speed,
          AVG(td.traffic_density) as avg_density,
          COUNT(td.id) as total_records
          FROM traffic_data td
          JOIN hotspots h ON td.hotspot_id = h.id
          WHERE td.recorded_at > DATE_SUB(NOW(), INTERVAL 7 DAY)
          GROUP BY h.id
          ORDER BY avg_density DESC";

$result = mysqli_query($conn, $query);

$trends = array();
while ($row = mysqli_fetch_object($result)) {
    $trends[] = array(
        'location_name' => htmlspecialchars($row->location_name),
        'avg_speed' => round($row->avg_speed, 2),
        'avg_density' => round($row->avg_density, 2),
        'total_records' => $row->total_records
    );
}

echo json_encode(['success' => true, 'data' => $trends]);
?>
