<?php
session_start();
require_once '../config/database.php';

header('Content-Type: application/json');

// Fetch hotspots with real-time traffic data
$query = "SELECT 
    h.*,
    COALESCE(
        (SELECT traffic_level FROM traffic_reports 
         WHERE hotspot_id = h.id 
         AND status = 'approved'
         ORDER BY created_at DESC LIMIT 1),
        'light'
    ) as current_traffic,
    COALESCE(
        (SELECT COUNT(*) FROM traffic_reports 
         WHERE hotspot_id = h.id 
         AND created_at >= DATE_SUB(NOW(), INTERVAL 1 HOUR)),
        0
    ) as reports_last_hour,
    COALESCE(
        (SELECT AVG(CASE 
            WHEN traffic_level = 'heavy' THEN 90
            WHEN traffic_level = 'moderate' THEN 60
            WHEN traffic_level = 'light' THEN 30
            ELSE 45
         END) FROM traffic_reports 
         WHERE hotspot_id = h.id 
         AND created_at >= DATE_SUB(NOW(), INTERVAL 24 HOUR)),
        45
    ) as avg_congestion
    FROM hotspots h
    ORDER BY 
        CASE 
            WHEN h.created_at >= DATE_SUB(NOW(), INTERVAL 24 HOUR) THEN 0 
            ELSE 1 
        END,
        h.created_at DESC";

$result = mysqli_query($conn, $query);

$hotspots = array();
while ($row = mysqli_fetch_assoc($result)) {
    // Calculate congestion level percentage
    $congestion = round($row['avg_congestion']);
    
    // Determine color based on congestion
    $color = '#10b981'; // green for light
    if ($congestion > 80) {
        $color = '#dc2626'; // red for heavy
    } elseif ($congestion > 50) {
        $color = '#f59e0b'; // orange for moderate
    } elseif ($congestion > 20) {
        $color = '#10b981'; // green for light
    }
    
    $hotspots[] = array(
        'id' => $row['id'],
        'location_name' => htmlspecialchars($row['location_name']),
        'latitude' => $row['latitude'],
        'longitude' => $row['longitude'],
        'peak_start' => $row['peak_start'] ? date('g:i A', strtotime($row['peak_start'])) : 'N/A',
        'peak_end' => $row['peak_end'] ? date('g:i A', strtotime($row['peak_end'])) : 'N/A',
        'current_traffic' => ucfirst($row['current_traffic']),
        'congestion' => $congestion,
        'reports_last_hour' => $row['reports_last_hour'],
        'color' => $color,
        'created_at' => $row['created_at']
    );
}

// If no hotspots in database, provide demo data
if (empty($hotspots)) {
    $hotspots = getDemoHotspots();
}

echo json_encode(['success' => true, 'data' => $hotspots]);

function getDemoHotspots() {
    return array(
        array(
            'id' => 1,
            'location_name' => 'Kampala Road',
            'latitude' => 0.3136,
            'longitude' => 32.5811,
            'peak_start' => '7:00 AM',
            'peak_end' => '9:00 AM',
            'current_traffic' => 'Heavy',
            'congestion' => 85,
            'reports_last_hour' => 12,
            'color' => '#dc2626',
            'created_at' => date('Y-m-d H:i:s')
        ),
        array(
            'id' => 2,
            'location_name' => 'Jinja Road',
            'latitude' => 0.3248,
            'longitude' => 32.5919,
            'peak_start' => '8:00 AM',
            'peak_end' => '10:00 AM',
            'current_traffic' => 'Moderate',
            'congestion' => 65,
            'reports_last_hour' => 8,
            'color' => '#f59e0b',
            'created_at' => date('Y-m-d H:i:s')
        ),
        array(
            'id' => 3,
            'location_name' => 'Entebbe Road',
            'latitude' => 0.2890,
            'longitude' => 32.5624,
            'peak_start' => '6:00 PM',
            'peak_end' => '8:00 PM',
            'current_traffic' => 'Light',
            'congestion' => 35,
            'reports_last_hour' => 3,
            'color' => '#10b981',
            'created_at' => date('Y-m-d H:i:s')
        ),
        array(
            'id' => 4,
            'location_name' => 'Northern Bypass',
            'latitude' => 0.3502,
            'longitude' => 32.5967,
            'peak_start' => '7:30 AM',
            'peak_end' => '9:30 AM',
            'current_traffic' => 'Heavy',
            'congestion' => 92,
            'reports_last_hour' => 15,
            'color' => '#dc2626',
            'created_at' => date('Y-m-d H:i:s')
        ),
        array(
            'id' => 5,
            'location_name' => 'Wampewo Avenue',
            'latitude' => 0.3305,
            'longitude' => 32.5754,
            'peak_start' => '8:30 AM',
            'peak_end' => '10:30 AM',
            'current_traffic' => 'Moderate',
            'congestion' => 55,
            'reports_last_hour' => 6,
            'color' => '#f59e0b',
            'created_at' => date('Y-m-d H:i:s')
        )
    );
}
?>