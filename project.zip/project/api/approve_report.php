<?php
session_start();
require_once '../config/database.php';

date_default_timezone_set('Africa/Nairobi');
header('Content-Type: application/json');

// Only admins can approve
if ($_SESSION['role'] !== 'admin') {
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
    exit;
}

$report_id = intval($_POST['id']);

$query = "UPDATE traffic_reports SET status = 'approved' WHERE id = $report_id";

if (mysqli_query($conn, $query)) {
    echo json_encode(['success' => true, 'message' => 'Report approved']);
} else {
    echo json_encode(['success' => false, 'message' => 'Failed to approve report']);
}
?>