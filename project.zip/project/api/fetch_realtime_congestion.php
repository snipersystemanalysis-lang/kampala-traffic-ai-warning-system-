<?php
session_start();
require_once '../config/database.php';

header('Content-Type: application/json');

// Fetch real-time congestion data for all hotspots
$query = "SELECT 
    h.id,
    h.location_name,
    h.latitude,
    h.longitude,
    COALESCE(
        (SELECT traffic_level FROM traffic_reports 
         WHERE hotspot_id = h.id 
         AND status = 'approved'
         ORDER BY created_at DESC LIMIT 1),
        'light'
    ) as current_traffic,
    COALESCE(
        (SELECT COUNT(*) FROM traffic_reports 
         WHERE hotspot_id = h.id 
         AND created_at >= DATE_SUB(NOW(), INTERVAL 1 HOUR)),
        0
    ) as reports_last_hour
    FROM hotspots h
    ORDER BY h.location_name";

$result = mysqli_query($conn, $query);
$hotspots = array();

while ($row = mysqli_fetch_assoc($result)) {
    // Calculate congestion score
    $congestion_score = 0;
    switch ($row['current_traffic']) {
        case 'heavy':
            $congestion_score = 85;
            break;
        case 'moderate':
            $congestion_score = 55;
            break;
        case 'light':
            $congestion_score = 25;
            break;
    }
    
    // Adjust based on recent reports
    $congestion_score += min(15, $row['reports_last_hour'] * 3);
    
    $hotspots[] = array(
        'id' => $row['id'],
        'name' => $row['location_name'],
        'lat' => $row['latitude'],
        'lng' => $row['longitude'],
        'congestion' => min(100, $congestion_score),
        'status' => $row['current_traffic'],
        'reports' => $row['reports_last_hour']
    );
}

// If no hotspots in database, provide demo data
if (empty($hotspots)) {
    $hotspots = getDemoHotspots();
}

echo json_encode(['success' => true, 'data' => $hotspots]);

function getDemoHotspots() {
    return array(
        array(
            'id' => 1,
            'name' => 'Kampala Road',
            'lat' => 0.3136,
            'lng' => 32.5811,
            'congestion' => 85,
            'status' => 'heavy',
            'reports' => 12
        ),
        array(
            'id' => 2,
            'name' => 'Jinja Road',
            'lat' => 0.3248,
            'lng' => 32.5919,
            'congestion' => 65,
            'status' => 'moderate',
            'reports' => 8
        ),
        array(
            'id' => 3,
            'name' => 'Entebbe Road',
            'lat' => 0.2890,
            'lng' => 32.5624,
            'congestion' => 35,
            'status' => 'light',
            'reports' => 3
        ),
        array(
            'id' => 4,
            'name' => 'Northern Bypass',
            'lat' => 0.3502,
            'lng' => 32.5967,
            'congestion' => 92,
            'status' => 'heavy',
            'reports' => 15
        )
    );
}
?>