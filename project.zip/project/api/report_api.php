<?php
require_once '../config/database.php';
require_once '../includes/auth.php';

header('Content-Type: application/json');

// Start session if not started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'Not authenticated']);
    exit;
}

$user_id = $_SESSION['user_id'];
$user_role = $_SESSION['role'];
$is_admin = ($user_role == 'admin');

// Get action from request
$action = isset($_REQUEST['action']) ? $_REQUEST['action'] : '';

switch ($action) {
    case 'get_reports':
        getReports();
        break;
    case 'get_stats':
        getStats();
        break;
    case 'get_charts_data':
        if ($is_admin) getChartsData();
        else echo json_encode(['success' => false, 'message' => 'Unauthorized']);
        break;
    case 'get_top_users':
        if ($is_admin) getTopUsers();
        else echo json_encode(['success' => false, 'message' => 'Unauthorized']);
        break;
    case 'get_top_hotspots':
        if ($is_admin) getTopHotspots();
        else echo json_encode(['success' => false, 'message' => 'Unauthorized']);
        break;
    case 'get_recent_activity':
        if ($is_admin) getRecentActivity();
        else echo json_encode(['success' => false, 'message' => 'Unauthorized']);
        break;
    case 'get_hotspots_for_select':
        getHotspotsForSelect();
        break;
    case 'submit_report':
        submitReport();
        break;
    case 'update_status':
        if ($is_admin) updateReportStatus();
        else echo json_encode(['success' => false, 'message' => 'Unauthorized']);
        break;
    case 'get_report_details':
        getReportDetails();
        break;
    case 'export_csv':
        exportToCSV();
        break;
    default:
        echo json_encode(['success' => false, 'message' => 'Invalid action']);
}

// Get date filter conditions
function getDateCondition() {
    $filter = isset($_GET['filter']) ? $_GET['filter'] : 'today';
    $date_from = isset($_GET['date_from']) ? $_GET['date_from'] : '';
    $date_to = isset($_GET['date_to']) ? $_GET['date_to'] : '';
    
    $condition = "";
    
    switch ($filter) {
        case 'today':
            $condition = "DATE(tr.created_at) = CURDATE()";
            break;
        case 'yesterday':
            $condition = "DATE(tr.created_at) = DATE_SUB(CURDATE(), INTERVAL 1 DAY)";
            break;
        case 'thisWeek':
            $condition = "YEARWEEK(tr.created_at) = YEARWEEK(CURDATE())";
            break;
        case 'thisMonth':
            $condition = "MONTH(tr.created_at) = MONTH(CURDATE()) AND YEAR(tr.created_at) = YEAR(CURDATE())";
            break;
        case 'lastMonth':
            $condition = "MONTH(tr.created_at) = MONTH(DATE_SUB(CURDATE(), INTERVAL 1 MONTH)) AND YEAR(tr.created_at) = YEAR(DATE_SUB(CURDATE(), INTERVAL 1 MONTH))";
            break;
        case 'thisYear':
            $condition = "YEAR(tr.created_at) = YEAR(CURDATE())";
            break;
        case 'lastYear':
            $condition = "YEAR(tr.created_at) = YEAR(DATE_SUB(CURDATE(), INTERVAL 1 YEAR))";
            break;
        case 'custom':
            if ($date_from && $date_to) {
                $condition = "DATE(tr.created_at) BETWEEN '$date_from' AND '$date_to'";
            }
            break;
    }
    
    return $condition;
}

// Get reports
function getReports() {
    global $conn, $is_admin, $user_id;
    
    $date_condition = getDateCondition();
    $where = $date_condition ? "WHERE $date_condition" : "";
    
    // If not admin, only show user's own reports
    if (!$is_admin) {
        $where .= $where ? " AND tr.user_id = $user_id" : " WHERE tr.user_id = $user_id";
    }
    
    $query = "
        SELECT tr.*, u.fullname as user_name, h.location_name 
        FROM traffic_reports tr
        JOIN users u ON tr.user_id = u.id
        JOIN hotspots h ON tr.hotspot_id = h.id
        $where
        ORDER BY tr.created_at DESC
    ";
    
    $result = mysqli_query($conn, $query);
    $reports = [];
    
    while ($row = mysqli_fetch_assoc($result)) {
        $reports[] = [
            'id' => $row['id'],
            'user_name' => $row['user_name'],
            'location_name' => $row['location_name'],
            'traffic_level' => $row['traffic_level'],
            'description' => substr($row['description'], 0, 50) . (strlen($row['description']) > 50 ? '...' : ''),
            'status' => $row['status'],
            'created_at' => date('M d, Y H:i', strtotime($row['created_at']))
        ];
    }
    
    echo json_encode(['success' => true, 'data' => $reports]);
}

// Get statistics
function getStats() {
    global $conn;
    
    $date_condition = getDateCondition();
    $where = $date_condition ? "WHERE $date_condition" : "";
    
    // Total reports
    $total_query = "SELECT COUNT(*) as total FROM traffic_reports tr $where";
    $total_result = mysqli_query($conn, $total_query);
    $total = mysqli_fetch_assoc($total_result)['total'];
    
    // Approved reports
    $approved_query = "SELECT COUNT(*) as total FROM traffic_reports tr $where " . ($where ? "AND" : "WHERE") . " status = 'approved'";
    $approved_result = mysqli_query($conn, $approved_query);
    $approved = mysqli_fetch_assoc($approved_result)['total'];
    
    // Pending reports
    $pending_query = "SELECT COUNT(*) as total FROM traffic_reports tr $where " . ($where ? "AND" : "WHERE") . " status = 'pending'";
    $pending_result = mysqli_query($conn, $pending_query);
    $pending = mysqli_fetch_assoc($pending_result)['total'];
    
    // Rejected reports
    $rejected_query = "SELECT COUNT(*) as total FROM traffic_reports tr $where " . ($where ? "AND" : "WHERE") . " status = 'rejected'";
    $rejected_result = mysqli_query($conn, $rejected_query);
    $rejected = mysqli_fetch_assoc($rejected_result)['total'];
    
    // Active users
    $users_query = "SELECT COUNT(DISTINCT user_id) as total FROM traffic_reports tr $where";
    $users_result = mysqli_query($conn, $users_query);
    $active_users = mysqli_fetch_assoc($users_result)['total'];
    
    // Active hotspots
    $hotspots_query = "SELECT COUNT(DISTINCT hotspot_id) as total FROM traffic_reports tr $where";
    $hotspots_result = mysqli_query($conn, $hotspots_query);
    $active_hotspots = mysqli_fetch_assoc($hotspots_result)['total'];
    
    echo json_encode([
        'success' => true,
        'data' => [
            'total' => (int)$total,
            'approved' => (int)$approved,
            'pending' => (int)$pending,
            'rejected' => (int)$rejected,
            'active_users' => (int)$active_users,
            'active_hotspots' => (int)$active_hotspots
        ]
    ]);
}

// Get charts data (admin only)
function getChartsData() {
    global $conn;
    
    $date_condition = getDateCondition();
    $where = $date_condition ? "WHERE $date_condition" : "";
    
    // Status counts
    $status_query = "
        SELECT 
            SUM(CASE WHEN status = 'approved' THEN 1 ELSE 0 END) as approved,
            SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END) as pending,
            SUM(CASE WHEN status = 'rejected' THEN 1 ELSE 0 END) as rejected
        FROM traffic_reports tr
        $where
    ";
    $status_result = mysqli_query($conn, $status_query);
    $status = mysqli_fetch_assoc($status_result);
    
    // Timeline data (last 7 days)
    $timeline_query = "
        SELECT DATE(created_at) as date, COUNT(*) as count
        FROM traffic_reports tr
        $where
        GROUP BY DATE(created_at)
        ORDER BY date DESC
        LIMIT 7
    ";
    $timeline_result = mysqli_query($conn, $timeline_query);
    $timeline_labels = [];
    $timeline_values = [];
    while ($row = mysqli_fetch_assoc($timeline_result)) {
        $timeline_labels[] = date('M d', strtotime($row['date']));
        $timeline_values[] = (int)$row['count'];
    }
    
    // Traffic levels
    $levels_query = "
        SELECT 
            SUM(CASE WHEN traffic_level = 'Heavy' THEN 1 ELSE 0 END) as heavy,
            SUM(CASE WHEN traffic_level = 'Moderate' THEN 1 ELSE 0 END) as moderate,
            SUM(CASE WHEN traffic_level = 'Light' THEN 1 ELSE 0 END) as light
        FROM traffic_reports tr
        $where
    ";
    $levels_result = mysqli_query($conn, $levels_query);
    $levels = mysqli_fetch_assoc($levels_result);
    
    // Top hotspots
    $hotspots_query = "
        SELECT h.location_name, COUNT(*) as count
        FROM traffic_reports tr
        JOIN hotspots h ON tr.hotspot_id = h.id
        $where
        GROUP BY h.id
        ORDER BY count DESC
        LIMIT 5
    ";
    $hotspots_result = mysqli_query($conn, $hotspots_query);
    $hotspot_labels = [];
    $hotspot_values = [];
    while ($row = mysqli_fetch_assoc($hotspots_result)) {
        $hotspot_labels[] = $row['location_name'];
        $hotspot_values[] = (int)$row['count'];
    }
    
    echo json_encode([
        'success' => true,
        'data' => [
            'status' => [
                'approved' => (int)$status['approved'],
                'pending' => (int)$status['pending'],
                'rejected' => (int)$status['rejected']
            ],
            'timeline' => [
                'labels' => array_reverse($timeline_labels),
                'values' => array_reverse($timeline_values)
            ],
            'levels' => [
                'heavy' => (int)$levels['heavy'],
                'moderate' => (int)$levels['moderate'],
                'light' => (int)$levels['light']
            ],
            'hotspots' => [
                'labels' => $hotspot_labels,
                'values' => $hotspot_values
            ]
        ]
    ]);
}

// Get top users (admin only)
function getTopUsers() {
    global $conn;
    
    $query = "
        SELECT u.fullname as name, COUNT(*) as count
        FROM traffic_reports tr
        JOIN users u ON tr.user_id = u.id
        GROUP BY u.id
        ORDER BY count DESC
        LIMIT 5
    ";
    
    $result = mysqli_query($conn, $query);
    $users = [];
    
    while ($row = mysqli_fetch_assoc($result)) {
        $users[] = [
            'name' => $row['name'],
            'count' => (int)$row['count']
        ];
    }
    
    echo json_encode(['success' => true, 'data' => $users]);
}

// Get top hotspots (admin only)
function getTopHotspots() {
    global $conn;
    
    $query = "
        SELECT h.location_name as name, COUNT(*) as count,
               AVG(CASE 
                   WHEN tr.traffic_level = 'Heavy' THEN 3
                   WHEN tr.traffic_level = 'Moderate' THEN 2
                   ELSE 1
               END) as avg_score
        FROM traffic_reports tr
        JOIN hotspots h ON tr.hotspot_id = h.id
        GROUP BY h.id
        ORDER BY count DESC
        LIMIT 5
    ";
    
    $result = mysqli_query($conn, $query);
    $hotspots = [];
    
    while ($row = mysqli_fetch_assoc($result)) {
        $avg_level = $row['avg_score'] > 2.5 ? 'Heavy' : ($row['avg_score'] > 1.5 ? 'Moderate' : 'Light');
        $hotspots[] = [
            'name' => $row['name'],
            'count' => (int)$row['count'],
            'avg_level' => $avg_level
        ];
    }
    
    echo json_encode(['success' => true, 'data' => $hotspots]);
}

// Get recent activity (admin only)
function getRecentActivity() {
    global $conn;
    
    $query = "
        SELECT u.fullname as user, 
               CONCAT(UCASE(LEFT(tr.status, 1)), LCASE(SUBSTRING(tr.status, 2)), ' report') as action,
               tr.created_at
        FROM traffic_reports tr
        JOIN users u ON tr.user_id = u.id
        ORDER BY tr.created_at DESC
        LIMIT 10
    ";
    
    $result = mysqli_query($conn, $query);
    $activities = [];
    
    while ($row = mysqli_fetch_assoc($result)) {
        $activities[] = [
            'user' => $row['user'],
            'action' => $row['action']
        ];
    }
    
    echo json_encode(['success' => true, 'data' => $activities]);
}

// Get hotspots for select dropdown
function getHotspotsForSelect() {
    global $conn;
    
    $query = "SELECT id, location_name FROM hotspots ORDER BY location_name";
    $result = mysqli_query($conn, $query);
    $hotspots = [];
    
    while ($row = mysqli_fetch_assoc($result)) {
        $hotspots[] = $row;
    }
    
    echo json_encode(['success' => true, 'data' => $hotspots]);
}

// Submit new report
function submitReport() {
    global $conn, $user_id;
    
    $hotspot_id = mysqli_real_escape_string($conn, $_POST['hotspot_id']);
    $traffic_level = mysqli_real_escape_string($conn, $_POST['traffic_level']);
    $description = mysqli_real_escape_string($conn, $_POST['description']);
    
    $query = "INSERT INTO traffic_reports (user_id, hotspot_id, traffic_level, description, status, created_at) 
              VALUES ('$user_id', '$hotspot_id', '$traffic_level', '$description', 'pending', NOW())";
    
    if (mysqli_query($conn, $query)) {
        echo json_encode(['success' => true, 'message' => 'Report submitted successfully']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Error submitting report']);
    }
}

// Update report status (approve/reject)
function updateReportStatus() {
    global $conn;
    
    $id = mysqli_real_escape_string($conn, $_POST['id']);
    $status = mysqli_real_escape_string($conn, $_POST['status']) == 'approve' ? 'approved' : 'rejected';
    
    $query = "UPDATE traffic_reports SET status = '$status' WHERE id = '$id'";
    
    if (mysqli_query($conn, $query)) {
        echo json_encode(['success' => true]);
    } else {
        echo json_encode(['success' => false]);
    }
}

// Get single report details
function getReportDetails() {
    global $conn;
    
    $id = mysqli_real_escape_string($conn, $_GET['id']);
    
    $query = "
        SELECT tr.*, u.fullname as user_name, h.location_name 
        FROM traffic_reports tr
        JOIN users u ON tr.user_id = u.id
        JOIN hotspots h ON tr.hotspot_id = h.id
        WHERE tr.id = '$id'
    ";
    
    $result = mysqli_query($conn, $query);
    
    if ($row = mysqli_fetch_assoc($result)) {
        echo json_encode([
            'success' => true,
            'data' => [
                'id' => $row['id'],
                'user_name' => $row['user_name'],
                'location_name' => $row['location_name'],
                'traffic_level' => $row['traffic_level'],
                'description' => $row['description'],
                'status' => $row['status'],
                'created_at' => date('M d, Y H:i:s', strtotime($row['created_at']))
            ]
        ]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Report not found']);
    }
}

// Export to CSV
function exportToCSV() {
    global $conn, $is_admin, $user_id;
    
    $date_condition = getDateCondition();
    $where = $date_condition ? "WHERE $date_condition" : "";
    
    // If not admin, only show user's own reports
    if (!$is_admin) {
        $where .= $where ? " AND tr.user_id = $user_id" : " WHERE tr.user_id = $user_id";
    }
    
    $query = "
        SELECT tr.id, u.fullname as user, h.location_name as location, 
               tr.traffic_level, tr.description, tr.status, tr.created_at
        FROM traffic_reports tr
        JOIN users u ON tr.user_id = u.id
        JOIN hotspots h ON tr.hotspot_id = h.id
        $where
        ORDER BY tr.created_at DESC
    ";
    
    $result = mysqli_query($conn, $query);
    
    // Set headers for CSV download
    header('Content-Type: text/csv');
    header('Content-Disposition: attachment; filename="traffic_reports_' . date('Y-m-d') . '.csv"');
    
    $output = fopen('php://output', 'w');
    
    // Add headers
    fputcsv($output, ['ID', 'User', 'Location', 'Traffic Level', 'Description', 'Status', 'Date']);
    
    // Add data
    while ($row = mysqli_fetch_assoc($result)) {
        fputcsv($output, $row);
    }
    
    fclose($output);
    exit;
}
?>