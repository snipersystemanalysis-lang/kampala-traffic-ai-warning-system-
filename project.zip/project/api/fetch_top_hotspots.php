<?php
session_start();
require_once '../config/database.php';

date_default_timezone_set('Africa/Nairobi');
header('Content-Type: application/json');

// Only admins can access
if ($_SESSION['role'] !== 'admin') {
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit;
}

$query = "SELECT 
    h.id,
    h.location_name as name,
    COUNT(tr.id) as report_count,
    CONCAT(ROUND(AVG(CASE 
        WHEN tr.traffic_level = 'heavy' THEN 90
        WHEN tr.traffic_level = 'moderate' THEN 60
        WHEN tr.traffic_level = 'light' THEN 30
        ELSE 45
    END)), '%') as avg_level
    FROM hotspots h
    LEFT JOIN traffic_reports tr ON h.id = tr.hotspot_id
    GROUP BY h.id
    ORDER BY report_count DESC
    LIMIT 5";

$result = mysqli_query($conn, $query);

$hotspots = array();
while ($row = mysqli_fetch_assoc($result)) {
    $hotspots[] = array(
        'id' => $row['id'],
        'name' => htmlspecialchars($row['name']),
        'count' => $row['report_count'],
        'avg_level' => $row['avg_level']
    );
}

echo json_encode(['success' => true, 'data' => $hotspots]);
?>