<?php
session_start();
require_once '../config/database.php';
require_once '../emailphp/PHPMailer-master/src/Exception.php';
require_once '../emailphp/PHPMailer-master/src/PHPMailer.php';
require_once '../emailphp/PHPMailer-master/src/SMTP.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
    exit;
}

$fullname = mysqli_real_escape_string($conn, $_POST['fullname']);
$email = mysqli_real_escape_string($conn, $_POST['email']);
$password = $_POST['password'];

// Validate inputs
if (empty($fullname) || empty($email) || empty($password)) {
    echo json_encode(['success' => false, 'message' => 'All fields are required']);
    exit;
}

// Validate email format
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    echo json_encode(['success' => false, 'message' => 'Invalid email format']);
    exit;
}

// Check if email exists
$check_query = "SELECT id FROM users WHERE email = '$email'";
$check_result = mysqli_query($conn, $check_query);

if (mysqli_num_rows($check_result) > 0) {
    echo json_encode(['success' => false, 'message' => 'Email already registered']);
    exit;
}

// Hash password
$hashed_password = password_hash($password, PASSWORD_DEFAULT);

// Insert user
$insert_query = "INSERT INTO users (fullname, email, password, role, email_verified) 
                 VALUES ('$fullname', '$email', '$hashed_password', 'user', 0)";

if (mysqli_query($conn, $insert_query)) {
    $user_id = mysqli_insert_id($conn);
    
    // Generate verification code in format: id-CODE
    // Example: 12-3F8K or 5-7B2M9
    $code_part = strtoupper(substr(md5(uniqid(mt_rand(), true)), 0, 5));
    $verification_code = $user_id . '-' . $code_part;
    
    $expires_at = date('Y-m-d H:i:s', strtotime('+10 minutes'));
    
    // Save verification code
    $code_query = "INSERT INTO email_verification (user_id, verification_code, code_expires) 
                   VALUES ($user_id, '$verification_code', '$expires_at')";
    mysqli_query($conn, $code_query);
    
    // Send verification email
    try {
        $mail = new PHPMailer(true);
        $mail->isMail(); // Use PHP mail() function
        
        $mail->setFrom('noreply@kampalatrafficaiwarningsystem.ugprice.com', 'Kampala Traffic Predictor');
        $mail->addAddress($email, $fullname);
        
        $mail->isHTML(true);
        $mail->Subject = 'Verify Your Email - Kampala Traffic Predictor';
        
        // HTML Email Body with id-code format
        $mail->Body = "
        <!DOCTYPE html>
        <html>
        <head>
            <style>
                body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
                .container { max-width: 600px; margin: 0 auto; padding: 20px; }
                .header { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 30px; text-align: center; border-radius: 10px 10px 0 0; }
                .content { padding: 30px; background: #f9f9f9; }
                .code-box { background: white; padding: 30px; text-align: center; margin: 20px 0; border-radius: 10px; box-shadow: 0 5px 15px rgba(0,0,0,0.1); }
                .code { font-size: 42px; font-weight: bold; letter-spacing: 4px; color: #667eea; font-family: 'Courier New', monospace; background: #f0f0f0; padding: 15px 25px; display: inline-block; border-radius: 8px; }
                .code-format { color: #999; font-size: 14px; margin-top: 10px; }
                .footer { text-align: center; margin-top: 30px; color: #666; font-size: 12px; }
                .note { color: #999; font-size: 13px; margin-top: 20px; }
            </style>
        </head>
        <body>
            <div class='container'>
                <div class='header'>
                    <h2>Welcome to Kampala Traffic Predictor!</h2>
                </div>
                <div class='content'>
                    <p>Dear $fullname,</p>
                    <p>Thank you for registering. Please verify your email address using the code below:</p>
                    <div class='code-box'>
                        <div class='code'>$verification_code</div>
                        <div class='code-format'>Format: UserID-CODE (include the dash)</div>
                    </div>
                    <p><strong>This code will expire in 10 minutes.</strong></p>
                    <p class='note'>If you didn't register for an account, please ignore this email.</p>
                </div>
                <div class='footer'>
                    <p>&copy; " . date('Y') . " Kampala Traffic Predictor. All rights reserved.</p>
                </div>
            </div>
        </body>
        </html>
        ";
        
        $mail->AltBody = "Your verification code is: $verification_code (Format: UserID-CODE - include the dash)\nIt expires in 10 minutes.";
        
        $mail->send();
        
        echo json_encode([
            'success' => true,
            'message' => 'Registration successful! Please check your email for verification code.',
            'user_id' => $user_id,
            'email' => $email
        ]);
        
    } catch (Exception $e) {
        // Email failed but user registered
        echo json_encode([
            'success' => true,
            'message' => 'Registration successful! Please contact support for verification.',
            'user_id' => $user_id,
            'email' => $email
        ]);
    }
    
} else {
    echo json_encode(['success' => false, 'message' => 'Registration failed. Please try again.']);
}
?>