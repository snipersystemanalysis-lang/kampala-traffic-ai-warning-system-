<?php
require_once '../config/database.php';
require_once '../includes/auth.php';

header('Content-Type: application/json');

// Start session if not started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Check if user is logged in and is admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit;
}

$action = isset($_GET['action']) ? $_GET['action'] : '';

switch ($action) {
    case 'get_analytics_data':
        getAnalyticsData();
        break;
    case 'get_hotspot_analysis':
        getHotspotAnalysis();
        break;
    case 'get_ai_insights':
        getAIInsights();
        break;
    default:
        echo json_encode(['success' => false, 'message' => 'Invalid action']);
}

function getAnalyticsData() {
    global $conn;
    
    // Get hotspots congestion data
    $hotspots_query = "
        SELECT h.location_name, 
               AVG(td.traffic_density) as avg_congestion
        FROM hotspots h
        LEFT JOIN traffic_data td ON h.id = td.hotspot_id
        WHERE td.recorded_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)
        GROUP BY h.id
        ORDER BY avg_congestion DESC
        LIMIT 5
    ";
    $hotspots_result = mysqli_query($conn, $hotspots_query);
    $hotspot_labels = [];
    $hotspot_values = [];
    while ($row = mysqli_fetch_assoc($hotspots_result)) {
        $hotspot_labels[] = $row['location_name'];
        $hotspot_values[] = round($row['avg_congestion'] ?: rand(40, 90));
    }
    
    // Get peak hours data
    $peak_hours_query = "
        SELECT HOUR(recorded_at) as hour, AVG(traffic_density) as avg_traffic
        FROM traffic_data
        WHERE recorded_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)
        GROUP BY HOUR(recorded_at)
        ORDER BY hour
    ";
    $peak_hours_result = mysqli_query($conn, $peak_hours_query);
    $peak_labels = [];
    $peak_values = [];
    while ($row = mysqli_fetch_assoc($peak_hours_result)) {
        $peak_labels[] = date('gA', mktime($row['hour'], 0, 0));
        $peak_values[] = round($row['avg_traffic']);
    }
    
    // If no data, provide sample
    if (empty($peak_labels)) {
        $peak_labels = ['6AM', '8AM', '10AM', '12PM', '2PM', '4PM', '6PM', '8PM'];
        $peak_values = [30, 75, 45, 55, 50, 65, 90, 55];
    }
    
    // Get daily trends
    $daily_query = "
        SELECT DAYNAME(recorded_at) as day,
               AVG(CASE WHEN HOUR(recorded_at) BETWEEN 7 AND 9 THEN traffic_density END) as morning,
               AVG(CASE WHEN HOUR(recorded_at) BETWEEN 17 AND 19 THEN traffic_density END) as evening
        FROM traffic_data
        WHERE recorded_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)
        GROUP BY DAYOFWEEK(recorded_at)
        ORDER BY DAYOFWEEK(recorded_at)
    ";
    $daily_result = mysqli_query($conn, $daily_query);
    $daily_labels = [];
    $morning_values = [];
    $evening_values = [];
    while ($row = mysqli_fetch_assoc($daily_result)) {
        $daily_labels[] = substr($row['day'], 0, 3);
        $morning_values[] = round($row['morning'] ?: rand(40, 80));
        $evening_values[] = round($row['evening'] ?: rand(50, 90));
    }
    
    // Get weekly patterns
    $weekly_query = "
        SELECT WEEK(recorded_at) as week,
               COUNT(*) as reports,
               AVG(traffic_density) as congestion
        FROM traffic_data
        WHERE recorded_at >= DATE_SUB(NOW(), INTERVAL 4 WEEK)
        GROUP BY WEEK(recorded_at)
        ORDER BY week DESC
        LIMIT 4
    ";
    $weekly_result = mysqli_query($conn, $weekly_query);
    $weekly_labels = [];
    $weekly_reports = [];
    $weekly_congestion = [];
    while ($row = mysqli_fetch_assoc($weekly_result)) {
        $weekly_labels[] = 'Week ' . $row['week'];
        $weekly_reports[] = (int)$row['reports'];
        $weekly_congestion[] = round($row['congestion']);
    }
    
    echo json_encode([
        'success' => true,
        'data' => [
            'hotspots' => [
                'labels' => $hotspot_labels,
                'values' => $hotspot_values
            ],
            'peak_hours' => [
                'labels' => $peak_labels,
                'values' => $peak_values
            ],
            'daily' => [
                'labels' => $daily_labels,
                'morning' => $morning_values,
                'evening' => $evening_values
            ],
            'weekly' => [
                'labels' => $weekly_labels,
                'reports' => $weekly_reports,
                'congestion' => $weekly_congestion
            ]
        ]
    ]);
}

function getHotspotAnalysis() {
    global $conn;
    
    $query = "
        SELECT h.location_name as name,
               COUNT(tr.id) as reports,
               AVG(CASE 
                   WHEN tr.traffic_level = 'Heavy' THEN 90
                   WHEN tr.traffic_level = 'Moderate' THEN 60
                   ELSE 30
               END) as avg_congestion,
               DATE_FORMAT(
                   (SELECT recorded_at FROM traffic_data td 
                    WHERE td.hotspot_id = h.id 
                    ORDER BY td.recorded_at DESC LIMIT 1),
                   '%h:%i %p'
               ) as last_updated,
               (SELECT HOUR(recorded_at) FROM traffic_data td 
                WHERE td.hotspot_id = h.id 
                GROUP BY HOUR(recorded_at)
                ORDER BY AVG(traffic_density) DESC LIMIT 1) as peak_hour
        FROM hotspots h
        LEFT JOIN traffic_reports tr ON h.id = tr.hotspot_id
        GROUP BY h.id
        HAVING reports > 0
        ORDER BY avg_congestion DESC
        LIMIT 8
    ";
    
    $result = mysqli_query($conn, $query);
    $hotspots = [];
    
    while ($row = mysqli_fetch_assoc($result)) {
        $trend = rand(-5, 10); // This should be calculated from historical data
        $peak_time = $row['peak_hour'] ? date('gA', mktime($row['peak_hour'], 0, 0)) . ' Peak' : 'Variable';
        
        $hotspots[] = [
            'name' => $row['name'],
            'reports' => (int)$row['reports'],
            'avg_congestion' => round($row['avg_congestion']),
            'peak_time' => $peak_time,
            'trend' => $trend
        ];
    }
    
    echo json_encode(['success' => true, 'data' => $hotspots]);
}

function getAIInsights() {
    global $conn;
    
    // Get peak hour
    $peak_query = "
        SELECT HOUR(recorded_at) as hour, AVG(traffic_density) as avg_traffic
        FROM traffic_data
        GROUP BY HOUR(recorded_at)
        ORDER BY avg_traffic DESC
        LIMIT 1
    ";
    $peak_result = mysqli_query($conn, $peak_query);
    $peak = mysqli_fetch_assoc($peak_result);
    $peak_hour = $peak ? date('gA', mktime($peak['hour'], 0, 0)) . ' - ' . date('gA', mktime($peak['hour'] + 2, 0, 0)) : '5:30 - 7:30 PM';
    $peak_traffic = $peak ? round($peak['avg_traffic']) : 92;
    
    // Get busiest hotspot
    $busiest_query = "
        SELECT h.location_name, COUNT(tr.id) as count
        FROM traffic_reports tr
        JOIN hotspots h ON tr.hotspot_id = h.id
        WHERE DATE(tr.created_at) = CURDATE()
        GROUP BY h.id
        ORDER BY count DESC
        LIMIT 1
    ";
    $busiest_result = mysqli_query($conn, $busiest_query);
    $busiest = mysqli_fetch_assoc($busiest_result);
    $busiest_hotspot = $busiest ? $busiest['location_name'] : 'Nakawa';
    $busiest_count = $busiest ? $busiest['count'] : 142;
    
    // Calculate trend
    $trend_query = "
        SELECT 
            (SELECT COUNT(*) FROM traffic_reports WHERE created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)) as this_week,
            (SELECT COUNT(*) FROM traffic_reports WHERE created_at BETWEEN DATE_SUB(NOW(), INTERVAL 14 DAY) AND DATE_SUB(NOW(), INTERVAL 7 DAY)) as last_week
    ";
    $trend_result = mysqli_query($conn, $trend_query);
    $trend_data = mysqli_fetch_assoc($trend_result);
    
    $this_week = (int)$trend_data['this_week'];
    $last_week = (int)$trend_data['last_week'];
    $trend_percent = $last_week > 0 ? round((($this_week - $last_week) / $last_week) * 100) : 8;
    $trend = ($trend_percent > 0 ? '+' : '') . $trend_percent . '%';
    $trend_class = $trend_percent > 0 ? 'trend-up' : ($trend_percent < 0 ? 'trend-down' : '');
    $trend_detail = $trend_percent > 0 ? 'Increasing vs last week' : ($trend_percent < 0 ? 'Decreasing vs last week' : 'Stable vs last week');
    
    // Get average congestion
    $avg_query = "SELECT AVG(traffic_density) as avg_cong FROM traffic_data WHERE DATE(recorded_at) = CURDATE()";
    $avg_result = mysqli_query($conn, $avg_query);
    $avg_cong = mysqli_fetch_assoc($avg_result);
    $avg_congestion = $avg_cong ? round($avg_cong['avg_cong']) : 74;
    
    $congestion_level = $avg_congestion > 80 ? 'Heavy' : ($avg_congestion > 60 ? 'Moderate-Heavy' : ($avg_congestion > 40 ? 'Moderate' : 'Light'));
    
    // Generate AI recommendation
    if ($avg_congestion > 75) {
        $recommendation = "⚠️ Heavy traffic detected. Avoid Nakawa and Clock Tower between 5-7 PM. Consider using Northern Bypass. Expect delays of 15-20 minutes.";
    } elseif ($avg_congestion > 50) {
        $recommendation = "🚦 Moderate traffic in most areas. Allow extra time for travel through Wandegeya and Ntinda. Traffic expected to clear by 8 PM.";
    } else {
        $recommendation = "✅ Light traffic conditions. Good time to travel. All major routes are flowing smoothly. Enjoy your drive!";
    }
    
    echo json_encode([
        'success' => true,
        'data' => [
            'peak_hour' => $peak_hour,
            'peak_traffic' => $peak_traffic,
            'busiest_hotspot' => $busiest_hotspot,
            'busiest_count' => $busiest_count,
            'trend' => $trend,
            'trend_class' => $trend_class,
            'trend_detail' => $trend_detail,
            'avg_congestion' => $avg_congestion,
            'congestion_level' => $congestion_level,
            'recommendation' => $recommendation
        ]
    ]);
}
?>