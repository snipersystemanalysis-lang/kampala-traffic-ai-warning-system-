<?php
session_start();
require_once '../config/database.php';

date_default_timezone_set('Africa/Nairobi');
header('Content-Type: application/json');

// Only admins can access
if ($_SESSION['role'] !== 'admin') {
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit;
}

$query = "SELECT 
    u.id,
    u.fullname as name,
    COUNT(tr.id) as report_count
    FROM users u
    LEFT JOIN traffic_reports tr ON u.id = tr.user_id
    WHERE u.role = 'user'
    GROUP BY u.id
    ORDER BY report_count DESC
    LIMIT 5";

$result = mysqli_query($conn, $query);

$users = array();
while ($row = mysqli_fetch_assoc($result)) {
    $users[] = array(
        'id' => $row['id'],
        'name' => htmlspecialchars($row['name']),
        'count' => $row['report_count']
    );
}

echo json_encode(['success' => true, 'data' => $users]);
?>