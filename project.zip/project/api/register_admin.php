<?php
require_once '../config/database.php';

header('Content-Type: application/json');

// Check if running on localhost (auto-verify)
$is_localhost = in_array($_SERVER['HTTP_HOST'], ['localhost', '127.0.0.1', '::1']);

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
    exit;
}

$fullname = mysqli_real_escape_string($conn, $_POST['fullname']);
$email = mysqli_real_escape_string($conn, $_POST['email']);
$password = $_POST['password'];

// Validate inputs
if (empty($fullname) || empty($email) || empty($password)) {
    echo json_encode(['success' => false, 'message' => 'All fields are required']);
    exit;
}

// Validate email format
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    echo json_encode(['success' => false, 'message' => 'Invalid email format']);
    exit;
}

// Check if email exists
$check_query = "SELECT id FROM users WHERE email = '$email'";
$check_result = mysqli_query($conn, $check_query);

if (mysqli_num_rows($check_result) > 0) {
    echo json_encode(['success' => false, 'message' => 'Email already registered']);
    exit;
}

// Hash password
$hashed_password = password_hash($password, PASSWORD_DEFAULT);

// ✅ Insert admin user with email_verified = 1 (no verification required)
$insert_query = "INSERT INTO users (fullname, email, password, role, email_verified, verified_at) 
                 VALUES ('$fullname', '$email', '$hashed_password', 'admin', 1, NOW())";

if (mysqli_query($conn, $insert_query)) {
    $user_id = mysqli_insert_id($conn);
    
    // Success response - no email sending, no verification required
    echo json_encode([
        'success' => true,
        'message' => 'Admin registration successful! You can now log in.',
        'user_id' => $user_id,
        'email' => $email,
        'auto_verified' => true
    ]);
    
} else {
    echo json_encode(['success' => false, 'message' => 'Registration failed. Please try again.']);
}
?>