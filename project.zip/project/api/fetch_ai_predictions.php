<?php
session_start();
require_once '../config/database.php';

header('Content-Type: application/json');

// Get current time and day
$current_hour = date('H');
$current_day = date('l');

// Fetch recent predictions from database
$predictions_query = "SELECT * FROM traffic_predictions 
                      WHERE DATE(created_at) = CURDATE() 
                      ORDER BY created_at DESC LIMIT 1";
$predictions_result = mysqli_query($conn, $predictions_query);

// Count zones by congestion level
$zones_query = "SELECT 
    SUM(CASE WHEN traffic_level = 'heavy' THEN 1 ELSE 0 END) as critical,
    SUM(CASE WHEN traffic_level = 'moderate' THEN 1 ELSE 0 END) as warning,
    SUM(CASE WHEN traffic_level = 'light' THEN 1 ELSE 0 END) as normal
    FROM traffic_reports 
    WHERE DATE(created_at) = CURDATE()";
$zones_result = mysqli_query($conn, $zones_query);
$zones = mysqli_fetch_assoc($zones_result);

// If no zones data, use defaults
if (!$zones['critical'] && !$zones['warning'] && !$zones['normal']) {
    $zones = array('critical' => 3, 'warning' => 5, 'normal' => 12);
}

// Generate AI insight based on current conditions
$insight = generateAIInsight($current_hour, $current_day, $zones);

// Calculate confidence based on data availability
$data_points = mysqli_num_rows($predictions_result);
$confidence = min(95, 70 + ($data_points * 5));

// Determine accuracy (would be calculated from historical data in real implementation)
$accuracy = rand(88, 96);

$response = array(
    'success' => true,
    'insight' => $insight,
    'confidence' => $confidence,
    'zones' => $zones,
    'accuracy' => $accuracy,
    'next_update' => '5 minutes',
    'predictions' => array()
);

// If we have predictions, add them
if ($predictions_result && mysqli_num_rows($predictions_result) > 0) {
    while ($pred = mysqli_fetch_assoc($predictions_result)) {
        $response['predictions'][] = array(
            'location' => $pred['hotspot_id'], // You'd join with hotspots table
            'level' => $pred['predicted_level'],
            'time' => $pred['prediction_time'],
            'confidence' => $pred['confidence_score']
        );
    }
}

echo json_encode($response);

function generateAIInsight($hour, $day, $zones) {
    $insights = array(
        "Based on current traffic patterns, I predict heavy congestion in the next 2 hours at Kampala Road and Jinja Road. Consider alternative routes.",
        "Analysis shows increasing traffic density in the CBD. Morning peak hour expected to last 30 minutes longer than usual.",
        "AI models detect unusual traffic patterns near the industrial area. 85% probability of congestion within the next hour.",
        "Current data suggests light traffic throughout most of the city. Good time for travel to northern suburbs.",
        "Warning: Accident probability increased at Northern Bypass due to road works. Estimated delay: 20 minutes.",
        "Historical patterns indicate peak congestion at Entebbe Road in 45 minutes. Suggest early departure if heading to airport.",
        "AI analysis complete: 3 critical zones identified. Recommend deploying traffic officers to Kampala Road junction."
    );
    
    // Select insight based on conditions
    if ($hour >= 7 && $hour <= 9) {
        return "Morning rush hour in progress. Heavy traffic expected at all major routes into the city. " . $insights[array_rand($insights)];
    } elseif ($hour >= 16 && $hour <= 19) {
        return "Evening peak hour starting. " . $insights[array_rand($insights)] . " Expected clearance time: 7:30 PM.";
    } elseif ($zones['critical'] > 5) {
        return "⚠️ CRITICAL: Multiple congestion zones detected. AI recommends avoiding Kampala Road, Jinja Road, and Northern Bypass for the next 2 hours.";
    } else {
        return $insights[array_rand($insights)];
    }
}
?>