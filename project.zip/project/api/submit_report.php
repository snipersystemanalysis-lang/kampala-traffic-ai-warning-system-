<?php
session_start();
require_once '../config/database.php';

date_default_timezone_set('Africa/Nairobi');
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
    exit;
}

$user_id = $_SESSION['user_id'];
$hotspot_id = intval($_POST['hotspot_id']);
$traffic_level = mysqli_real_escape_string($conn, strtolower($_POST['traffic_level']));
$description = mysqli_real_escape_string($conn, $_POST['description']);

// Validate
if (!$hotspot_id || !$traffic_level || !$description) {
    echo json_encode(['success' => false, 'message' => 'All fields are required']);
    exit;
}

// Check if hotspot exists
$check_query = "SELECT id FROM hotspots WHERE id = $hotspot_id";
$check_result = mysqli_query($conn, $check_query);

if (mysqli_num_rows($check_result) === 0) {
    echo json_encode(['success' => false, 'message' => 'Invalid hotspot']);
    exit;
}

// Insert report
$query = "INSERT INTO traffic_reports (user_id, hotspot_id, traffic_level, description, status) 
          VALUES ($user_id, $hotspot_id, '$traffic_level', '$description', 'pending')";

if (mysqli_query($conn, $query)) {
    echo json_encode(['success' => true, 'message' => 'Report submitted successfully']);
} else {
    echo json_encode(['success' => false, 'message' => 'Failed to submit report']);
}
?>