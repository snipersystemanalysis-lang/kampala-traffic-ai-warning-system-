<?php
session_start();
require_once '../config/database.php';

date_default_timezone_set('Africa/Nairobi');
header('Content-Type: application/json');

$user_id = $_SESSION['user_id'];
$role = $_SESSION['role'];
$filter = isset($_GET['filter']) ? $_GET['filter'] : 'today';
$date_from = isset($_GET['date_from']) ? $_GET['date_from'] : '';
$date_to = isset($_GET['date_to']) ? $_GET['date_to'] : '';

// Build date filter
$date_condition = "";
switch($filter) {
    case 'today':
        $date_condition = "DATE(created_at) = CURDATE()";
        break;
    case 'yesterday':
        $date_condition = "DATE(created_at) = DATE_SUB(CURDATE(), INTERVAL 1 DAY)";
        break;
    case 'thisWeek':
        $date_condition = "YEARWEEK(created_at) = YEARWEEK(CURDATE())";
        break;
    case 'thisMonth':
        $date_condition = "MONTH(created_at) = MONTH(CURDATE()) AND YEAR(created_at) = YEAR(CURDATE())";
        break;
    case 'lastMonth':
        $date_condition = "MONTH(created_at) = MONTH(DATE_SUB(CURDATE(), INTERVAL 1 MONTH)) AND YEAR(created_at) = YEAR(DATE_SUB(CURDATE(), INTERVAL 1 MONTH))";
        break;
    case 'thisYear':
        $date_condition = "YEAR(created_at) = YEAR(CURDATE())";
        break;
    case 'lastYear':
        $date_condition = "YEAR(created_at) = YEAR(DATE_SUB(CURDATE(), INTERVAL 1 YEAR))";
        break;
    case 'custom':
        if ($date_from && $date_to) {
            $date_condition = "DATE(created_at) BETWEEN '$date_from' AND '$date_to'";
        }
        break;
    default:
        $date_condition = "1=1";
}

// Total reports
$total_query = "SELECT COUNT(*) as total FROM traffic_reports WHERE $date_condition";
$total_result = mysqli_query($conn, $total_query);
$total = mysqli_fetch_assoc($total_result)['total'];

// Approved reports
$approved_query = "SELECT COUNT(*) as total FROM traffic_reports WHERE status = 'approved' AND $date_condition";
$approved_result = mysqli_query($conn, $approved_query);
$approved = mysqli_fetch_assoc($approved_result)['total'];

// Pending reports
$pending_query = "SELECT COUNT(*) as total FROM traffic_reports WHERE status = 'pending' AND $date_condition";
$pending_result = mysqli_query($conn, $pending_query);
$pending = mysqli_fetch_assoc($pending_result)['total'];

// Rejected reports
$rejected_query = "SELECT COUNT(*) as total FROM traffic_reports WHERE status = 'rejected' AND $date_condition";
$rejected_result = mysqli_query($conn, $rejected_query);
$rejected = mysqli_fetch_assoc($rejected_result)['total'];

// Active users (users who submitted reports)
$users_query = "SELECT COUNT(DISTINCT user_id) as total FROM traffic_reports WHERE $date_condition";
$users_result = mysqli_query($conn, $users_query);
$active_users = mysqli_fetch_assoc($users_result)['total'];

// Active hotspots
$hotspots_query = "SELECT COUNT(DISTINCT hotspot_id) as total FROM traffic_reports WHERE $date_condition";
$hotspots_result = mysqli_query($conn, $hotspots_query);
$active_hotspots = mysqli_fetch_assoc($hotspots_result)['total'];

$stats = array(
    'total' => $total,
    'approved' => $approved,
    'pending' => $pending,
    'rejected' => $rejected,
    'active_users' => $active_users,
    'active_hotspots' => $active_hotspots
);

echo json_encode(['success' => true, 'data' => $stats]);
?>