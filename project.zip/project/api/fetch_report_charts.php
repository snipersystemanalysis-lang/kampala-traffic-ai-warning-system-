<?php
session_start();
require_once '../config/database.php';

date_default_timezone_set('Africa/Nairobi');
header('Content-Type: application/json');

// Only admins can access charts
if ($_SESSION['role'] !== 'admin') {
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit;
}

$filter = isset($_GET['filter']) ? $_GET['filter'] : 'today';
$date_from = isset($_GET['date_from']) ? $_GET['date_from'] : '';
$date_to = isset($_GET['date_to']) ? $_GET['date_to'] : '';

// Build date filter
$date_condition = "";
switch($filter) {
    case 'today':
        $date_condition = "DATE(created_at) = CURDATE()";
        break;
    case 'yesterday':
        $date_condition = "DATE(created_at) = DATE_SUB(CURDATE(), INTERVAL 1 DAY)";
        break;
    case 'thisWeek':
        $date_condition = "YEARWEEK(created_at) = YEARWEEK(CURDATE())";
        break;
    case 'thisMonth':
        $date_condition = "MONTH(created_at) = MONTH(CURDATE()) AND YEAR(created_at) = YEAR(CURDATE())";
        break;
    case 'lastMonth':
        $date_condition = "MONTH(created_at) = MONTH(DATE_SUB(CURDATE(), INTERVAL 1 MONTH)) AND YEAR(created_at) = YEAR(DATE_SUB(CURDATE(), INTERVAL 1 MONTH))";
        break;
    case 'thisYear':
        $date_condition = "YEAR(created_at) = YEAR(CURDATE())";
        break;
    case 'lastYear':
        $date_condition = "YEAR(created_at) = YEAR(DATE_SUB(CURDATE(), INTERVAL 1 YEAR))";
        break;
    case 'custom':
        if ($date_from && $date_to) {
            $date_condition = "DATE(created_at) BETWEEN '$date_from' AND '$date_to'";
        }
        break;
    default:
        $date_condition = "1=1";
}

// Status counts
$status_query = "SELECT 
    SUM(CASE WHEN status = 'approved' THEN 1 ELSE 0 END) as approved,
    SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END) as pending,
    SUM(CASE WHEN status = 'rejected' THEN 1 ELSE 0 END) as rejected
    FROM traffic_reports WHERE $date_condition";
$status_result = mysqli_query($conn, $status_query);
$status = mysqli_fetch_assoc($status_result);

// Timeline data (last 7 days)
$timeline_query = "SELECT 
    DATE(created_at) as date,
    COUNT(*) as count
    FROM traffic_reports 
    WHERE created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)
    GROUP BY DATE(created_at)
    ORDER BY date ASC";
$timeline_result = mysqli_query($conn, $timeline_query);

$timeline_labels = [];
$timeline_values = [];

while ($row = mysqli_fetch_assoc($timeline_result)) {
    $timeline_labels[] = date('d M', strtotime($row['date']));
    $timeline_values[] = $row['count'];
}

// Traffic levels
$levels_query = "SELECT 
    SUM(CASE WHEN traffic_level = 'heavy' THEN 1 ELSE 0 END) as heavy,
    SUM(CASE WHEN traffic_level = 'moderate' THEN 1 ELSE 0 END) as moderate,
    SUM(CASE WHEN traffic_level = 'light' THEN 1 ELSE 0 END) as light
    FROM traffic_reports WHERE $date_condition";
$levels_result = mysqli_query($conn, $levels_query);
$levels = mysqli_fetch_assoc($levels_result);

// Top hotspots
$hotspots_query = "SELECT 
    h.location_name,
    COUNT(*) as report_count
    FROM traffic_reports tr
    JOIN hotspots h ON tr.hotspot_id = h.id
    WHERE $date_condition
    GROUP BY tr.hotspot_id
    ORDER BY report_count DESC
    LIMIT 5";
$hotspots_result = mysqli_query($conn, $hotspots_query);

$hotspot_labels = [];
$hotspot_values = [];

while ($row = mysqli_fetch_assoc($hotspots_result)) {
    $hotspot_labels[] = $row['location_name'];
    $hotspot_values[] = $row['report_count'];
}

$data = array(
    'status' => array(
        'approved' => (int)$status['approved'],
        'pending' => (int)$status['pending'],
        'rejected' => (int)$status['rejected']
    ),
    'timeline' => array(
        'labels' => $timeline_labels,
        'values' => $timeline_values
    ),
    'levels' => array(
        'heavy' => (int)$levels['heavy'],
        'moderate' => (int)$levels['moderate'],
        'light' => (int)$levels['light']
    ),
    'hotspots' => array(
        'labels' => $hotspot_labels,
        'values' => $hotspot_values
    )
);

echo json_encode(['success' => true, 'data' => $data]);
?>