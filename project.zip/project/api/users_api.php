<?php
session_start();
require_once '../config/database.php';

// Set timezone
date_default_timezone_set('Africa/Nairobi');

header('Content-Type: application/json');

// Check if user is logged in and is admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit;
}

$action = isset($_POST['action']) ? $_POST['action'] : (isset($_GET['action']) ? $_GET['action'] : '');

switch($action) {
    case 'getAllData':
        getAllData();
        break;
    case 'addUser':
        addUser();
        break;
    case 'getUserDetails':
        getUserDetails();
        break;
    case 'getUserLogs':
        getUserLogs();
        break;
    case 'editUser':
        editUser();
        break;
    case 'suspendUser':
        suspendUser();
        break;
    case 'activateUser':
        activateUser();
        break;
    case 'deleteUser':
        deleteUser();
        break;
    case 'export':
        exportUsers();
        break;
    default:
        echo json_encode(['success' => false, 'message' => 'Invalid action']);
}

function getAllData() {
    global $conn;
    
    $filter = isset($_POST['filter']) ? $_POST['filter'] : 'all';
    $search = isset($_POST['search']) ? $_POST['search'] : '';
    $page = isset($_POST['page']) ? intval($_POST['page']) : 1;
    $limit = isset($_POST['limit']) ? intval($_POST['limit']) : 10;
    $offset = ($page - 1) * $limit;
    
    // Build WHERE conditions
    $where_conditions = ["role != 'admin'"]; // Exclude current admin from list
    
    if (!empty($search)) {
        $search = mysqli_real_escape_string($conn, $search);
        $where_conditions[] = "(fullname LIKE '%$search%' OR email LIKE '%$search%')";
    }
    
    switch($filter) {
        case 'active':
            $where_conditions[] = "status = 'active'";
            break;
        case 'suspended':
            $where_conditions[] = "status = 'suspended'";
            break;
        case 'pending':
            $where_conditions[] = "status = 'pending'";
            break;
        case 'admins':
            $where_conditions = ["role = 'admin'"];
            break;
        default:
            break;
    }
    
    $where_sql = 'WHERE ' . implode(' AND ', $where_conditions);
    
    // Get total count
    $count_query = "SELECT COUNT(*) as total FROM users $where_sql";
    $count_result = mysqli_query($conn, $count_query);
    $total = mysqli_fetch_assoc($count_result)['total'];
    $total_pages = ceil($total / $limit);
    
    // Get paginated users
    $users_query = "SELECT id, fullname, email, role, COALESCE(status, 'pending') as status, 
                    last_login, last_ip, email_verified, created_at 
                    FROM users 
                    $where_sql 
                    ORDER BY id DESC 
                    LIMIT $limit OFFSET $offset";
    $users_result = mysqli_query($conn, $users_query);
    
    $users = array();
    while ($row = mysqli_fetch_assoc($users_result)) {
        $users[] = $row;
    }
    
    // Get statistics
    $stats_query = "SELECT 
        COUNT(*) as total,
        SUM(CASE WHEN COALESCE(status, 'pending') = 'active' THEN 1 ELSE 0 END) as active,
        SUM(CASE WHEN COALESCE(status, 'pending') = 'suspended' THEN 1 ELSE 0 END) as suspended,
        SUM(CASE WHEN DATE(created_at) = CURDATE() THEN 1 ELSE 0 END) as new_today,
        SUM(CASE WHEN DATE(last_login) = CURDATE() THEN 1 ELSE 0 END) as active_today
        FROM users";
    $stats_result = mysqli_query($conn, $stats_query);
    $stats = mysqli_fetch_assoc($stats_result);
    
    // Get most active users (excluding admin)
    $most_active_query = "SELECT 
        u.id, u.fullname, 
        COUNT(al.id) as activity_count,
        MAX(al.created_at) as last_action
        FROM users u
        LEFT JOIN user_activity_logs al ON u.id = al.user_id
        WHERE u.role != 'admin'
        GROUP BY u.id
        ORDER BY activity_count DESC
        LIMIT 5";
    $most_active_result = mysqli_query($conn, $most_active_query);
    $most_active = array();
    while ($row = mysqli_fetch_assoc($most_active_result)) {
        $row['last_action'] = $row['last_action'] ? time_ago($row['last_action']) : 'Never';
        $most_active[] = $row;
    }
    
    // Get least active users
    $least_active_query = "SELECT 
        u.id, u.fullname, 
        COUNT(al.id) as activity_count,
        MAX(al.created_at) as last_action
        FROM users u
        LEFT JOIN user_activity_logs al ON u.id = al.user_id
        WHERE u.role != 'admin'
        GROUP BY u.id
        HAVING activity_count < 5 OR activity_count IS NULL
        ORDER BY activity_count ASC, last_action ASC
        LIMIT 5";
    $least_active_result = mysqli_query($conn, $least_active_query);
    $least_active = array();
    while ($row = mysqli_fetch_assoc($least_active_result)) {
        $row['last_action'] = $row['last_action'] ? time_ago($row['last_action']) : 'Never';
        $least_active[] = $row;
    }
    
    // Get system logs
    $logs_query = "SELECT l.*, u.fullname as created_by_name 
                    FROM system_logs l
                    LEFT JOIN users u ON l.created_by = u.id
                    ORDER BY l.created_at DESC
                    LIMIT 20";
    $logs_result = mysqli_query($conn, $logs_query);
    $logs = array();
    while ($row = mysqli_fetch_assoc($logs_result)) {
        $row['created_at'] = date('d M Y H:i', strtotime($row['created_at']));
        $row['created_by'] = $row['created_by_name'] ?? 'System';
        $logs[] = $row;
    }
    
    echo json_encode([
        'success' => true,
        'data' => [
            'users' => $users,
            'stats' => $stats,
            'pagination' => [
                'total' => $total,
                'per_page' => $limit,
                'current_page' => $page,
                'total_pages' => $total_pages
            ],
            'most_active' => $most_active,
            'least_active' => $least_active,
            'system_logs' => $logs
        ]
    ]);
}

function addUser() {
    global $conn, $_SESSION;
    
    $fullname = mysqli_real_escape_string($conn, $_POST['fullname']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $password = $_POST['password'];
    $role = mysqli_real_escape_string($conn, $_POST['role']);
    $status = mysqli_real_escape_string($conn, $_POST['status']);
    
    // Validate inputs
    if (empty($fullname) || empty($email) || empty($password)) {
        echo json_encode(['success' => false, 'message' => 'All fields are required']);
        exit;
    }
    
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        echo json_encode(['success' => false, 'message' => 'Invalid email format']);
        exit;
    }
    
    if (strlen($password) < 6) {
        echo json_encode(['success' => false, 'message' => 'Password must be at least 6 characters']);
        exit;
    }
    
    // Check if email exists
    $check_query = "SELECT id FROM users WHERE email = '$email'";
    $check_result = mysqli_query($conn, $check_query);
    
    if (mysqli_num_rows($check_result) > 0) {
        echo json_encode(['success' => false, 'message' => 'Email already registered']);
        exit;
    }
    
    // Hash password
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);
    
    // ✅ Insert user with email_verified = 1 (no verification required)
    $insert_query = "INSERT INTO users (fullname, email, password, role, status, email_verified) 
                     VALUES ('$fullname', '$email', '$hashed_password', '$role', '$status', 1)";
    
    if (mysqli_query($conn, $insert_query)) {
        $user_id = mysqli_insert_id($conn);
        
        // Log the action
        $log_query = "INSERT INTO system_logs (log_type, message, details, created_by) 
                      VALUES ('success', 'User created', 'New user: $fullname ($email) created by admin', {$_SESSION['user_id']})";
        mysqli_query($conn, $log_query);
        
        echo json_encode([
            'success' => true, 
            'message' => 'User created successfully!'
        ]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Failed to create user']);
    }
}

function getUserDetails() {
    global $conn;
    
    $id = intval($_POST['id']);
    
    $query = "SELECT u.*, 
              (SELECT COUNT(*) FROM user_activity_logs WHERE user_id = u.id) as activity_count
              FROM users u 
              WHERE u.id = $id";
    $result = mysqli_query($conn, $query);
    
    if (mysqli_num_rows($result) > 0) {
        $user = mysqli_fetch_assoc($result);
        echo json_encode(['success' => true, 'data' => $user]);
    } else {
        echo json_encode(['success' => false, 'message' => 'User not found']);
    }
}

function getUserLogs() {
    global $conn;
    
    $id = intval($_POST['id']);
    
    $query = "SELECT * FROM user_activity_logs 
              WHERE user_id = $id 
              ORDER BY created_at DESC 
              LIMIT 50";
    $result = mysqli_query($conn, $query);
    
    $logs = array();
    while ($row = mysqli_fetch_assoc($result)) {
        $row['created_at'] = date('d M Y H:i', strtotime($row['created_at']));
        $logs[] = $row;
    }
    
    echo json_encode(['success' => true, 'data' => $logs]);
}

function editUser() {
    global $conn, $_SESSION;
    
    $id = intval($_POST['id']);
    $fullname = mysqli_real_escape_string($conn, $_POST['fullname']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $role = mysqli_real_escape_string($conn, $_POST['role']);
    $status = mysqli_real_escape_string($conn, $_POST['status']);
    $new_password = isset($_POST['new_password']) && !empty($_POST['new_password']) ? $_POST['new_password'] : null;
    
    $update_fields = "fullname = '$fullname', email = '$email', role = '$role', status = '$status'";
    
    if ($new_password) {
        $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
        $update_fields .= ", password = '$hashed_password'";
    }
    
    $query = "UPDATE users SET $update_fields WHERE id = $id";
    
    if (mysqli_query($conn, $query)) {
        $log_query = "INSERT INTO system_logs (log_type, message, details, created_by) 
                      VALUES ('info', 'User updated', 'User ID: $id updated by admin', {$_SESSION['user_id']})";
        mysqli_query($conn, $log_query);
        
        echo json_encode(['success' => true, 'message' => 'User updated successfully']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Failed to update user']);
    }
}

function suspendUser() {
    global $conn, $_SESSION;
    
    $id = intval($_POST['id']);
    $reason = isset($_POST['reason']) ? mysqli_real_escape_string($conn, $_POST['reason']) : 'No reason provided';
    
    $query = "UPDATE users SET status = 'suspended' WHERE id = $id";
    
    if (mysqli_query($conn, $query)) {
        $log_query = "INSERT INTO system_logs (log_type, message, details, created_by) 
                      VALUES ('warning', 'User suspended', 'User ID: $id suspended. Reason: $reason', {$_SESSION['user_id']})";
        mysqli_query($conn, $log_query);
        
        echo json_encode(['success' => true, 'message' => 'User suspended successfully']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Failed to suspend user']);
    }
}

function activateUser() {
    global $conn, $_SESSION;
    
    $id = intval($_POST['id']);
    
    $query = "UPDATE users SET status = 'active' WHERE id = $id";
    
    if (mysqli_query($conn, $query)) {
        $log_query = "INSERT INTO system_logs (log_type, message, details, created_by) 
                      VALUES ('success', 'User activated', 'User ID: $id activated', {$_SESSION['user_id']})";
        mysqli_query($conn, $log_query);
        
        echo json_encode(['success' => true, 'message' => 'User activated successfully']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Failed to activate user']);
    }
}

function deleteUser() {
    global $conn, $_SESSION;
    
    $id = intval($_POST['id']);
    
    $user_query = "SELECT fullname, email FROM users WHERE id = $id";
    $user_result = mysqli_query($conn, $user_query);
    $user = mysqli_fetch_assoc($user_result);
    
    $query = "DELETE FROM users WHERE id = $id";
    
    if (mysqli_query($conn, $query)) {
        $log_query = "INSERT INTO system_logs (log_type, message, details, created_by) 
                      VALUES ('error', 'User deleted', 'User: {$user['fullname']} ({$user['email']}) deleted', {$_SESSION['user_id']})";
        mysqli_query($conn, $log_query);
        
        echo json_encode(['success' => true, 'message' => 'User deleted successfully']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Failed to delete user']);
    }
}

function exportUsers() {
    global $conn;
    
    $query = "SELECT id, fullname, email, role, status, last_login, created_at FROM users ORDER BY id DESC";
    $result = mysqli_query($conn, $query);
    
    $filename = "users_export_" . date('Y-m-d') . ".csv";
    
    header('Content-Type: text/csv');
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    
    $output = fopen('php://output', 'w');
    fputcsv($output, ['ID', 'Full Name', 'Email', 'Role', 'Status', 'Last Login', 'Registered']);
    
    while ($row = mysqli_fetch_assoc($result)) {
        fputcsv($output, $row);
    }
    
    fclose($output);
    exit;
}

function time_ago($datetime) {
    $time = strtotime($datetime);
    $now = time();
    $diff = $now - $time;
    
    if ($diff < 60) {
        return 'just now';
    } elseif ($diff < 3600) {
        $mins = floor($diff / 60);
        return $mins . ' minute' . ($mins > 1 ? 's' : '') . ' ago';
    } elseif ($diff < 86400) {
        $hours = floor($diff / 3600);
        return $hours . ' hour' . ($hours > 1 ? 's' : '') . ' ago';
    } elseif ($diff < 604800) {
        $days = floor($diff / 86400);
        return $days . ' day' . ($days > 1 ? 's' : '') . ' ago';
    } else {
        return date('d M Y', $time);
    }
}
?>