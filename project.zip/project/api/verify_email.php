<?php
require_once '../config/database.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $user_id = intval($_POST['user_id']);
    $verification_code = mysqli_real_escape_string($conn, $_POST['verification_code']);

    // Check if code exists and is not expired
    $query = "SELECT * FROM email_verification 
              WHERE user_id = ? 
              AND verification_code = ? 
              AND verified_at IS NULL 
              AND code_expires > NOW() 
              ORDER BY id DESC LIMIT 1";
    
    $stmt = mysqli_prepare($conn, $query);
    mysqli_stmt_bind_param($stmt, "is", $user_id, $verification_code);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);

    if (mysqli_num_rows($result) > 0) {
        // Update verification record
        $update_verification = "UPDATE email_verification SET verified_at = NOW() WHERE user_id = ? AND verification_code = ?";
        $update_stmt = mysqli_prepare($conn, $update_verification);
        mysqli_stmt_bind_param($update_stmt, "is", $user_id, $verification_code);
        mysqli_stmt_execute($update_stmt);
        
        // Update user
        $update_user = "UPDATE users SET email_verified = 1, verified_at = NOW() WHERE id = ?";
        $user_stmt = mysqli_prepare($conn, $update_user);
        mysqli_stmt_bind_param($user_stmt, "i", $user_id);
        
        if (mysqli_stmt_execute($user_stmt)) {
            echo json_encode(['success' => true, 'message' => 'Email verified successfully! You can now login.']);
        } else {
            echo json_encode(['success' => false, 'message' => 'Verification failed. Please try again.']);
        }
    } else {
        // Check if code expired
        $check_expired = "SELECT * FROM email_verification 
                          WHERE user_id = ? 
                          AND verification_code = ? 
                          AND code_expires <= NOW()";
        $expired_stmt = mysqli_prepare($conn, $check_expired);
        mysqli_stmt_bind_param($expired_stmt, "is", $user_id, $verification_code);
        mysqli_stmt_execute($expired_stmt);
        $expired_result = mysqli_stmt_get_result($expired_stmt);
        
        if (mysqli_num_rows($expired_result) > 0) {
            echo json_encode(['success' => false, 'message' => 'Verification code has expired. Please request a new one.']);
        } else {
            echo json_encode(['success' => false, 'message' => 'Invalid verification code.']);
        }
    }
}
?>