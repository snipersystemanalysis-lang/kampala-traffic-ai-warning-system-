<?php
require_once '../config/database.php';
require_once '../emailphp/PHPMailer-master/src/Exception.php';
require_once '../emailphp/PHPMailer-master/src/PHPMailer.php';
require_once '../emailphp/PHPMailer-master/src/SMTP.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $user_id = intval($_POST['user_id']);

    // Get user details
    $user_query = "SELECT * FROM users WHERE id = ?";
    $user_stmt = mysqli_prepare($conn, $user_query);
    mysqli_stmt_bind_param($user_stmt, "i", $user_id);
    mysqli_stmt_execute($user_stmt);
    $user_result = mysqli_stmt_get_result($user_stmt);
    $user = mysqli_fetch_assoc($user_result);

    if (!$user) {
        echo json_encode(['success' => false, 'message' => 'User not found']);
        exit();
    }

    // Check if already verified
    if ($user['email_verified'] == 1) {
        echo json_encode(['success' => false, 'message' => 'Email already verified']);
        exit();
    }

    // Generate verification code in format: id-CODE
    $code_part = strtoupper(substr(md5(uniqid(mt_rand(), true)), 0, 5));
    $verification_code = $user_id . '-' . $code_part;
    $expires_at = date('Y-m-d H:i:s', strtotime('+10 minutes'));

    // Invalidate old codes
    $invalidate_query = "UPDATE email_verification SET verified_at = NOW() WHERE user_id = ? AND verified_at IS NULL";
    $invalidate_stmt = mysqli_prepare($conn, $invalidate_query);
    mysqli_stmt_bind_param($invalidate_stmt, "i", $user_id);
    mysqli_stmt_execute($invalidate_stmt);

    // Save new code
    $code_query = "INSERT INTO email_verification (user_id, verification_code, code_expires) VALUES (?, ?, ?)";
    $code_stmt = mysqli_prepare($conn, $code_query);
    mysqli_stmt_bind_param($code_stmt, "iss", $user_id, $verification_code, $expires_at);
    mysqli_stmt_execute($code_stmt);

    // Send verification email
    try {
        $mail = new PHPMailer(true);
        $mail->isMail();
        
        $mail->setFrom('noreply@kampalatrafficaiwarningsystem.ugprice.com', 'Kampala Traffic Predictor');
        $mail->addAddress($user['email'], $user['fullname']);
        
        $mail->isHTML(true);
        $mail->Subject = 'New Verification Code - Kampala Traffic Predictor';
        
        $mail->Body = "
        <!DOCTYPE html>
        <html>
        <head>
            <style>
                body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
                .container { max-width: 600px; margin: 0 auto; padding: 20px; }
                .header { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 30px; text-align: center; border-radius: 10px 10px 0 0; }
                .content { padding: 30px; background: #f9f9f9; }
                .code-box { background: white; padding: 30px; text-align: center; margin: 20px 0; border-radius: 10px; box-shadow: 0 5px 15px rgba(0,0,0,0.1); }
                .code { font-size: 42px; font-weight: bold; letter-spacing: 4px; color: #667eea; font-family: 'Courier New', monospace; background: #f0f0f0; padding: 15px 25px; display: inline-block; border-radius: 8px; }
                .code-format { color: #999; font-size: 14px; margin-top: 10px; }
                .footer { text-align: center; margin-top: 30px; color: #666; font-size: 12px; }
                .note { color: #999; font-size: 13px; margin-top: 20px; }
            </style>
        </head>
        <body>
            <div class='container'>
                <div class='header'>
                    <h2>New Verification Code</h2>
                </div>
                <div class='content'>
                    <p>Dear {$user['fullname']},</p>
                    <p>Here is your new verification code:</p>
                    <div class='code-box'>
                        <div class='code'>$verification_code</div>
                        <div class='code-format'>Format: UserID-CODE (include the dash)</div>
                    </div>
                    <p><strong>This code will expire in 10 minutes.</strong></p>
                </div>
                <div class='footer'>
                    <p>&copy; " . date('Y') . " Kampala Traffic Predictor. All rights reserved.</p>
                </div>
            </div>
        </body>
        </html>
        ";
        
        $mail->AltBody = "Your new verification code is: $verification_code (Format: UserID-CODE - include the dash)\nIt expires in 10 minutes.";
        
        $mail->send();
        
        echo json_encode(['success' => true, 'message' => 'Verification code resent successfully!']);
        
    } catch (Exception $e) {
        echo json_encode(['success' => false, 'message' => 'Failed to send verification email. Please try again.']);
    }
}
?>