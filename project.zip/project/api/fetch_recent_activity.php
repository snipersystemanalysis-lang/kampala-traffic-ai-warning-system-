<?php
session_start();
require_once '../config/database.php';

date_default_timezone_set('Africa/Nairobi');
header('Content-Type: application/json');

// Only admins can access
if ($_SESSION['role'] !== 'admin') {
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit;
}

$query = "SELECT 
    u.fullname as user,
    CONCAT(
        CASE 
            WHEN tr.status = 'approved' THEN 'approved a report at '
            WHEN tr.status = 'rejected' THEN 'rejected a report at '
            ELSE 'submitted a report at '
        END,
        h.location_name
    ) as action,
    tr.created_at as time
    FROM traffic_reports tr
    JOIN users u ON tr.user_id = u.id
    JOIN hotspots h ON tr.hotspot_id = h.id
    ORDER BY tr.created_at DESC
    LIMIT 10";

$result = mysqli_query($conn, $query);

$activities = array();
while ($row = mysqli_fetch_assoc($result)) {
    $time_ago = time_elapsed_string($row['time']);
    $activities[] = array(
        'user' => htmlspecialchars($row['user']),
        'action' => $row['action'] . ' ' . $time_ago
    );
}

echo json_encode(['success' => true, 'data' => $activities]);

function time_elapsed_string($datetime) {
    $now = new DateTime();
    $ago = new DateTime($datetime);
    $diff = $now->diff($ago);

    if ($diff->d > 0) return $diff->d . ' day' . ($diff->d > 1 ? 's' : '') . ' ago';
    if ($diff->h > 0) return $diff->h . ' hour' . ($diff->h > 1 ? 's' : '') . ' ago';
    if ($diff->i > 0) return $diff->i . ' minute' . ($diff->i > 1 ? 's' : '') . ' ago';
    return 'just now';
}
?>