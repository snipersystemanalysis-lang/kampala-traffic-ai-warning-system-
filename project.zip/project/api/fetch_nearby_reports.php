<?php
session_start();
require_once '../config/database.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $lat = floatval($_POST['lat']);
    $lng = floatval($_POST['lng']);
    $radius = intval($_POST['radius']); // radius in km
    
    // Fetch nearby reports within radius
    $query = "SELECT 
                AVG(CASE 
                    WHEN traffic_level = 'heavy' THEN 90
                    WHEN traffic_level = 'moderate' THEN 60
                    WHEN traffic_level = 'light' THEN 30
                    ELSE 45
                END) as avg_congestion,
                COUNT(*) as report_count
              FROM traffic_reports tr
              JOIN hotspots h ON tr.hotspot_id = h.id
              WHERE tr.status = 'approved'
              AND tr.created_at >= DATE_SUB(NOW(), INTERVAL 2 HOUR)
              AND (6371 * acos(cos(radians($lat)) * cos(radians(h.latitude)) * cos(radians(h.longitude) - radians($lng)) + sin(radians($lat)) * sin(radians(h.latitude)))) <= $radius";
    
    $result = mysqli_query($conn, $query);
    $data = mysqli_fetch_assoc($result);
    
    $congestion = $data['avg_congestion'] ? round($data['avg_congestion']) : 20; // Default to 20% if no reports
    $reports = $data['report_count'] ? $data['report_count'] : 0;
    
    echo json_encode([
        'success' => true,
        'congestion' => $congestion,
        'reports_count' => $reports
    ]);
} else {
    echo json_encode(['success' => false, 'message' => 'Invalid request']);
}
?>