<?php
session_start();
require_once '../config/database.php';

date_default_timezone_set('Africa/Nairobi');
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
    exit;
}

$report_id = intval($_POST['id']);
$user_id = $_SESSION['user_id'];
$role = $_SESSION['role'];

// Build query with access control
$query = "SELECT 
    tr.*,
    u.fullname as user_name,
    u.email as user_email,
    h.location_name,
    h.latitude,
    h.longitude
    FROM traffic_reports tr
    JOIN users u ON tr.user_id = u.id
    JOIN hotspots h ON tr.hotspot_id = h.id
    WHERE tr.id = $report_id";

// Non-admins can only view their own reports
if ($role !== 'admin') {
    $query .= " AND tr.user_id = $user_id";
}

$result = mysqli_query($conn, $query);

if (mysqli_num_rows($result) === 0) {
    echo json_encode(['success' => false, 'message' => 'Report not found']);
    exit;
}

$row = mysqli_fetch_assoc($result);

$report = array(
    'id' => $row['id'],
    'user_id' => $row['user_id'],
    'user_name' => htmlspecialchars($row['user_name']),
    'user_email' => $row['user_email'],
    'hotspot_id' => $row['hotspot_id'],
    'location_name' => htmlspecialchars($row['location_name']),
    'latitude' => $row['latitude'],
    'longitude' => $row['longitude'],
    'traffic_level' => ucfirst($row['traffic_level']),
    'description' => htmlspecialchars($row['description']),
    'status' => $row['status'],
    'created_at' => date('d M Y H:i:s', strtotime($row['created_at']))
);

echo json_encode(['success' => true, 'data' => $report]);
?>