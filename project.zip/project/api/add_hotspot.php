<?php
session_start();
require_once '../config/database.php';

header('Content-Type: application/json');

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
    exit;
}

// Validate required fields
if (empty($_POST['location_name']) || empty($_POST['latitude']) || empty($_POST['longitude']) || 
    empty($_POST['peak_start']) || empty($_POST['peak_end'])) {
    echo json_encode(['success' => false, 'message' => 'All fields are required']);
    exit;
}

$location_name = mysqli_real_escape_string($conn, $_POST['location_name']);
$latitude = floatval($_POST['latitude']);
$longitude = floatval($_POST['longitude']);
$peak_start = mysqli_real_escape_string($conn, $_POST['peak_start']);
$peak_end = mysqli_real_escape_string($conn, $_POST['peak_end']);
$created_by = intval($_SESSION['user_id']);

// Validate coordinates
if ($latitude < -90 || $latitude > 90 || $longitude < -180 || $longitude > 180) {
    echo json_encode(['success' => false, 'message' => 'Invalid coordinates']);
    exit;
}

// Validate time format (HH:MM)
if (!preg_match('/^([01]?[0-9]|2[0-3]):[0-5][0-9]$/', $peak_start) || 
    !preg_match('/^([01]?[0-9]|2[0-3]):[0-5][0-9]$/', $peak_end)) {
    echo json_encode(['success' => false, 'message' => 'Invalid time format']);
    exit;
}

// Check if hotspot with same coordinates already exists
$check_query = "SELECT id FROM hotspots WHERE latitude = $latitude AND longitude = $longitude";
$check_result = mysqli_query($conn, $check_query);

if (mysqli_num_rows($check_result) > 0) {
    echo json_encode(['success' => false, 'message' => 'A hotspot already exists at these coordinates']);
    exit;
}

$query = "INSERT INTO hotspots (location_name, latitude, longitude, peak_start, peak_end, created_by) 
          VALUES ('$location_name', $latitude, $longitude, '$peak_start', '$peak_end', $created_by)";

if (mysqli_query($conn, $query)) {
    // Log the action
    $log_query = "INSERT INTO system_logs (log_type, message, details, created_by) 
                  VALUES ('success', 'New hotspot added', 'Added hotspot: $location_name', $created_by)";
    mysqli_query($conn, $log_query);
    
    echo json_encode([
        'success' => true, 
        'message' => 'Hotspot added successfully',
        'id' => mysqli_insert_id($conn)
    ]);
} else {
    error_log("Failed to add hotspot: " . mysqli_error($conn));
    echo json_encode(['success' => false, 'message' => 'Failed to add hotspot: ' . mysqli_error($conn)]);
}
?>