<?php
session_start();
require_once '../config/database.php';

header('Content-Type: application/json');

// Function to get user IP address
function getUserIP() {
    if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
        return $_SERVER['HTTP_CLIENT_IP'];
    } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        return $_SERVER['HTTP_X_FORWARDED_FOR'];
    } else {
        return $_SERVER['REMOTE_ADDR'];
    }
}

// Function to log user activity
function logUserActivity($conn, $user_id, $action, $details = null) {
    $ip_address = getUserIP();
    $details = $details ? mysqli_real_escape_string($conn, $details) : null;
    
    $query = "INSERT INTO user_activity_logs (user_id, action, details, ip_address) 
              VALUES (?, ?, ?, ?)";
    
    $stmt = mysqli_prepare($conn, $query);
    mysqli_stmt_bind_param($stmt, "isss", $user_id, $action, $details, $ip_address);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = mysqli_real_escape_string($conn, filter_var($_POST['email'], FILTER_SANITIZE_EMAIL));
    $password = $_POST['password'];

    // Get user by email - include status field
    $query = "SELECT * FROM users WHERE email = ?";
    $stmt = mysqli_prepare($conn, $query);
    mysqli_stmt_bind_param($stmt, "s", $email);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);

    if (mysqli_num_rows($result) == 1) {
        $user = mysqli_fetch_assoc($result);
        
        if (password_verify($password, $user['password'])) {
            
            // NEW: Check if account is suspended
            if (isset($user['status']) && $user['status'] === 'suspended') {
                // Log the failed login attempt due to suspension
                logUserActivity($conn, $user['id'], 'login_failed', 'Attempted login on suspended account');
                
                echo json_encode([
                    'success' => false, 
                    'suspended' => true,
                    'message' => 'Your account has been suspended. Please contact the administrator.'
                ]);
                exit();
            }
            
            // Check if email is verified
            if ($user['email_verified'] == 0) {
                // Log unverified attempt
                logUserActivity($conn, $user['id'], 'login_failed', 'Attempted login with unverified email');
                
                echo json_encode([
                    'success' => false,
                    'require_verification' => true,
                    'user_id' => $user['id'],
                    'message' => 'Please verify your email before logging in.'
                ]);
                exit();
            }
            
            // NEW: Update last login and IP
            $ip_address = getUserIP();
            $update_query = "UPDATE users SET last_login = NOW(), last_ip = ? WHERE id = ?";
            $update_stmt = mysqli_prepare($conn, $update_query);
            mysqli_stmt_bind_param($update_stmt, "si", $ip_address, $user['id']);
            mysqli_stmt_execute($update_stmt);
            mysqli_stmt_close($update_stmt);
            
            // NEW: Log successful login
            logUserActivity($conn, $user['id'], 'login', 'Successful login');
            
            // Clear any existing session
            $_SESSION = array();
            
            // Set session variables
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['user_name'] = $user['fullname'];
            $_SESSION['user_email'] = $user['email'];
            $_SESSION['role'] = $user['role']; // This is crucial!
            
            // Log for debugging
            error_log("LOGIN SUCCESS - User ID: {$user['id']}, Role: {$user['role']}, Session role set to: " . $_SESSION['role']);
            
            echo json_encode(['success' => true]);
        } else {
            // NEW: Log failed password attempt (without user_id since we don't have it)
            // We need to get user_id first for logging failed password
            if (isset($user['id'])) {
                logUserActivity($conn, $user['id'], 'login_failed', 'Invalid password attempt');
            }
            
            echo json_encode(['success' => false, 'message' => 'Invalid email or password']);
        }
    } else {
        echo json_encode(['success' => false, 'message' => 'Invalid email or password']);
    }
}
?>