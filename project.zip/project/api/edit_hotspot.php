<?php
session_start();
require_once '../config/database.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
    exit;
}

$id = intval($_POST['id']);
$location_name = mysqli_real_escape_string($conn, $_POST['location_name']);
$latitude = floatval($_POST['latitude']);
$longitude = floatval($_POST['longitude']);
$peak_start = mysqli_real_escape_string($conn, $_POST['peak_start']);
$peak_end = mysqli_real_escape_string($conn, $_POST['peak_end']);

$query = "UPDATE hotspots SET 
          location_name = '$location_name', 
          latitude = $latitude, 
          longitude = $longitude, 
          peak_start = '$peak_start', 
          peak_end = '$peak_end' 
          WHERE id = $id";

if (mysqli_query($conn, $query)) {
    echo json_encode(['success' => true, 'message' => 'Hotspot updated successfully']);
} else {
    echo json_encode(['success' => false, 'message' => 'Failed to update hotspot']);
}
?>