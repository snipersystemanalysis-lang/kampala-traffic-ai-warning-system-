<?php
session_start();
require_once '../config/database.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] == 'POST' && $_SESSION['role'] == 'admin') {
    $sidebar_color = mysqli_real_escape_string($conn, $_POST['sidebar_color']);
    $font_family = mysqli_real_escape_string($conn, filter_var($_POST['font_family'], FILTER_SANITIZE_STRING));
    $font_size = mysqli_real_escape_string($conn, $_POST['font_size']);

    $query = "UPDATE system_settings SET sidebar_color = ?, font_family = ?, font_size = ? WHERE id = 1";
    $stmt = mysqli_prepare($conn, $query);
    mysqli_stmt_bind_param($stmt, "sss", $sidebar_color, $font_family, $font_size);

    if (mysqli_stmt_execute($stmt)) {
        echo json_encode(['success' => true, 'message' => 'Settings updated successfully']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Failed to update settings']);
    }
} else {
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
}
?>
