<?php
session_start();
require_once '../config/database.php';

header('Content-Type: application/json');

// Fetch peak congestion hours from traffic data
$query = "SELECT 
    HOUR(tr.created_at) as hour,
    AVG(CASE 
        WHEN tr.traffic_level = 'heavy' THEN 90
        WHEN tr.traffic_level = 'moderate' THEN 60
        WHEN tr.traffic_level = 'light' THEN 30
        ELSE 45
    END) as congestion_level,
    COUNT(*) as report_count
    FROM traffic_reports tr
    WHERE tr.created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)
    GROUP BY HOUR(tr.created_at)
    ORDER BY hour ASC";

$result = mysqli_query($conn, $query);
$peak_hours = array();

// If we have real data, use it
if (mysqli_num_rows($result) > 0) {
    while ($row = mysqli_fetch_assoc($result)) {
        $hour_formatted = date('g A', strtotime($row['hour'] . ':00'));
        $peak_hours[] = array(
            'time' => $hour_formatted,
            'congestion' => round($row['congestion_level']),
            'reports' => $row['report_count']
        );
    }
} else {
    // Provide demo data
    $peak_hours = getDemoPeakHours();
}

echo json_encode(['success' => true, 'data' => $peak_hours]);

function getDemoPeakHours() {
    return array(
        array('time' => '6 AM', 'congestion' => 25, 'reports' => 5),
        array('time' => '7 AM', 'congestion' => 45, 'reports' => 12),
        array('time' => '8 AM', 'congestion' => 85, 'reports' => 28),
        array('time' => '9 AM', 'congestion' => 70, 'reports' => 20),
        array('time' => '4 PM', 'congestion' => 55, 'reports' => 15),
        array('time' => '5 PM', 'congestion' => 75, 'reports' => 22),
        array('time' => '6 PM', 'congestion' => 90, 'reports' => 30),
        array('time' => '7 PM', 'congestion' => 65, 'reports' => 18),
        array('time' => '8 PM', 'congestion' => 40, 'reports' => 8)
    );
}
?>