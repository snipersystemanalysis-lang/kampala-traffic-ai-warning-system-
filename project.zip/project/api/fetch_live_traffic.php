<?php
session_start();
require_once '../config/database.php';

header('Content-Type: application/json');

$query = "SELECT td.*, h.location_name FROM traffic_data td
          JOIN hotspots h ON td.hotspot_id = h.id
          ORDER BY td.recorded_at DESC LIMIT 20";
$result = mysqli_query($conn, $query);

$traffic_data = array();
while ($row = mysqli_fetch_object($result)) {
    $traffic_data[] = array(
        'id' => $row->id,
        'location_name' => htmlspecialchars($row->location_name),
        'congestion_level' => htmlspecialchars($row->congestion_level),
        'vehicle_speed' => $row->vehicle_speed,
        'traffic_density' => $row->traffic_density,
        'recorded_at' => $row->recorded_at
    );
}

echo json_encode(['success' => true, 'data' => $traffic_data]);
?>
