<?php
session_start();
require_once '../config/database.php';

// Set timezone
date_default_timezone_set('Africa/Nairobi');

header('Content-Type: application/json');

$user_id = $_SESSION['user_id'];
$role = $_SESSION['role'];
$filter = isset($_GET['filter']) ? $_GET['filter'] : 'today';
$date_from = isset($_GET['date_from']) ? $_GET['date_from'] : '';
$date_to = isset($_GET['date_to']) ? $_GET['date_to'] : '';

// Build date filter
$date_condition = "";
switch($filter) {
    case 'today':
        $date_condition = "DATE(tr.created_at) = CURDATE()";
        break;
    case 'yesterday':
        $date_condition = "DATE(tr.created_at) = DATE_SUB(CURDATE(), INTERVAL 1 DAY)";
        break;
    case 'thisWeek':
        $date_condition = "YEARWEEK(tr.created_at) = YEARWEEK(CURDATE())";
        break;
    case 'thisMonth':
        $date_condition = "MONTH(tr.created_at) = MONTH(CURDATE()) AND YEAR(tr.created_at) = YEAR(CURDATE())";
        break;
    case 'lastMonth':
        $date_condition = "MONTH(tr.created_at) = MONTH(DATE_SUB(CURDATE(), INTERVAL 1 MONTH)) AND YEAR(tr.created_at) = YEAR(DATE_SUB(CURDATE(), INTERVAL 1 MONTH))";
        break;
    case 'thisYear':
        $date_condition = "YEAR(tr.created_at) = YEAR(CURDATE())";
        break;
    case 'lastYear':
        $date_condition = "YEAR(tr.created_at) = YEAR(DATE_SUB(CURDATE(), INTERVAL 1 YEAR))";
        break;
    case 'custom':
        if ($date_from && $date_to) {
            $date_condition = "DATE(tr.created_at) BETWEEN '$date_from' AND '$date_to'";
        }
        break;
    default:
        $date_condition = "1=1";
}

// Build user condition
$user_condition = ($role == 'admin') ? "1=1" : "tr.user_id = $user_id";

$query = "SELECT 
    tr.*,
    u.fullname as user_name,
    h.location_name,
    h.latitude,
    h.longitude
    FROM traffic_reports tr
    JOIN users u ON tr.user_id = u.id
    JOIN hotspots h ON tr.hotspot_id = h.id
    WHERE $user_condition AND $date_condition
    ORDER BY tr.created_at DESC";

$result = mysqli_query($conn, $query);

$reports = array();
while ($row = mysqli_fetch_assoc($result)) {
    $reports[] = array(
        'id' => $row['id'],
        'user_id' => $row['user_id'],
        'user_name' => htmlspecialchars($row['fullname']),
        'hotspot_id' => $row['hotspot_id'],
        'location_name' => htmlspecialchars($row['location_name']),
        'latitude' => $row['latitude'],
        'longitude' => $row['longitude'],
        'traffic_level' => ucfirst($row['traffic_level']),
        'description' => htmlspecialchars($row['description']),
        'status' => $row['status'],
        'created_at' => date('d M Y H:i', strtotime($row['created_at']))
    );
}

echo json_encode(['success' => true, 'data' => $reports]);
?>