<?php
session_start();
require_once '../config/database.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] == 'POST' && $_SESSION['role'] == 'admin') {
    $id = intval($_POST['id']);
    $location_name = mysqli_real_escape_string($conn, filter_var($_POST['location_name'], FILTER_SANITIZE_STRING));
    $latitude = mysqli_real_escape_string($conn, filter_var($_POST['latitude'], FILTER_SANITIZE_STRING));
    $longitude = mysqli_real_escape_string($conn, filter_var($_POST['longitude'], FILTER_SANITIZE_STRING));
    $peak_start = mysqli_real_escape_string($conn, $_POST['peak_start']);
    $peak_end = mysqli_real_escape_string($conn, $_POST['peak_end']);

    $query = "UPDATE hotspots SET location_name = ?, latitude = ?, longitude = ?, peak_start = ?, peak_end = ? WHERE id = ?";
    $stmt = mysqli_prepare($conn, $query);
    mysqli_stmt_bind_param($stmt, "sssssi", $location_name, $latitude, $longitude, $peak_start, $peak_end, $id);

    if (mysqli_stmt_execute($stmt)) {
        echo json_encode(['success' => true, 'message' => 'Hotspot updated successfully']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Failed to update hotspot']);
    }
} else {
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
}
?>
