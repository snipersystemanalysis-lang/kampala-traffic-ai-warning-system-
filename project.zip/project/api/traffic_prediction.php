<?php
session_start();
require_once '../config/database.php';

header('Content-Type: application/json');

$hotspots_query = "SELECT * FROM hotspots";
$hotspots_result = mysqli_query($conn, $hotspots_query);

$predictions = array();

while ($hotspot = mysqli_fetch_object($hotspots_result)) {
    $traffic_query = "SELECT AVG(vehicle_speed) as avg_speed, AVG(traffic_density) as avg_density
                      FROM traffic_data WHERE hotspot_id = ?
                      AND recorded_at > DATE_SUB(NOW(), INTERVAL 1 HOUR)";
    $stmt = mysqli_prepare($conn, $traffic_query);
    mysqli_stmt_bind_param($stmt, "i", $hotspot->id);
    mysqli_stmt_execute($stmt);
    $traffic_result = mysqli_stmt_get_result($stmt);
    $traffic = mysqli_fetch_object($traffic_result);

    $predicted_level = 'Light';
    $confidence = 75;

    if ($traffic && $traffic->avg_speed) {
        if ($traffic->avg_speed < 10) {
            $predicted_level = 'Heavy';
            $confidence = 85;
        } elseif ($traffic->avg_speed < 25) {
            $predicted_level = 'Moderate';
            $confidence = 80;
        } else {
            $predicted_level = 'Light';
            $confidence = 75;
        }
    }

    $current_hour = date('H:i:s');
    if ($current_hour >= $hotspot->peak_start && $current_hour <= $hotspot->peak_end) {
        $predicted_level = 'Heavy';
        $confidence = 90;
    }

    $check_prediction = "SELECT * FROM traffic_predictions WHERE hotspot_id = ? AND DATE(created_at) = CURDATE()";
    $check_stmt = mysqli_prepare($conn, $check_prediction);
    mysqli_stmt_bind_param($check_stmt, "i", $hotspot->id);
    mysqli_stmt_execute($check_stmt);
    $check_result = mysqli_stmt_get_result($check_stmt);

    if (mysqli_num_rows($check_result) == 0) {
        $prediction_time = date('Y-m-d H:i:s', strtotime('+45 minutes'));
        $insert_query = "INSERT INTO traffic_predictions (hotspot_id, predicted_level, prediction_time, confidence_score)
                        VALUES (?, ?, ?, ?)";
        $insert_stmt = mysqli_prepare($conn, $insert_query);
        mysqli_stmt_bind_param($insert_stmt, "issd", $hotspot->id, $predicted_level, $prediction_time, $confidence);
        mysqli_stmt_execute($insert_stmt);
    }

    $predictions[] = array(
        'location_name' => htmlspecialchars($hotspot->location_name),
        'predicted_level' => $predicted_level,
        'prediction_time' => date('Y-m-d H:i:s', strtotime('+45 minutes')),
        'confidence_score' => $confidence
    );
}

echo json_encode(['success' => true, 'data' => $predictions]);
?>
