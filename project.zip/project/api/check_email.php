<?php
require_once '../config/database.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['exists' => false]);
    exit;
}

$email = mysqli_real_escape_string($conn, $_POST['email']);

$query = "SELECT id FROM users WHERE email = '$email'";
$result = mysqli_query($conn, $query);

echo json_encode(['exists' => mysqli_num_rows($result) > 0]);