<?php
session_start();
require_once '../config/database.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $hotspot_id = intval($_POST['hotspot_id']);
    $congestion_level = mysqli_real_escape_string($conn, filter_var($_POST['congestion_level'], FILTER_SANITIZE_STRING));
    $vehicle_speed = floatval($_POST['vehicle_speed']);
    $traffic_density = intval($_POST['traffic_density']);

    $query = "INSERT INTO traffic_data (hotspot_id, congestion_level, vehicle_speed, traffic_density) VALUES (?, ?, ?, ?)";
    $stmt = mysqli_prepare($conn, $query);
    mysqli_stmt_bind_param($stmt, "isdi", $hotspot_id, $congestion_level, $vehicle_speed, $traffic_density);

    if (mysqli_stmt_execute($stmt)) {
        echo json_encode(['success' => true, 'message' => 'Traffic data recorded']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Failed to record traffic data']);
    }
}
?>
