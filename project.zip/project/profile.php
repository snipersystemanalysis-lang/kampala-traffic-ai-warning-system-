<?php
require_once 'includes/auth.php';
require_once 'includes/header.php';
require_once 'config/database.php';

$user_id = $_SESSION['user_id'];
$query = "SELECT * FROM users WHERE id = ?";
$stmt = mysqli_prepare($conn, $query);
mysqli_stmt_bind_param($stmt, "i", $user_id);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
$user = mysqli_fetch_object($result);

// Get user activity stats
$stats_query = "SELECT 
    COUNT(*) as total_logins,
    MAX(created_at) as last_activity
    FROM user_activity_logs 
    WHERE user_id = ? AND action = 'login'";
$stats_stmt = mysqli_prepare($conn, $stats_query);
mysqli_stmt_bind_param($stats_stmt, "i", $user_id);
mysqli_stmt_execute($stats_stmt);
$stats_result = mysqli_stmt_get_result($stats_stmt);
$stats = mysqli_fetch_object($stats_result);

// Get recent activity
$activity_query = "SELECT action, details, ip_address, created_at 
                   FROM user_activity_logs 
                   WHERE user_id = ? 
                   ORDER BY created_at DESC 
                   LIMIT 5";
$activity_stmt = mysqli_prepare($conn, $activity_query);
mysqli_stmt_bind_param($activity_stmt, "i", $user_id);
mysqli_stmt_execute($activity_stmt);
$activity_result = mysqli_stmt_get_result($activity_stmt);

// Fetch system settings for colors
$settings_query = "SELECT * FROM system_settings LIMIT 1";
$settings_result = mysqli_query($conn, $settings_query);
$settings = mysqli_fetch_object($settings_result);

$sidebar_color = $settings ? htmlspecialchars($settings->sidebar_color) : '#343a40';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Profile - Kampala Traffic Predictor</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <style>
        :root {
            --sidebar-color: <?php echo $sidebar_color; ?>;
            --primary-gradient: linear-gradient(135deg, var(--sidebar-color) 0%, <?php echo adjustBrightness($sidebar_color, -20); ?> 100%);
        }

        body {
            background: #f8fafc;
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
        }

        .profile-wrapper {
            display: flex;
            min-height: 100vh;
        }

        .main-content {
            flex: 1;
            margin-left: var(--sidebar-width);
            transition: margin-left 0.3s;
            padding: 30px;
        }

        /* Profile Header */
        .profile-header {
            background: white;
            border-radius: 24px;
            padding: 30px;
            margin-bottom: 25px;
            box-shadow: 0 10px 40px rgba(0,0,0,0.08);
            border: 1px solid rgba(0,0,0,0.05);
            display: flex;
            align-items: center;
            gap: 30px;
            flex-wrap: wrap;
        }

        .profile-avatar {
            width: 120px;
            height: 120px;
            background: var(--primary-gradient);
            border-radius: 60px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 48px;
            font-weight: 600;
            box-shadow: 0 10px 20px rgba(0,0,0,0.15);
            border: 4px solid rgba(255,255,255,0.3);
        }

        .profile-info h1 {
            font-size: 2rem;
            font-weight: 700;
            margin: 0 0 5px 0;
            color: #1e293b;
        }

        .profile-info .badge {
            padding: 8px 16px;
            border-radius: 30px;
            font-size: 0.85rem;
            font-weight: 600;
            margin-right: 10px;
        }

        .badge-role {
            background: <?php echo $sidebar_color; ?>;
            color: white;
        }

        .badge-status {
            background: #d1fae5;
            color: #065f46;
        }

        .profile-meta {
            display: flex;
            gap: 30px;
            margin-top: 15px;
            flex-wrap: wrap;
        }

        .meta-item {
            display: flex;
            align-items: center;
            gap: 10px;
            color: #64748b;
        }

        .meta-item i {
            font-size: 1.2rem;
            color: <?php echo $sidebar_color; ?>;
        }

        /* Stats Cards */
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-bottom: 25px;
        }

        .stat-card {
            background: white;
            border-radius: 20px;
            padding: 20px;
            box-shadow: 0 5px 20px rgba(0,0,0,0.05);
            border: 1px solid rgba(0,0,0,0.05);
            display: flex;
            align-items: center;
            gap: 15px;
            transition: all 0.3s;
        }

        .stat-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 15px 30px rgba(0,0,0,0.1);
        }

        .stat-icon {
            width: 50px;
            height: 50px;
            background: var(--primary-gradient);
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 24px;
        }

        .stat-content h3 {
            font-size: 1.8rem;
            font-weight: 700;
            margin: 0;
            color: #1e293b;
        }

        .stat-content p {
            margin: 0;
            color: #64748b;
            font-size: 0.9rem;
        }

        /* Profile Form Card */
        .profile-card {
            background: white;
            border-radius: 24px;
            box-shadow: 0 10px 40px rgba(0,0,0,0.08);
            border: 1px solid rgba(0,0,0,0.05);
            overflow: hidden;
            margin-bottom: 25px;
        }

        .card-header {
            background: var(--primary-gradient);
            color: white;
            padding: 20px 25px;
            border: none;
        }

        .card-header h5 {
            margin: 0;
            font-size: 1.2rem;
            font-weight: 600;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .card-body {
            padding: 30px;
        }

        /* Form Styles */
        .form-label {
            font-weight: 600;
            color: #1e293b;
            margin-bottom: 8px;
            font-size: 0.9rem;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .form-control {
            padding: 12px 15px;
            border: 2px solid #e2e8f0;
            border-radius: 12px;
            font-size: 0.95rem;
            transition: all 0.3s;
        }

        .form-control:focus {
            outline: none;
            border-color: var(--sidebar-color);
            box-shadow: 0 0 0 4px rgba(102, 126, 234, 0.1);
        }

        .input-group-text {
            background: white;
            border: 2px solid #e2e8f0;
            border-right: none;
            border-radius: 12px 0 0 12px;
            color: <?php echo $sidebar_color; ?>;
        }

        .input-group .form-control {
            border-left: none;
            border-radius: 0 12px 12px 0;
        }

        .btn-update {
            background: var(--primary-gradient);
            color: white;
            padding: 12px 30px;
            border: none;
            border-radius: 12px;
            font-weight: 600;
            display: inline-flex;
            align-items: center;
            gap: 10px;
            transition: all 0.3s;
        }

        .btn-update:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 20px rgba(0,0,0,0.15);
            color: white;
        }

        .btn-update:disabled {
            opacity: 0.7;
            transform: none;
        }

        /* Activity List */
        .activity-list {
            background: white;
            border-radius: 16px;
            padding: 5px 0;
        }

        .activity-item {
            display: flex;
            align-items: center;
            gap: 15px;
            padding: 15px 20px;
            border-bottom: 1px solid #eef2f6;
        }

        .activity-item:last-child {
            border-bottom: none;
        }

        .activity-icon {
            width: 40px;
            height: 40px;
            background: #f1f5f9;
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: <?php echo $sidebar_color; ?>;
            font-size: 1.2rem;
        }

        .activity-details {
            flex: 1;
        }

        .activity-action {
            font-weight: 600;
            color: #1e293b;
            margin-bottom: 3px;
        }

        .activity-meta {
            font-size: 0.8rem;
            color: #64748b;
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .activity-meta i {
            margin-right: 3px;
        }

        /* Alert Styles */
        .alert {
            border-radius: 12px;
            padding: 15px 20px;
            border: none;
            margin-bottom: 20px;
        }

        .alert-success {
            background: #d1fae5;
            color: #065f46;
        }

        .alert-danger {
            background: #fee2e2;
            color: #991b1b;
        }

        /* Responsive */
        @media (max-width: 991px) {
            .main-content {
                margin-left: 0;
                padding: 20px;
            }
            
            .profile-header {
                flex-direction: column;
                text-align: center;
            }
            
            .profile-meta {
                justify-content: center;
            }
        }

        @media (max-width: 768px) {
            .stats-grid {
                grid-template-columns: 1fr;
            }
            
            .profile-meta {
                flex-direction: column;
                gap: 10px;
            }
        }
    </style>
</head>
<body>
    <div class="profile-wrapper">
        <?php require_once 'includes/sidebar.php'; ?>
        
        <div class="main-content">
            <!-- Page Title -->
            <div class="d-flex align-items-center justify-content-between mb-4">
                <h2 class="fw-bold" style="color: #1e293b;">
                    <i class="bi bi-person-circle me-2" style="color: <?php echo $sidebar_color; ?>;"></i>
                    My Profile
                </h2>
                <span class="badge bg-light text-dark py-2 px-3">
                    <i class="bi bi-shield-check me-1" style="color: <?php echo $sidebar_color; ?>;"></i>
                    Member since <?php echo date('M Y', strtotime($user->created_at)); ?>
                </span>
            </div>

            <!-- Profile Header -->
            <div class="profile-header">
                <div class="profile-avatar">
                    <?php echo strtoupper(substr($user->fullname, 0, 1)); ?>
                </div>
                <div class="profile-info">
                    <h1><?php echo htmlspecialchars($user->fullname); ?></h1>
                    <div class="mb-3">
                        <span class="badge badge-role">
                            <i class="bi bi-shield me-1"></i>
                            <?php echo ucfirst($user->role); ?>
                        </span>
                        <span class="badge badge-status">
                            <i class="bi bi-check-circle me-1"></i>
                            <?php echo ucfirst($user->status ?? 'active'); ?>
                        </span>
                        <?php if($user->email_verified): ?>
                        <span class="badge bg-success text-white">
                            <i class="bi bi-envelope-check me-1"></i>
                            Verified
                        </span>
                        <?php else: ?>
                        <span class="badge bg-warning text-dark">
                            <i class="bi bi-envelope-exclamation me-1"></i>
                            Unverified
                        </span>
                        <?php endif; ?>
                    </div>
                    <div class="profile-meta">
                        <div class="meta-item">
                            <i class="bi bi-envelope"></i>
                            <span><?php echo htmlspecialchars($user->email); ?></span>
                        </div>
                        <div class="meta-item">
                            <i class="bi bi-calendar"></i>
                            <span>Joined: <?php echo date('F j, Y', strtotime($user->created_at)); ?></span>
                        </div>
                        <div class="meta-item">
                            <i class="bi bi-clock-history"></i>
                            <span>Last login: <?php echo $user->last_login ? date('M j, Y H:i', strtotime($user->last_login)) : 'Never'; ?></span>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Stats Cards -->
            <div class="stats-grid">
                <div class="stat-card">
                    <div class="stat-icon">
                        <i class="bi bi-box-arrow-in-right"></i>
                    </div>
                    <div class="stat-content">
                        <h3><?php echo $stats->total_logins ?? 0; ?></h3>
                        <p>Total Logins</p>
                    </div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon">
                        <i class="bi bi-activity"></i>
                    </div>
                    <div class="stat-content">
                        <h3><?php echo $stats->last_activity ? time_ago($stats->last_activity) : 'Never'; ?></h3>
                        <p>Last Activity</p>
                    </div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon">
                        <i class="bi bi-shield-check"></i>
                    </div>
                    <div class="stat-content">
                        <h3><?php echo $user->email_verified ? 'Verified' : 'Pending'; ?></h3>
                        <p>Email Status</p>
                    </div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon">
                        <i class="bi bi-globe"></i>
                    </div>
                    <div class="stat-content">
                        <h3><?php echo $user->last_ip ?? 'N/A'; ?></h3>
                        <p>Last IP</p>
                    </div>
                </div>
            </div>

            <div class="row">
                <!-- Profile Update Form -->
                <div class="col-lg-7">
                    <div class="profile-card">
                        <div class="card-header">
                            <h5>
                                <i class="bi bi-pencil-square"></i>
                                Edit Profile Information
                            </h5>
                        </div>
                        <div class="card-body">
                            <div id="profileMessage"></div>
                            
                            <form id="profileForm">
                                <div class="mb-4">
                                    <label class="form-label">
                                        <i class="bi bi-person me-1"></i>
                                        Full Name
                                    </label>
                                    <div class="input-group">
                                        <span class="input-group-text">
                                            <i class="bi bi-person"></i>
                                        </span>
                                        <input type="text" class="form-control" name="fullname" 
                                               value="<?php echo htmlspecialchars($user->fullname); ?>" 
                                               placeholder="Enter your full name" required>
                                    </div>
                                </div>

                                <div class="mb-4">
                                    <label class="form-label">
                                        <i class="bi bi-envelope me-1"></i>
                                        Email Address
                                    </label>
                                    <div class="input-group">
                                        <span class="input-group-text">
                                            <i class="bi bi-envelope"></i>
                                        </span>
                                        <input type="email" class="form-control" name="email" 
                                               value="<?php echo htmlspecialchars($user->email); ?>" 
                                               placeholder="Enter your email" required>
                                    </div>
                                </div>

                                <div class="mb-4">
                                    <label class="form-label">
                                        <i class="bi bi-lock me-1"></i>
                                        New Password
                                    </label>
                                    <div class="input-group">
                                        <span class="input-group-text">
                                            <i class="bi bi-lock"></i>
                                        </span>
                                        <input type="password" class="form-control" name="password" 
                                               placeholder="Leave blank to keep current" id="password">
                                        <button class="btn btn-outline-secondary" type="button" id="togglePassword">
                                            <i class="bi bi-eye"></i>
                                        </button>
                                    </div>
                                    <small class="text-muted mt-2 d-block">
                                        <i class="bi bi-info-circle me-1"></i>
                                        Minimum 8 characters with at least one number
                                    </small>
                                </div>

                                <div class="mb-4">
                                    <label class="form-label">
                                        <i class="bi bi-lock-fill me-1"></i>
                                        Confirm New Password
                                    </label>
                                    <div class="input-group">
                                        <span class="input-group-text">
                                            <i class="bi bi-lock-fill"></i>
                                        </span>
                                        <input type="password" class="form-control" name="confirm_password" 
                                               placeholder="Confirm new password" id="confirm_password">
                                        <button class="btn btn-outline-secondary" type="button" id="toggleConfirmPassword">
                                            <i class="bi bi-eye"></i>
                                        </button>
                                    </div>
                                </div>

                                <button type="submit" class="btn-update">
                                    <i class="bi bi-check-circle"></i>
                                    Update Profile
                                </button>
                            </form>
                        </div>
                    </div>
                </div>

                <!-- Recent Activity -->
                <div class="col-lg-5">
                    <div class="profile-card">
                        <div class="card-header">
                            <h5>
                                <i class="bi bi-clock-history"></i>
                                Recent Activity
                            </h5>
                        </div>
                        <div class="card-body p-0">
                            <div class="activity-list">
                                <?php if(mysqli_num_rows($activity_result) > 0): ?>
                                    <?php while($activity = mysqli_fetch_object($activity_result)): ?>
                                    <div class="activity-item">
                                        <div class="activity-icon">
                                            <i class="bi bi-<?php echo $activity->action === 'login' ? 'box-arrow-in-right' : 'gear'; ?>"></i>
                                        </div>
                                        <div class="activity-details">
                                            <div class="activity-action">
                                                <?php echo ucfirst($activity->action); ?>
                                            </div>
                                            <div class="activity-meta">
                                                <span>
                                                    <i class="bi bi-clock"></i>
                                                    <?php echo time_ago($activity->created_at); ?>
                                                </span>
                                                <span>
                                                    <i class="bi bi-globe"></i>
                                                    <?php echo $activity->ip_address ?? 'N/A'; ?>
                                                </span>
                                            </div>
                                            <?php if($activity->details): ?>
                                            <small class="text-muted"><?php echo $activity->details; ?></small>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <?php endwhile; ?>
                                <?php else: ?>
                                    <div class="text-center py-5">
                                        <i class="bi bi-activity" style="font-size: 3rem; color: #cbd5e1;"></i>
                                        <p class="text-muted mt-3">No recent activity found</p>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>

                    <!-- Security Tips -->
                    <div class="profile-card mt-4">
                        <div class="card-header" style="background: linear-gradient(135deg, #f59e0b 0%, #d97706 100%);">
                            <h5>
                                <i class="bi bi-shield-check"></i>
                                Security Tips
                            </h5>
                        </div>
                        <div class="card-body">
                            <ul class="list-unstyled mb-0">
                                <li class="mb-3">
                                    <i class="bi bi-check-circle-fill text-success me-2"></i>
                                    Use a strong password with letters, numbers, and symbols
                                </li>
                                <li class="mb-3">
                                    <i class="bi bi-check-circle-fill text-success me-2"></i>
                                    Never share your password with anyone
                                </li>
                                <li class="mb-3">
                                    <i class="bi bi-check-circle-fill text-success me-2"></i>
                                    Log out from public computers
                                </li>
                                <li class="mb-3">
                                    <i class="bi bi-check-circle-fill text-success me-2"></i>
                                    Enable two-factor authentication if available
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Toggle password visibility
        $('#togglePassword').click(function() {
            const password = $('#password');
            const icon = $(this).find('i');
            
            if (password.attr('type') === 'password') {
                password.attr('type', 'text');
                icon.removeClass('bi-eye').addClass('bi-eye-slash');
            } else {
                password.attr('type', 'password');
                icon.removeClass('bi-eye-slash').addClass('bi-eye');
            }
        });

        $('#toggleConfirmPassword').click(function() {
            const password = $('#confirm_password');
            const icon = $(this).find('i');
            
            if (password.attr('type') === 'password') {
                password.attr('type', 'text');
                icon.removeClass('bi-eye').addClass('bi-eye-slash');
            } else {
                password.attr('type', 'password');
                icon.removeClass('bi-eye-slash').addClass('bi-eye');
            }
        });

        // Profile form submission
        $('#profileForm').on('submit', function(e) {
            e.preventDefault();
            
            // Validate passwords match if both are filled
            const password = $('#password').val();
            const confirm = $('#confirm_password').val();
            
            if (password || confirm) {
                if (password !== confirm) {
                    $('#profileMessage').html('<div class="alert alert-danger"><i class="bi bi-exclamation-triangle-fill me-2"></i>Passwords do not match</div>');
                    return;
                }
                
                if (password.length < 8) {
                    $('#profileMessage').html('<div class="alert alert-danger"><i class="bi bi-exclamation-triangle-fill me-2"></i>Password must be at least 8 characters long</div>');
                    return;
                }
            }
            
            const $btn = $(this).find('button[type="submit"]');
            const originalText = $btn.html();
            $btn.prop('disabled', true).html('<span class="spinner-border spinner-border-sm me-2"></span>Updating...');
            
            $.ajax({
                url: 'api/update_profile.php',
                type: 'POST',
                data: $(this).serialize(),
                dataType: 'json',
                success: function(response) {
                    if (response.success) {
                        $('#profileMessage').html('<div class="alert alert-success"><i class="bi bi-check-circle-fill me-2"></i>' + response.message + '</div>');
                        // Clear password fields on success
                        $('#password, #confirm_password').val('');
                        
                        // Auto-hide success message after 5 seconds
                        setTimeout(() => {
                            $('#profileMessage .alert').fadeOut();
                        }, 5000);
                    } else {
                        $('#profileMessage').html('<div class="alert alert-danger"><i class="bi bi-exclamation-triangle-fill me-2"></i>' + response.message + '</div>');
                    }
                    $btn.prop('disabled', false).html(originalText);
                },
                error: function() {
                    $('#profileMessage').html('<div class="alert alert-danger"><i class="bi bi-exclamation-triangle-fill me-2"></i>An error occurred. Please try again.</div>');
                    $btn.prop('disabled', false).html(originalText);
                }
            });
        });

        // Auto-hide alerts when close button is clicked
        $(document).on('click', '.alert .btn-close', function() {
            $(this).closest('.alert').fadeOut();
        });
    </script>
</body>
</html>

<?php
// Helper function for time ago
function time_ago($datetime) {
    $time = strtotime($datetime);
    $now = time();
    $diff = $now - $time;
    
    if ($diff < 60) {
        return 'just now';
    } elseif ($diff < 3600) {
        $mins = floor($diff / 60);
        return $mins . ' minute' . ($mins > 1 ? 's' : '') . ' ago';
    } elseif ($diff < 86400) {
        $hours = floor($diff / 3600);
        return $hours . ' hour' . ($hours > 1 ? 's' : '') . ' ago';
    } elseif ($diff < 604800) {
        $days = floor($diff / 86400);
        return $days . ' day' . ($days > 1 ? 's' : '') . ' ago';
    } else {
        return date('M j, Y', $time);
    }
}

function adjustBrightness($hex, $steps) {
    $hex = str_replace('#', '', $hex);
    if (strlen($hex) == 3) {
        $hex = $hex[0].$hex[0].$hex[1].$hex[1].$hex[2].$hex[2];
    }
    
    $r = hexdec(substr($hex, 0, 2));
    $g = hexdec(substr($hex, 2, 2));
    $b = hexdec(substr($hex, 4, 2));
    
    $r = max(0, min(255, $r + $steps));
    $g = max(0, min(255, $g + $steps));
    $b = max(0, min(255, $b + $steps));
    
    return '#' . sprintf("%02x%02x%02x", $r, $g, $b);
}
?>