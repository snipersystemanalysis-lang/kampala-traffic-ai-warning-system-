<?php
session_start();
require_once 'config/database.php';
require_once 'includes/header.php';

if (isset($_SESSION['user_id'])) {
    header("Location: dashboard.php");
    exit();
}

// Fetch system settings for colors
$settings_query = "SELECT * FROM system_settings LIMIT 1";
$settings_result = mysqli_query($conn, $settings_query);
$settings = mysqli_fetch_object($settings_result);

$sidebar_color = $settings ? htmlspecialchars($settings->sidebar_color) : '#343a40';
$font_family = $settings ? htmlspecialchars($settings->font_family) : 'Arial, sans-serif';
$font_size = $settings ? htmlspecialchars($settings->font_size) : '16px';
?>
<body>
    <div class="container-fluid p-0">
        <div class="row g-0 min-vh-100">
            <!-- Left Side - Image with Overlay -->
            <div class="col-lg-6 d-none d-lg-block position-relative" style="background: linear-gradient(135deg, <?php echo $sidebar_color; ?> 0%, <?php echo $sidebar_color; ?>dd 100%);">
                <div class="position-absolute top-0 start-0 w-100 h-100 d-flex flex-column justify-content-center align-items-center text-white p-5">
                    <img src="images/logo.jpg" alt="Kampala Traffic Predictor" class="img-fluid mb-4" style="max-width: 180px; border-radius: 50%; box-shadow: 0 20px 40px rgba(0,0,0,0.3); border: 4px solid rgba(255,255,255,0.2);">
                    <h2 class="text-center mb-4 fw-bold display-5">Welcome to Kampala Traffic Predictor</h2>
                    <p class="text-center opacity-75 fs-5 mb-5">Join thousands of users getting real-time traffic updates and helping make Kampala's roads better</p>
                    
                    <div class="features-list">
                        <div class="feature-item mb-4 d-flex align-items-center">
                            <div class="feature-icon me-3 bg-white bg-opacity-20 p-3 rounded-circle">
                                <i class="fas fa-traffic-light fa-2x"></i>
                            </div>
                            <div class="feature-text">
                                <h5 class="mb-1">Real-time Traffic Updates</h5>
                                <p class="mb-0 small opacity-75">Get instant alerts about traffic conditions</p>
                            </div>
                        </div>
                        <div class="feature-item mb-4 d-flex align-items-center">
                            <div class="feature-icon me-3 bg-white bg-opacity-20 p-3 rounded-circle">
                                <i class="fas fa-chart-line fa-2x"></i>
                            </div>
                            <div class="feature-text">
                                <h5 class="mb-1">AI-Powered Predictions</h5>
                                <p class="mb-0 small opacity-75">Advanced algorithms predict traffic patterns</p>
                            </div>
                        </div>
                        <div class="feature-item mb-4 d-flex align-items-center">
                            <div class="feature-icon me-3 bg-white bg-opacity-20 p-3 rounded-circle">
                                <i class="fas fa-route fa-2x"></i>
                            </div>
                            <div class="feature-text">
                                <h5 class="mb-1">Smart Route Planning</h5>
                                <p class="mb-0 small opacity-75">Find the fastest routes to your destination</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Right Side - Registration Form -->
            <div class="col-lg-6 d-flex align-items-center justify-content-center p-4" style="background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);">
                <div class="w-100" style="max-width: 450px;">
                    <!-- Mobile Logo -->
                    <div class="text-center mb-4 d-lg-none">
                        <img src="images/logo.jpg" alt="Logo" style="max-width: 80px; border-radius: 50%; box-shadow: 0 10px 20px rgba(0,0,0,0.1);">
                    </div>
                    
                    <h3 class="text-center mb-4 fw-bold" style="color: <?php echo $sidebar_color; ?>;">Create Your Account</h3>
                    
                    <!-- Main Registration Form -->
                    <div id="registerForm">
                        <div id="registerMessage"></div>
                        
                        <form id="registerUserForm">
                            <div class="mb-3">
                                <label for="fullname" class="form-label fw-semibold">Full Name</label>
                                <div class="input-group">
                                    <span class="input-group-text bg-white border-end-0" style="color: <?php echo $sidebar_color; ?>;">
                                        <i class="fas fa-user"></i>
                                    </span>
                                    <input type="text" class="form-control border-start-0 ps-0" id="fullname" name="fullname" 
                                           placeholder="Enter your full name" required>
                                </div>
                            </div>
                            
                            <div class="mb-3">
                                <label for="email" class="form-label fw-semibold">Email Address</label>
                                <div class="input-group">
                                    <span class="input-group-text bg-white border-end-0" style="color: <?php echo $sidebar_color; ?>;">
                                        <i class="fas fa-envelope"></i>
                                    </span>
                                    <input type="email" class="form-control border-start-0 ps-0" id="email" name="email" 
                                           placeholder="Enter your email" required>
                                </div>
                                <div id="emailStatus" class="small mt-1"></div>
                            </div>
                            
                            <div class="mb-3">
                                <label for="password" class="form-label fw-semibold">Password</label>
                                <div class="input-group">
                                    <span class="input-group-text bg-white border-end-0" style="color: <?php echo $sidebar_color; ?>;">
                                        <i class="fas fa-lock"></i>
                                    </span>
                                    <input type="password" class="form-control border-start-0 ps-0" id="password" name="password" 
                                           placeholder="Create a strong password" required>
                                    <button class="btn btn-outline-secondary border-start-0" type="button" id="togglePassword">
                                        <i class="fas fa-eye"></i>
                                    </button>
                                </div>
                                <div class="password-strength mt-2">
                                    <div class="progress" style="height: 5px;">
                                        <div class="progress-bar" id="passwordStrength" style="width: 0%; background-color: #dc3545;"></div>
                                    </div>
                                    <div class="d-flex justify-content-between mt-1 small">
                                        <span id="lengthCheck" class="text-muted"><i class="fas fa-circle fa-2xs me-1"></i> 8+ characters</span>
                                        <span id="uppercaseCheck" class="text-muted"><i class="fas fa-circle fa-2xs me-1"></i> Uppercase</span>
                                        <span id="lowercaseCheck" class="text-muted"><i class="fas fa-circle fa-2xs me-1"></i> Lowercase</span>
                                        <span id="numberCheck" class="text-muted"><i class="fas fa-circle fa-2xs me-1"></i> Number</span>
                                        <span id="specialCheck" class="text-muted"><i class="fas fa-circle fa-2xs me-1"></i> Special</span>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="mb-4">
                                <label for="confirm_password" class="form-label fw-semibold">Confirm Password</label>
                                <div class="input-group">
                                    <span class="input-group-text bg-white border-end-0" style="color: <?php echo $sidebar_color; ?>;">
                                        <i class="fas fa-lock"></i>
                                    </span>
                                    <input type="password" class="form-control border-start-0 ps-0" id="confirm_password" name="confirm_password" 
                                           placeholder="Re-enter your password" required>
                                    <button class="btn btn-outline-secondary border-start-0" type="button" id="toggleConfirmPassword">
                                        <i class="fas fa-eye"></i>
                                    </button>
                                </div>
                                <div id="passwordMatch" class="small mt-1"></div>
                            </div>
                            
                            <div class="mb-4 form-check">
                                <input type="checkbox" class="form-check-input" id="terms" name="terms" required>
                                <label class="form-check-label small" for="terms">
                                    I agree to the <a href="#" class="text-decoration-none" style="color: <?php echo $sidebar_color; ?>;">Terms of Service</a> and 
                                    <a href="#" class="text-decoration-none" style="color: <?php echo $sidebar_color; ?>;">Privacy Policy</a>
                                </label>
                            </div>
                            
                            <button type="submit" class="btn w-100 py-3 fw-semibold" style="background: linear-gradient(135deg, <?php echo $sidebar_color; ?> 0%, <?php echo $sidebar_color; ?>dd 100%); color: white; border: none;">
                                <i class="fas fa-user-plus me-2"></i>Create Account
                            </button>
                        </form>
                        
                        <div class="mt-4 text-center">
                            <p class="mb-2">Already have an account? <a href="login.php" class="text-decoration-none fw-semibold" style="color: <?php echo $sidebar_color; ?>;">Sign In</a></p>
                            <p class="small text-muted">or</p>
                            <p><a href="register_admin.php" class="text-decoration-none small" style="color: <?php echo $sidebar_color; ?>;">Register as Admin Instead</a></p>
                        </div>
                    </div>
                    
                    <!-- Hidden Verification Form -->
                    <div id="verificationSection" style="display: none;">
                        <div class="text-center mb-4">
                            <div class="bg-success bg-opacity-10 rounded-circle d-inline-flex p-3 mb-3">
                                <i class="fas fa-envelope-open-text fa-3x" style="color: <?php echo $sidebar_color; ?>;"></i>
                            </div>
                            <h4 class="fw-bold" style="color: <?php echo $sidebar_color; ?>;">Verify Your Email</h4>
                            <p class="text-muted small">We've sent a verification code to <span id="verificationEmail" class="fw-semibold"></span></p>
                        </div>
                        
                        <div id="verificationMessage"></div>
                        
                        <form id="verifyCodeForm">
                            <input type="hidden" id="verificationUserId" name="user_id">
                            <div class="mb-4">
                                <label class="form-label fw-semibold">Enter Verification Code</label>
                                <input type="text" class="form-control code-input text-center" id="verificationCode" name="verification_code" 
                                       maxlength="8" placeholder="••••••••" required autocomplete="off">
                                <div class="text-center mt-2">
                                    <span class="badge bg-light text-dark p-2" id="codeTimer">
                                        <i class="far fa-clock me-1"></i> Code expires in <span id="timer">10:00</span>
                                    </span>
                                </div>
                            </div>
                            
                            <button type="submit" class="btn w-100 py-3 mb-3 fw-semibold" style="background: linear-gradient(135deg, <?php echo $sidebar_color; ?> 0%, <?php echo $sidebar_color; ?>dd 100%); color: white; border: none;">
                                <i class="fas fa-check-circle me-2"></i>Verify Email
                            </button>
                            
                            <div class="text-center">
                                <button type="button" class="btn btn-link text-decoration-none" id="resendCode" style="color: <?php echo $sidebar_color; ?>;">
                                    <i class="fas fa-redo-alt me-1"></i>Resend Verification Code
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Password strength checker
        function checkPasswordStrength(password) {
            let strength = 0;
            const checks = {
                length: password.length >= 8,
                uppercase: /[A-Z]/.test(password),
                lowercase: /[a-z]/.test(password),
                number: /[0-9]/.test(password),
                special: /[^A-Za-z0-9]/.test(password)
            };
            
            // Update check icons
            $('#lengthCheck').html(`<i class="fas fa-${checks.length ? 'check-circle text-success' : 'circle text-muted'} fa-2xs me-1"></i> 8+ characters`);
            $('#uppercaseCheck').html(`<i class="fas fa-${checks.uppercase ? 'check-circle text-success' : 'circle text-muted'} fa-2xs me-1"></i> Uppercase`);
            $('#lowercaseCheck').html(`<i class="fas fa-${checks.lowercase ? 'check-circle text-success' : 'circle text-muted'} fa-2xs me-1"></i> Lowercase`);
            $('#numberCheck').html(`<i class="fas fa-${checks.number ? 'check-circle text-success' : 'circle text-muted'} fa-2xs me-1"></i> Number`);
            $('#specialCheck').html(`<i class="fas fa-${checks.special ? 'check-circle text-success' : 'circle text-muted'} fa-2xs me-1"></i> Special`);
            
            // Calculate strength
            Object.values(checks).forEach(check => check && strength++);
            
            // Update progress bar
            const strengthPercent = (strength / 5) * 100;
            $('#passwordStrength').css('width', strengthPercent + '%');
            
            if (strength <= 2) {
                $('#passwordStrength').css('background-color', '#dc3545');
            } else if (strength <= 4) {
                $('#passwordStrength').css('background-color', '#ffc107');
            } else {
                $('#passwordStrength').css('background-color', '#28a745');
            }
            
            return checks;
        }

        // Real-time email existence check
        let emailTimeout;
        $('#email').on('input', function() {
            clearTimeout(emailTimeout);
            const email = $(this).val();
            
            if (email.includes('@') && email.includes('.')) {
                emailTimeout = setTimeout(function() {
                    $.ajax({
                        url: 'api/check_email.php',
                        type: 'POST',
                        data: { email: email },
                        dataType: 'json',
                        success: function(response) {
                            if (response.exists) {
                                $('#emailStatus').html('<span class="text-danger"><i class="fas fa-times-circle me-1"></i> Email already registered</span>');
                                $('#email').addClass('is-invalid').removeClass('is-valid');
                            } else {
                                $('#emailStatus').html('<span class="text-success"><i class="fas fa-check-circle me-1"></i> Email available</span>');
                                $('#email').addClass('is-valid').removeClass('is-invalid');
                            }
                        }
                    });
                }, 500);
            }
        });

        // Password strength on input
        $('#password').on('input', function() {
            checkPasswordStrength($(this).val());
            checkPasswordMatch();
        });

        // Confirm password match
        $('#confirm_password, #password').on('input', checkPasswordMatch);
        
        function checkPasswordMatch() {
            const password = $('#password').val();
            const confirm = $('#confirm_password').val();
            
            if (confirm.length > 0) {
                if (password === confirm) {
                    $('#passwordMatch').html('<span class="text-success"><i class="fas fa-check-circle me-1"></i> Passwords match</span>');
                    $('#confirm_password').addClass('is-valid').removeClass('is-invalid');
                } else {
                    $('#passwordMatch').html('<span class="text-danger"><i class="fas fa-times-circle me-1"></i> Passwords do not match</span>');
                    $('#confirm_password').addClass('is-invalid').removeClass('is-valid');
                }
            }
        }

        // Toggle password visibility
        $('#togglePassword').click(function() {
            const password = $('#password');
            const icon = $(this).find('i');
            
            if (password.attr('type') === 'password') {
                password.attr('type', 'text');
                icon.removeClass('fa-eye').addClass('fa-eye-slash');
            } else {
                password.attr('type', 'password');
                icon.removeClass('fa-eye-slash').addClass('fa-eye');
            }
        });

        $('#toggleConfirmPassword').click(function() {
            const confirmPassword = $('#confirm_password');
            const icon = $(this).find('i');
            
            if (confirmPassword.attr('type') === 'password') {
                confirmPassword.attr('type', 'text');
                icon.removeClass('fa-eye').addClass('fa-eye-slash');
            } else {
                confirmPassword.attr('type', 'password');
                icon.removeClass('fa-eye-slash').addClass('fa-eye');
            }
        });

        // Registration form submission
        $('#registerUserForm').on('submit', function(e) {
            e.preventDefault();
            
            // Validate password strength
            const password = $('#password').val();
            const checks = checkPasswordStrength(password);
            const strength = Object.values(checks).filter(v => v).length;
            
            if (strength < 3) {
                $('#registerMessage').html('<div class="alert alert-danger"><i class="fas fa-exclamation-triangle me-2"></i>Please use a stronger password</div>');
                return;
            }
            
            // Check password match
            if (password !== $('#confirm_password').val()) {
                $('#registerMessage').html('<div class="alert alert-danger"><i class="fas fa-exclamation-triangle me-2"></i>Passwords do not match</div>');
                return;
            }
            
            // Check terms
            if (!$('#terms').is(':checked')) {
                $('#registerMessage').html('<div class="alert alert-danger"><i class="fas fa-exclamation-triangle me-2"></i>You must agree to the terms</div>');
                return;
            }
            
            // Disable submit button
            $(this).find('button[type="submit"]').prop('disabled', true).html('<span class="spinner-border spinner-border-sm me-2"></span>Creating Account...');
            
            $.ajax({
                url: 'api/register_user.php',
                type: 'POST',
                data: $(this).serialize(),
                dataType: 'json',
                success: function(response) {
                    if (response.success) {
                        // Show verification section
                        $('#registerForm').hide();
                        $('#verificationUserId').val(response.user_id);
                        $('#verificationEmail').text(response.email);
                        $('#verificationSection').fadeIn();
                        
                        // Start timer
                        startTimer(600); // 10 minutes
                        
                        $('#registerMessage').html('<div class="alert alert-success"><i class="fas fa-check-circle me-2"></i>' + response.message + '</div>');
                    } else {
                        $('#registerMessage').html('<div class="alert alert-danger"><i class="fas fa-times-circle me-2"></i>' + response.message + '</div>');
                        $('button[type="submit"]').prop('disabled', false).html('<i class="fas fa-user-plus me-2"></i>Create Account');
                    }
                },
                error: function() {
                    $('#registerMessage').html('<div class="alert alert-danger"><i class="fas fa-times-circle me-2"></i>An error occurred. Please try again.</div>');
                    $('button[type="submit"]').prop('disabled', false).html('<i class="fas fa-user-plus me-2"></i>Create Account');
                }
            });
        });

        // Timer function
        let timerInterval;
        function startTimer(seconds) {
            clearInterval(timerInterval);
            const timerDisplay = $('#timer');
            
            timerInterval = setInterval(function() {
                const minutes = Math.floor(seconds / 60);
                const remainingSeconds = seconds % 60;
                
                timerDisplay.text(`${minutes.toString().padStart(2, '0')}:${remainingSeconds.toString().padStart(2, '0')}`);
                
                if (seconds <= 0) {
                    clearInterval(timerInterval);
                    timerDisplay.text('00:00');
                    $('#codeTimer').removeClass('bg-light text-dark').addClass('bg-danger text-white');
                }
                
                seconds--;
            }, 1000);
        }

        // Verify code form submission
        $('#verifyCodeForm').on('submit', function(e) {
            e.preventDefault();
            
            $(this).find('button[type="submit"]').prop('disabled', true).html('<span class="spinner-border spinner-border-sm me-2"></span>Verifying...');
            
            $.ajax({
                url: 'api/verify_email.php',
                type: 'POST',
                data: $(this).serialize(),
                dataType: 'json',
                success: function(response) {
                    if (response.success) {
                        $('#verificationMessage').html('<div class="alert alert-success"><i class="fas fa-check-circle me-2"></i>' + response.message + '</div>');
                        setTimeout(function() {
                            window.location.href = 'login.php';
                        }, 2000);
                    } else {
                        $('#verificationMessage').html('<div class="alert alert-danger"><i class="fas fa-times-circle me-2"></i>' + response.message + '</div>');
                        $('button[type="submit"]').prop('disabled', false).html('<i class="fas fa-check-circle me-2"></i>Verify Email');
                    }
                },
                error: function() {
                    $('#verificationMessage').html('<div class="alert alert-danger"><i class="fas fa-times-circle me-2"></i>An error occurred. Please try again.</div>');
                    $('button[type="submit"]').prop('disabled', false).html('<i class="fas fa-check-circle me-2"></i>Verify Email');
                }
            });
        });

        // Resend code
        $('#resendCode').on('click', function() {
            const userId = $('#verificationUserId').val();
            
            $(this).prop('disabled', true).html('<span class="spinner-border spinner-border-sm me-2"></span>Sending...');
            
            $.ajax({
                url: 'api/resend_verification.php',
                type: 'POST',
                data: { user_id: userId },
                dataType: 'json',
                success: function(response) {
                    if (response.success) {
                        $('#verificationMessage').html('<div class="alert alert-success"><i class="fas fa-check-circle me-2"></i>' + response.message + '</div>');
                        startTimer(600); // Reset timer
                    } else {
                        $('#verificationMessage').html('<div class="alert alert-danger"><i class="fas fa-times-circle me-2"></i>' + response.message + '</div>');
                    }
                    $('#resendCode').prop('disabled', false).html('<i class="fas fa-redo-alt me-1"></i>Resend Verification Code');
                },
                error: function() {
                    $('#verificationMessage').html('<div class="alert alert-danger"><i class="fas fa-times-circle me-2"></i>An error occurred. Please try again.</div>');
                    $('#resendCode').prop('disabled', false).html('<i class="fas fa-redo-alt me-1"></i>Resend Verification Code');
                }
            });
        });
    </script>
</body>
</html>