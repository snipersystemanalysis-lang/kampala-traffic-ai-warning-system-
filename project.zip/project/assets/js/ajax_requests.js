function makeAjaxRequest(url, method, data, successCallback) {
    $.ajax({
        url: url,
        type: method,
        data: data,
        dataType: 'json',
        success: function(response) {
            if (successCallback) {
                successCallback(response);
            }
        },
        error: function(xhr, status, error) {
            console.error('AJAX Error:', error);
            alert('An error occurred. Please try again.');
        }
    });
}

function loadDataWithAjax(url, containerId) {
    $.ajax({
        url: url,
        type: 'GET',
        dataType: 'json',
        success: function(response) {
            if (response.success) {
                $(containerId).html(JSON.stringify(response.data));
            }
        },
        error: function(xhr, status, error) {
            console.error('Error loading data:', error);
        }
    });
}

function submitFormAjax(formId, url, successCallback) {
    $(formId).on('submit', function(e) {
        e.preventDefault();

        $.ajax({
            url: url,
            type: 'POST',
            data: $(this).serialize(),
            dataType: 'json',
            success: function(response) {
                if (successCallback) {
                    successCallback(response);
                }
            },
            error: function(xhr, status, error) {
                console.error('Form submission error:', error);
                alert('An error occurred. Please try again.');
            }
        });
    });
}
