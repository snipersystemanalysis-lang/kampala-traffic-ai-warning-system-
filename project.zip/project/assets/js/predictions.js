function getPredictionClass(level) {
    switch(level.toLowerCase()) {
        case 'heavy':
            return 'danger';
        case 'moderate':
            return 'warning';
        case 'light':
            return 'success';
        default:
            return 'info';
    }
}

function formatPrediction(prediction) {
    const alertClass = getPredictionClass(prediction.predicted_level);

    return `
        <div class="col-md-6 mb-3">
            <div class="alert alert-${alertClass}">
                <h5>${prediction.location_name}</h5>
                <p><strong>Predicted Level:</strong> ${prediction.predicted_level}</p>
                <p><strong>Time:</strong> ${prediction.prediction_time}</p>
                <p><strong>Confidence:</strong> ${prediction.confidence_score}%</p>
            </div>
        </div>
    `;
}

function displayPredictions(predictions, containerId) {
    let html = '';
    predictions.forEach(function(prediction) {
        html += formatPrediction(prediction);
    });
    $(containerId).html(html);
}

function getTrafficRecommendation(level, location) {
    if (level === 'Heavy') {
        return `Heavy congestion expected at ${location}. Consider alternative routes.`;
    } else if (level === 'Moderate') {
        return `Moderate traffic expected at ${location}. Plan accordingly.`;
    } else {
        return `Light traffic expected at ${location}. Good time to travel.`;
    }
}
