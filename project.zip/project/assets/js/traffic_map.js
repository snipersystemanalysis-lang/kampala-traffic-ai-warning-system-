function initTrafficMap(mapElementId, centerLat, centerLng) {
    const map = new google.maps.Map(document.getElementById(mapElementId), {
        center: { lat: centerLat, lng: centerLng },
        zoom: 12,
        mapTypeId: 'roadmap'
    });

    return map;
}

function addMarkerToMap(map, lat, lng, title, infoContent) {
    const marker = new google.maps.Marker({
        position: { lat: lat, lng: lng },
        map: map,
        title: title
    });

    if (infoContent) {
        const infoWindow = new google.maps.InfoWindow({
            content: infoContent
        });

        marker.addListener('click', function() {
            infoWindow.open(map, marker);
        });
    }

    return marker;
}

function setTrafficLayer(map) {
    const trafficLayer = new google.maps.TrafficLayer();
    trafficLayer.setMap(map);
    return trafficLayer;
}

function addHeatmap(map, locations) {
    const heatmapData = locations.map(function(location) {
        return new google.maps.LatLng(location.lat, location.lng);
    });

    const heatmap = new google.maps.visualization.HeatmapLayer({
        data: heatmapData
    });

    heatmap.setMap(map);
    return heatmap;
}
