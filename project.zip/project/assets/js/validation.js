function validateEmail(email) {
    const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return re.test(email);
}

function validatePassword(password) {
    return password.length >= 6;
}

function validateForm(formId) {
    const form = document.getElementById(formId);
    const email = form.querySelector('input[type="email"]');
    const password = form.querySelector('input[type="password"]');

    if (email && !validateEmail(email.value)) {
        alert('Please enter a valid email address');
        return false;
    }

    if (password && !validatePassword(password.value)) {
        alert('Password must be at least 6 characters long');
        return false;
    }

    return true;
}

function sanitizeInput(input) {
    const div = document.createElement('div');
    div.textContent = input;
    return div.innerHTML;
}
