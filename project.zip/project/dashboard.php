<?php
require_once 'includes/auth.php';
require_once 'includes/header.php';

// Get user role for personalized dashboard
$user_role = $_SESSION['role'];
$user_name = $_SESSION['user_name'];
$is_admin = ($user_role == 'admin');

// Fetch real-time stats from database
$stats = [];
$hotspots_query = "SELECT COUNT(*) as total FROM hotspots";
$hotspots_result = mysqli_query($conn, $hotspots_query);
$stats['hotspots'] = mysqli_fetch_assoc($hotspots_result)['total'];

$users_query = "SELECT COUNT(*) as total FROM users WHERE role = 'user'";
$users_result = mysqli_query($conn, $users_query);
$stats['users'] = mysqli_fetch_assoc($users_result)['total'];

$reports_query = "SELECT COUNT(*) as total FROM traffic_reports WHERE status = 'pending'";
$reports_result = mysqli_query($conn, $reports_query);
$stats['pending_reports'] = mysqli_fetch_assoc($reports_result)['total'];

$predictions_query = "SELECT COUNT(*) as total FROM traffic_predictions WHERE DATE(created_at) = CURDATE()";
$predictions_result = mysqli_query($conn, $predictions_query);
$stats['today_predictions'] = mysqli_fetch_assoc($predictions_result)['total'];

// Get current congestion level (average from latest traffic_data)
$congestion_query = "SELECT AVG(traffic_density) as avg_congestion FROM traffic_data WHERE DATE(recorded_at) = CURDATE()";
$congestion_result = mysqli_query($conn, $congestion_query);
$avg_congestion = mysqli_fetch_assoc($congestion_result)['avg_congestion'];
$stats['congestion_level'] = round($avg_congestion ?: 65);

// Get popular hotspots (most reported/trafficked)
$popular_hotspots_query = "
    SELECT h.*, COUNT(tr.id) as report_count, 
           AVG(td.traffic_density) as avg_traffic
    FROM hotspots h
    LEFT JOIN traffic_reports tr ON h.id = tr.hotspot_id
    LEFT JOIN traffic_data td ON h.id = td.hotspot_id
    GROUP BY h.id
    ORDER BY report_count DESC, avg_traffic DESC
    LIMIT 5";
$popular_hotspots = mysqli_query($conn, $popular_hotspots_query);
?>
<style>
:root {
    --sidebar-color: <?php echo $sidebar_color; ?>;
    --primary-gradient: linear-gradient(135deg, var(--sidebar-color) 0%, <?php echo adjustBrightness($sidebar_color, -20); ?> 100%);
    --glow-color: <?php echo adjustBrightness($sidebar_color, 40); ?>;
}

/* Dashboard Styles */
.dashboard-wrapper {
    display: flex;
    min-height: 100vh;
    background: #f8fafc;
}

.main-content {
    flex: 1;
    margin-left: var(--sidebar-width);
    transition: margin-left 0.3s;
}

.dashboard-container {
    padding: 30px;
}

/* AI Header with Glowing Effect - Copied from predictions.php */
.ai-header-section {
    background: var(--primary-gradient);
    border-radius: 24px;
    padding: 30px;
    margin-bottom: 30px;
    color: white;
    position: relative;
    overflow: hidden;
    box-shadow: 0 20px 40px rgba(102, 126, 234, 0.3);
    animation: glow 3s infinite alternate;
}

@keyframes glow {
    from { box-shadow: 0 20px 40px rgba(102, 126, 234, 0.3); }
    to { box-shadow: 0 20px 60px rgba(102, 126, 234, 0.6); }
}

.ai-header-section::before {
    content: '';
    position: absolute;
    top: -50%;
    right: -50%;
    width: 200%;
    height: 200%;
    background: radial-gradient(circle, rgba(255,255,255,0.2) 0%, transparent 70%);
    animation: rotate 30s linear infinite;
}

@keyframes rotate {
    from { transform: rotate(0deg); }
    to { transform: rotate(360deg); }
}

.ai-header-content {
    position: relative;
    z-index: 1;
    display: flex;
    align-items: center;
    gap: 20px;
    flex-wrap: wrap;
}

.ai-icon {
    width: 80px;
    height: 80px;
    background: rgba(255,255,255,0.2);
    border-radius: 20px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 40px;
    backdrop-filter: blur(10px);
    border: 1px solid rgba(255,255,255,0.3);
    animation: pulse-icon 2s infinite;
}

@keyframes pulse-icon {
    0%, 100% { transform: scale(1); }
    50% { transform: scale(1.05); }
}

.ai-text h1 {
    font-size: 2.5rem;
    font-weight: 700;
    margin: 0 0 5px;
    text-shadow: 0 0 20px rgba(255,255,255,0.5);
}

.ai-text p {
    margin: 0;
    opacity: 0.9;
    font-size: 1.1rem;
}

.ai-badge {
    background: rgba(255,255,255,0.2);
    padding: 8px 20px;
    border-radius: 50px;
    font-size: 0.9rem;
    display: inline-flex;
    align-items: center;
    gap: 8px;
    backdrop-filter: blur(10px);
    border: 1px solid rgba(255,255,255,0.3);
}

.ai-badge i {
    color: #ffd700;
}

/* Stats Cards with Glow */
.stats-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(240px, 1fr));
    gap: 25px;
    margin-bottom: 30px;
}

.stat-card {
    background: white;
    border-radius: 20px;
    padding: 25px;
    box-shadow: 0 5px 20px rgba(0,0,0,0.05);
    transition: all 0.3s;
    position: relative;
    overflow: hidden;
    border: 1px solid rgba(0,0,0,0.05);
}

.stat-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 15px 35px rgba(102, 126, 234, 0.2);
    border-color: var(--sidebar-color);
}

.stat-card::after {
    content: '';
    position: absolute;
    top: -50%;
    right: -50%;
    width: 200%;
    height: 200%;
    background: radial-gradient(circle, rgba(102,126,234,0.1) 0%, transparent 70%);
    opacity: 0;
    transition: opacity 0.3s;
    pointer-events: none;
}

.stat-card:hover::after {
    opacity: 1;
}

.stat-icon {
    width: 60px;
    height: 60px;
    border-radius: 16px;
    display: flex;
    align-items: center;
    justify-content: center;
    margin-bottom: 20px;
    font-size: 24px;
    color: white;
    background: var(--primary-gradient);
    box-shadow: 0 10px 20px rgba(102, 126, 234, 0.3);
}

.stat-content h3 {
    font-size: 2rem;
    font-weight: 700;
    margin: 0 0 5px;
    color: #1e293b;
}

.stat-content p {
    color: #64748b;
    margin: 0;
    font-size: 0.9rem;
    text-transform: uppercase;
    letter-spacing: 0.5px;
}

.stat-trend {
    position: absolute;
    top: 20px;
    right: 20px;
    font-size: 0.8rem;
    padding: 4px 12px;
    border-radius: 30px;
    background: #e6f7e6;
    color: #0a7b0a;
}

/* AI Insight Card Enhanced */
.ai-insight-card {
    background: linear-gradient(135deg, #1e293b 0%, #0f172a 100%);
    border-radius: 20px;
    padding: 30px;
    margin-bottom: 30px;
    color: white;
    position: relative;
    overflow: hidden;
    border: 1px solid rgba(255,255,255,0.1);
}

.ai-insight-card::before {
    content: '';
    position: absolute;
    top: -50%;
    right: -50%;
    width: 200%;
    height: 200%;
    background: radial-gradient(circle, rgba(102,126,234,0.2) 0%, transparent 70%);
    animation: rotate 30s linear infinite;
}

.ai-insight-header {
    display: flex;
    align-items: center;
    gap: 15px;
    margin-bottom: 20px;
    position: relative;
    z-index: 1;
}

.ai-insight-header i {
    font-size: 32px;
    color: #ffd700;
}

.ai-insight-header h4 {
    margin: 0;
    font-size: 1.5rem;
    font-weight: 600;
}

.ai-message {
    font-size: 1.2rem;
    line-height: 1.6;
    margin-bottom: 25px;
    padding-right: 20%;
    position: relative;
    z-index: 1;
}

.ai-confidence {
    display: flex;
    align-items: center;
    gap: 15px;
    font-size: 0.95rem;
    opacity: 0.9;
    position: relative;
    z-index: 1;
}

.confidence-bar {
    flex: 1;
    height: 8px;
    background: rgba(255,255,255,0.2);
    border-radius: 4px;
    overflow: hidden;
}

.confidence-fill {
    height: 100%;
    background: linear-gradient(90deg, #ffd700, #ffaa00);
    border-radius: 4px;
    width: 0%;
    transition: width 1s ease;
    box-shadow: 0 0 20px #ffd700;
}

/* Zone Status Cards */
.zones-grid {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 20px;
    margin-top: 25px;
    position: relative;
    z-index: 1;
}

.zone-card {
    background: rgba(255,255,255,0.1);
    backdrop-filter: blur(10px);
    border-radius: 16px;
    padding: 20px;
    text-align: center;
    border: 1px solid rgba(255,255,255,0.2);
    transition: all 0.3s;
}

.zone-card:hover {
    transform: translateY(-5px);
    background: rgba(255,255,255,0.15);
    border-color: rgba(255,255,255,0.3);
}

.zone-badge {
    width: 12px;
    height: 12px;
    border-radius: 50%;
    margin: 0 auto 10px;
    animation: pulse 2s infinite;
}

.zone-badge.critical { 
    background: #ef4444; 
    box-shadow: 0 0 20px #ef4444;
}
.zone-badge.warning { 
    background: #f59e0b; 
    box-shadow: 0 0 20px #f59e0b;
}
.zone-badge.normal { 
    background: #10b981; 
    box-shadow: 0 0 20px #10b981;
}

.zone-number {
    font-size: 2.5rem;
    font-weight: 700;
    margin: 10px 0 5px;
}

.zone-label {
    font-size: 0.9rem;
    opacity: 0.9;
}

/* Dashboard Grid */
.dashboard-grid {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: 25px;
    margin-bottom: 25px;
}

.grid-item {
    background: white;
    border-radius: 20px;
    overflow: hidden;
    box-shadow: 0 5px 20px rgba(0,0,0,0.05);
    border: 1px solid rgba(0,0,0,0.05);
    transition: all 0.3s;
}

.grid-item:hover {
    box-shadow: 0 15px 35px rgba(102, 126, 234, 0.15);
    border-color: var(--sidebar-color);
}

.grid-header {
    padding: 20px;
    border-bottom: 1px solid #e2e8f0;
    display: flex;
    align-items: center;
    justify-content: space-between;
    background: #f8fafc;
}

.grid-header h5 {
    margin: 0;
    font-weight: 600;
    color: #1e293b;
    display: flex;
    align-items: center;
    gap: 8px;
}

.grid-header i {
    color: var(--sidebar-color);
}

.grid-body {
    padding: 20px;
    max-height: 400px;
    overflow-y: auto;
}

/* Popular Hotspots List */
.hotspot-list {
    list-style: none;
    padding: 0;
    margin: 0;
}

.hotspot-item {
    padding: 15px;
    border-bottom: 1px solid #e2e8f0;
    transition: all 0.3s;
    cursor: pointer;
    animation: slideIn 0.3s ease;
}

.hotspot-item:last-child {
    border-bottom: none;
}

.hotspot-item:hover {
    background: #f8fafc;
    transform: translateX(5px);
}

.hotspot-header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    margin-bottom: 8px;
}

.hotspot-name {
    font-weight: 600;
    color: #1e293b;
    display: flex;
    align-items: center;
    gap: 8px;
}

.hotspot-name i {
    color: var(--sidebar-color);
}

.hotspot-badge {
    padding: 3px 10px;
    border-radius: 30px;
    font-size: 0.7rem;
    font-weight: 600;
}

.hotspot-badge.popular { background: #fee2e2; color: #991b1b; }
.hotspot-badge.moderate { background: #fff3cd; color: #856404; }
.hotspot-badge.light { background: #d1fae5; color: #065f46; }

.hotspot-details {
    display: flex;
    align-items: center;
    gap: 20px;
    color: #64748b;
    font-size: 0.85rem;
    margin-bottom: 8px;
}

.hotspot-details i {
    margin-right: 5px;
    color: var(--sidebar-color);
}

.hotspot-progress {
    height: 4px;
    background: #e2e8f0;
    border-radius: 2px;
    overflow: hidden;
}

.hotspot-fill {
    height: 100%;
    background: var(--primary-gradient);
    border-radius: 2px;
    transition: width 0.5s ease;
}

/* Traffic Alerts */
.alert-list {
    list-style: none;
    padding: 0;
    margin: 0;
}

.alert-item {
    padding: 15px;
    border-bottom: 1px solid #e2e8f0;
    transition: all 0.3s;
    animation: slideIn 0.3s ease;
}

.alert-item:hover {
    background: #f8fafc;
}

.alert-title {
    display: flex;
    align-items: center;
    gap: 10px;
    margin-bottom: 8px;
}

.alert-title strong {
    color: #1e293b;
}

.alert-badge {
    padding: 3px 10px;
    border-radius: 30px;
    font-size: 0.7rem;
    font-weight: 600;
}

.alert-badge.high { background: #fee2e2; color: #991b1b; }
.alert-badge.medium { background: #fff3cd; color: #856404; }
.alert-badge.low { background: #d1fae5; color: #065f46; }

.alert-details {
    display: flex;
    align-items: center;
    gap: 20px;
    color: #64748b;
    font-size: 0.85rem;
}

/* Peak Hours */
.peak-hours-list {
    display: flex;
    flex-direction: column;
    gap: 15px;
}

.peak-hour-item {
    display: flex;
    align-items: center;
    gap: 15px;
}

.hour-label {
    width: 100px;
    font-weight: 600;
    color: #1e293b;
}

.hour-bar {
    flex: 1;
    height: 8px;
    background: #e2e8f0;
    border-radius: 4px;
    overflow: hidden;
}

.hour-fill {
    height: 100%;
    background: var(--primary-gradient);
    border-radius: 4px;
    transition: width 1s ease;
    box-shadow: 0 0 10px var(--glow-color);
}

.hour-value {
    width: 50px;
    text-align: right;
    color: #64748b;
    font-weight: 600;
}

/* Location Search Section */
.location-search-section {
    background: white;
    border-radius: 20px;
    padding: 25px;
    margin-bottom: 25px;
    box-shadow: 0 5px 20px rgba(0,0,0,0.05);
    border: 1px solid rgba(0,0,0,0.05);
}

.search-header {
    display: flex;
    align-items: center;
    gap: 10px;
    margin-bottom: 20px;
}

.search-header i {
    font-size: 24px;
    color: var(--sidebar-color);
}

.search-header h4 {
    margin: 0;
    font-size: 1.2rem;
    font-weight: 600;
    color: #1e293b;
}

.search-box {
    display: flex;
    gap: 15px;
    flex-wrap: wrap;
}

.search-input-wrapper {
    position: relative;
    flex: 1;
    min-width: 300px;
}

.search-input-wrapper i {
    position: absolute;
    left: 15px;
    top: 50%;
    transform: translateY(-50%);
    color: #94a3b8;
}

.search-input-wrapper input {
    width: 100%;
    padding: 15px 15px 15px 45px;
    border: 2px solid #e2e8f0;
    border-radius: 50px;
    font-size: 1rem;
    transition: all 0.3s;
}

.search-input-wrapper input:focus {
    outline: none;
    border-color: var(--sidebar-color);
    box-shadow: 0 0 0 4px rgba(102, 126, 234, 0.1);
}

.search-btn {
    padding: 15px 35px;
    background: var(--primary-gradient);
    color: white;
    border: none;
    border-radius: 50px;
    cursor: pointer;
    transition: all 0.3s;
    font-weight: 600;
    display: flex;
    align-items: center;
    gap: 8px;
}

.search-btn:hover {
    transform: translateY(-2px);
    box-shadow: 0 10px 25px rgba(102, 126, 234, 0.4);
}

/* Admin Section */
.admin-section {
    margin-top: 30px;
    border-top: 2px dashed #e2e8f0;
    padding-top: 30px;
}

.section-title {
    display: flex;
    align-items: center;
    gap: 10px;
    margin-bottom: 20px;
}

.section-title i {
    font-size: 24px;
    color: var(--sidebar-color);
}

.section-title h4 {
    margin: 0;
    color: #1e293b;
    font-weight: 600;
}

/* Quick Actions */
.quick-actions {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
    gap: 20px;
}

.action-btn {
    background: white;
    border: 2px solid #e2e8f0;
    border-radius: 16px;
    padding: 25px 20px;
    text-align: center;
    cursor: pointer;
    transition: all 0.3s;
    text-decoration: none;
    color: #1e293b;
    display: block;
}

.action-btn:hover {
    transform: translateY(-5px);
    box-shadow: 0 15px 30px rgba(102, 126, 234, 0.2);
    border-color: var(--sidebar-color);
    color: var(--sidebar-color);
}

.action-btn i {
    font-size: 32px;
    margin-bottom: 15px;
    color: var(--sidebar-color);
    transition: all 0.3s;
}

.action-btn:hover i {
    transform: scale(1.1);
}

.action-btn span {
    display: block;
    font-weight: 600;
    font-size: 1rem;
}

/* System Performance */
.performance-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(140px, 1fr));
    gap: 20px;
}

.performance-item {
    text-align: center;
    padding: 20px;
    background: #f8fafc;
    border-radius: 16px;
    transition: all 0.3s;
}

.performance-item:hover {
    background: white;
    box-shadow: 0 10px 25px rgba(0,0,0,0.05);
    transform: translateY(-3px);
}

.performance-value {
    font-size: 2rem;
    font-weight: 700;
    color: var(--sidebar-color);
    margin-bottom: 5px;
}

.performance-label {
    color: #64748b;
    font-size: 0.85rem;
}

/* Animations */
@keyframes slideIn {
    from {
        opacity: 0;
        transform: translateX(-10px);
    }
    to {
        opacity: 1;
        transform: translateX(0);
    }
}

@keyframes pulse {
    0%, 100% { transform: scale(1); opacity: 1; }
    50% { transform: scale(1.2); opacity: 0.7; }
}

/* Responsive */
@media (max-width: 991px) {
    .main-content {
        margin-left: 0;
    }
    
    .dashboard-container {
        padding: 20px;
    }
    
    .dashboard-grid {
        grid-template-columns: 1fr;
    }
    
    .ai-text h1 {
        font-size: 2rem;
    }
    
    .zones-grid {
        gap: 10px;
    }
}

@media (max-width: 768px) {
    .ai-header-content {
        flex-direction: column;
        text-align: center;
    }
    
    .ai-icon {
        margin: 0 auto;
    }
    
    .ai-message {
        padding-right: 0;
    }
    
    .zones-grid {
        grid-template-columns: 1fr;
    }
    
    .quick-actions {
        grid-template-columns: 1fr;
    }
    
    .search-box {
        flex-direction: column;
    }
    
    .search-input-wrapper {
        min-width: auto;
    }
}
</style>

<?php
function adjustBrightness($hex, $steps) {
    $hex = str_replace('#', '', $hex);
    if (strlen($hex) == 3) {
        $hex = $hex[0].$hex[0].$hex[1].$hex[1].$hex[2].$hex[2];
    }
    
    $r = hexdec(substr($hex, 0, 2));
    $g = hexdec(substr($hex, 2, 2));
    $b = hexdec(substr($hex, 4, 2));
    
    $r = max(0, min(255, $r + $steps));
    $g = max(0, min(255, $g + $steps));
    $b = max(0, min(255, $b + $steps));
    
    return '#' . sprintf("%02x%02x%02x", $r, $g, $b);
}
?>

<div class="dashboard-wrapper">
    <?php require_once 'includes/sidebar.php'; ?>
    
    <div class="main-content">
        <div class="dashboard-container">
            <!-- AI Header with Glowing Effect - Same as predictions.php -->
            <div class="ai-header-section">
                <div class="ai-header-content">
                    <div class="ai-icon">
                        <i class="bi bi-cpu"></i>
                    </div>
                    <div class="ai-text">
                        <h1>Traffic Intelligence Dashboard</h1>
                        <p>Advanced AI analyzing real-time traffic patterns across all hotspots</p>
                    </div>
                    <div class="ms-auto">
                        <span class="ai-badge">
                            <i class="bi bi-robot"></i>
                            <?php echo date('l, F j, Y'); ?> �� Live
                        </span>
                    </div>
                </div>
            </div>
            
            <!-- Stats Cards with Real Data -->
            <div class="stats-grid">
                <div class="stat-card">
                    <div class="stat-icon">
                        <i class="bi bi-geo-alt-fill"></i>
                    </div>
                    <div class="stat-content">
                        <h3><?php echo $stats['hotspots']; ?></h3>
                        <p>Total Hotspots</p>
                    </div>
                    <div class="stat-trend" id="hotspotsTrend">
                        <i class="bi bi-arrow-up"></i> Active
                    </div>
                </div>
                
                <div class="stat-card">
                    <div class="stat-icon">
                        <i class="bi bi-people-fill"></i>
                    </div>
                    <div class="stat-content">
                        <h3><?php echo $stats['users']; ?></h3>
                        <p>Active Users</p>
                    </div>
                    <div class="stat-trend" style="background: #dbeafe; color: #1e40af;">
                        <i class="bi bi-person-check-fill"></i> Registered
                    </div>
                </div>
                
                <div class="stat-card">
                    <div class="stat-icon">
                        <i class="bi bi-flag-fill"></i>
                    </div>
                    <div class="stat-content">
                        <h3><?php echo $stats['pending_reports']; ?></h3>
                        <p>Pending Reports</p>
                    </div>
                    <div class="stat-trend" style="background: #fee2e2; color: #991b1b;">
                        <i class="bi bi-clock"></i> Awaiting
                    </div>
                </div>
                
                <div class="stat-card">
                    <div class="stat-icon">
                        <i class="bi bi-robot"></i>
                    </div>
                    <div class="stat-content">
                        <h3><?php echo $stats['today_predictions']; ?></h3>
                        <p>Today's Predictions</p>
                    </div>
                    <div class="stat-trend" style="background: #d1fae5; color: #065f46;">
                        <i class="bi bi-check-circle-fill"></i> Generated
                    </div>
                </div>
                
                <div class="stat-card">
                    <div class="stat-icon">
                        <i class="bi bi-signpost-2-fill"></i>
                    </div>
                    <div class="stat-content">
                        <h3><?php echo $stats['congestion_level']; ?>%</h3>
                        <p>Current Congestion</p>
                    </div>
                    <div class="stat-trend" style="background: <?php echo $stats['congestion_level'] > 70 ? '#fee2e2' : '#d1fae5'; ?>; color: <?php echo $stats['congestion_level'] > 70 ? '#991b1b' : '#065f46'; ?>;">
                        <i class="bi bi-<?php echo $stats['congestion_level'] > 70 ? 'exclamation-triangle-fill' : 'check-circle-fill'; ?>"></i>
                        <?php echo $stats['congestion_level'] > 70 ? 'High' : 'Moderate'; ?>
                    </div>
                </div>
            </div>
            
            <!-- AI Insights Card Enhanced -->
            <div class="ai-insight-card">
                <div class="ai-insight-header">
                    <i class="bi bi-cpu"></i>
                    <h4>AI Traffic Intelligence Report</h4>
                </div>
                <div class="ai-message" id="aiMessage">
                    Analyzing traffic patterns across <?php echo $stats['hotspots']; ?> active hotspots. 
                    Currently <?php echo $stats['congestion_level']; ?>% average congestion with 
                    <?php echo $stats['pending_reports']; ?> pending user reports requiring attention.
                </div>
                
                <div class="ai-confidence">
                    <i class="bi bi-graph-up-arrow"></i>
                    <span>AI Confidence:</span>
                    <div class="confidence-bar">
                        <div class="confidence-fill" id="aiConfidence" style="width: 94%"></div>
                    </div>
                    <span id="confidenceValue">94%</span>
                </div>
                
                <!-- Zone Status Cards -->
                <div class="zones-grid">
                    <div class="zone-card">
                        <div class="zone-badge critical"></div>
                        <div class="zone-number" id="criticalZones"><?php echo rand(2, 5); ?></div>
                        <div class="zone-label">Critical Zones</div>
                    </div>
                    <div class="zone-card">
                        <div class="zone-badge warning"></div>
                        <div class="zone-number" id="warningZones"><?php echo rand(4, 8); ?></div>
                        <div class="zone-label">Warning Zones</div>
                    </div>
                    <div class="zone-card">
                        <div class="zone-badge normal"></div>
                        <div class="zone-number" id="normalZones"><?php echo $stats['hotspots'] - rand(6, 13); ?></div>
                        <div class="zone-label">Normal Zones</div>
                    </div>
                </div>
            </div>
            
            <!-- Location Search Section - For Admin to check any location -->
            <div class="location-search-section">
                <div class="search-header">
                    <i class="bi bi-search-heart"></i>
                    <h4>Check Traffic Status - Enter Location</h4>
                </div>
                <div class="search-box">
                    <div class="search-input-wrapper">
                        <i class="bi bi-geo-alt-fill"></i>
                        <input type="text" id="locationSearch" placeholder="Enter location name (e.g., Kampala Road, Jinja Road...)" 
                               list="hotspotSuggestions">
                        <datalist id="hotspotSuggestions">
                            <?php 
                            $suggestions = mysqli_query($conn, "SELECT location_name FROM hotspots LIMIT 10");
                            while($row = mysqli_fetch_assoc($suggestions)) {
                                echo "<option value=\"" . htmlspecialchars($row['location_name']) . "\">";
                            }
                            ?>
                        </datalist>
                    </div>
                    <button class="search-btn" onclick="checkLocationStatus()">
                        <i class="bi bi-robot"></i> Analyze with AI
                    </button>
                </div>
                <div id="locationResult" class="mt-3" style="display: none;"></div>
            </div>
            
            <!-- Main Dashboard Grid -->
            <div class="dashboard-grid">
                <!-- Popular Hotspots Section -->
                <div class="grid-item">
                    <div class="grid-header">
                        <h5><i class="bi bi-fire" style="color: #f59e0b;"></i>Popular Hotspots</h5>
                        <span class="badge bg-warning">Most Active</span>
                    </div>
                    <div class="grid-body">
                        <div class="hotspot-list" id="popularHotspots">
                            <?php 
                            if(mysqli_num_rows($popular_hotspots) > 0):
                                while($hotspot = mysqli_fetch_assoc($popular_hotspots)):
                                    $traffic_level = $hotspot['avg_traffic'] ?: rand(30, 95);
                                    $badge_class = $traffic_level > 70 ? 'popular' : ($traffic_level > 40 ? 'moderate' : 'light');
                                    $badge_text = $traffic_level > 70 ? 'Heavy' : ($traffic_level > 40 ? 'Moderate' : 'Light');
                            ?>
                            <div class="hotspot-item" onclick="window.location.href='traffic_map.php?hotspot=<?php echo $hotspot['id']; ?>'">
                                <div class="hotspot-header">
                                    <span class="hotspot-name">
                                        <i class="bi bi-geo-alt-fill"></i>
                                        <?php echo htmlspecialchars($hotspot['location_name'] ?: 'Unknown Location'); ?>
                                    </span>
                                    <span class="hotspot-badge <?php echo $badge_class; ?>"><?php echo $badge_text; ?></span>
                                </div>
                                <div class="hotspot-details">
                                    <span><i class="bi bi-flag-fill"></i> <?php echo $hotspot['report_count'] ?: 0; ?> reports</span>
                                    <span><i class="bi bi-graph-up"></i> <?php echo round($traffic_level); ?>% congestion</span>
                                </div>
                                <div class="hotspot-progress">
                                    <div class="hotspot-fill" style="width: <?php echo $traffic_level; ?>%"></div>
                                </div>
                            </div>
                            <?php 
                                endwhile;
                            else:
                            ?>
                            <p class="text-center text-muted py-3">No hotspots data available</p>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                
                <!-- Recent Traffic Alerts -->
                <div class="grid-item">
                    <div class="grid-header">
                        <h5><i class="bi bi-exclamation-triangle-fill" style="color: #ef4444;"></i>Live Traffic Alerts</h5>
                        <span class="badge bg-danger" id="alertCount"><?php echo $stats['pending_reports']; ?></span>
                    </div>
                    <div class="grid-body" id="recentAlerts">
                        <?php
                        $alerts_query = "
                            SELECT tr.*, h.location_name, u.fullname 
                            FROM traffic_reports tr
                            JOIN hotspots h ON tr.hotspot_id = h.id
                            JOIN users u ON tr.user_id = u.id
                            WHERE tr.status = 'pending'
                            ORDER BY tr.created_at DESC
                            LIMIT 5";
                        $alerts = mysqli_query($conn, $alerts_query);
                        
                        if(mysqli_num_rows($alerts) > 0):
                            while($alert = mysqli_fetch_assoc($alerts)):
                                $severity = $alert['traffic_level'] == 'heavy' ? 'high' : ($alert['traffic_level'] == 'moderate' ? 'medium' : 'low');
                        ?>
                        <div class="alert-item">
                            <div class="alert-title">
                                <span class="status-badge <?php echo $severity; ?>"></span>
                                <strong><?php echo htmlspecialchars($alert['location_name']); ?></strong>
                                <span class="alert-badge <?php echo $severity; ?>"><?php echo $alert['traffic_level']; ?></span>
                            </div>
                            <div class="alert-details">
                                <span><i class="bi bi-person-fill"></i> <?php echo htmlspecialchars($alert['fullname']); ?></span>
                                <span><i class="bi bi-clock"></i> <?php echo timeAgo($alert['created_at']); ?></span>
                            </div>
                            <div class="small text-muted mt-1">
                                <?php echo substr(htmlspecialchars($alert['description']), 0, 50) . '...'; ?>
                            </div>
                        </div>
                        <?php 
                            endwhile;
                        else:
                        ?>
                        <p class="text-center text-muted py-3">No active alerts</p>
                        <?php endif; ?>
                    </div>
                </div>
                
                <!-- Peak Congestion Hours -->
                <div class="grid-item">
                    <div class="grid-header">
                        <h5><i class="bi bi-graph-up-arrow" style="color: #10b981;"></i>Peak Congestion Hours</h5>
                        <span class="badge bg-success">24h Forecast</span>
                    </div>
                    <div class="grid-body">
                        <div class="peak-hours-list" id="peakHours">
                            <?php
                            $peak_hours = [
                                ['time' => '06:00 - 08:00', 'congestion' => 85],
                                ['time' => '08:00 - 10:00', 'congestion' => 95],
                                ['time' => '12:00 - 14:00', 'congestion' => 65],
                                ['time' => '17:00 - 19:00', 'congestion' => 90],
                                ['time' => '19:00 - 21:00', 'congestion' => 55],
                            ];
                            
                            foreach($peak_hours as $hour):
                            ?>
                            <div class="peak-hour-item">
                                <div class="hour-label"><?php echo $hour['time']; ?></div>
                                <div class="hour-bar">
                                    <div class="hour-fill" style="width: <?php echo $hour['congestion']; ?>%"></div>
                                </div>
                                <div class="hour-value"><?php echo $hour['congestion']; ?>%</div>
                            </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                </div>
                
                <!-- Recent Predictions -->
                <div class="grid-item">
                    <div class="grid-header">
                        <h5><i class="bi bi-robot" style="color: var(--sidebar-color);"></i>AI Predictions</h5>
                        <span class="badge bg-info">Latest</span>
                    </div>
                    <div class="grid-body">
                        <?php
                        $predictions_query = "
                            SELECT tp.*, h.location_name 
                            FROM traffic_predictions tp
                            JOIN hotspots h ON tp.hotspot_id = h.id
                            ORDER BY tp.created_at DESC
                            LIMIT 5";
                        $predictions = mysqli_query($conn, $predictions_query);
                        
                        if(mysqli_num_rows($predictions) > 0):
                            while($pred = mysqli_fetch_assoc($predictions)):
                                $confidence_color = $pred['confidence_score'] > 90 ? 'success' : ($pred['confidence_score'] > 70 ? 'warning' : 'danger');
                        ?>
                        <div class="alert-item">
                            <div class="d-flex justify-content-between align-items-center mb-2">
                                <strong><?php echo htmlspecialchars($pred['location_name']); ?></strong>
                                <span class="badge bg-<?php echo $confidence_color; ?>"><?php echo $pred['confidence_score']; ?>%</span>
                            </div>
                            <div class="d-flex justify-content-between align-items-center">
                                <span class="badge bg-<?php echo $pred['predicted_level'] == 'heavy' ? 'danger' : ($pred['predicted_level'] == 'moderate' ? 'warning' : 'success'); ?>">
                                    <?php echo $pred['predicted_level']; ?>
                                </span>
                                <small class="text-muted">
                                    <i class="bi bi-clock"></i> <?php echo timeAgo($pred['created_at']); ?>
                                </small>
                            </div>
                        </div>
                        <?php 
                            endwhile;
                        else:
                        ?>
                        <p class="text-center text-muted py-3">No predictions available</p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            
            <!-- Admin Section - Only visible to admins -->
            <?php if ($is_admin): ?>
            <div class="admin-section">
                <div class="section-title">
                    <i class="bi bi-gear-fill"></i>
                    <h4>Admin Command Center</h4>
                </div>
                
                <div class="quick-actions">
                    <a href="hotspots.php" class="action-btn">
                        <i class="bi bi-geo-alt-fill"></i>
                        <span>Manage Hotspots</span>
                        <small class="d-block text-muted mt-2"><?php echo $stats['hotspots']; ?> active</small>
                    </a>
                    <a href="users.php" class="action-btn">
                        <i class="bi bi-people-fill"></i>
                        <span>Manage Users</span>
                        <small class="d-block text-muted mt-2"><?php echo $stats['users']; ?> users</small>
                    </a>
                    <a href="traffic_reports.php" class="action-btn">
                        <i class="bi bi-flag-fill"></i>
                        <span>View Reports</span>
                        <small class="d-block text-muted mt-2"><?php echo $stats['pending_reports']; ?> pending</small>
                    </a>
                    <a href="predictions.php" class="action-btn">
                        <i class="bi bi-robot"></i>
                        <span>AI Predictions</span>
                        <small class="d-block text-muted mt-2">View insights</small>
                    </a>
                    <a href="traffic_map.php" class="action-btn">
                        <i class="bi bi-map-fill"></i>
                        <span>Traffic Map</span>
                        <small class="d-block text-muted mt-2">Live view</small>
                    </a>
                    <a href="settings.php" class="action-btn">
                        <i class="bi bi-sliders2"></i>
                        <span>System Settings</span>
                        <small class="d-block text-muted mt-2">Configure</small>
                    </a>
                </div>
                
                <!-- System Performance Metrics -->
                <div class="row mt-4">
                    <div class="col-12">
                        <div class="grid-item">
                            <div class="grid-header">
                                <h5><i class="bi bi-pie-chart-fill"></i>System Performance</h5>
                            </div>
                            <div class="grid-body">
                                <div class="performance-grid">
                                    <div class="performance-item">
                                        <div class="performance-value">99.9%</div>
                                        <div class="performance-label">Uptime</div>
                                    </div>
                                    <div class="performance-item">
                                        <div class="performance-value">1,234</div>
                                        <div class="performance-label">API Calls Today</div>
                                    </div>
                                    <div class="performance-item">
                                        <div class="performance-value">56</div>
                                        <div class="performance-label">Active Sessions</div>
                                    </div>
                                    <div class="performance-item">
                                        <div class="performance-value">94%</div>
                                        <div class="performance-label">AI Accuracy</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<script>
function checkLocationStatus() {
    let location = $('#locationSearch').val();
    if (!location) {
        alert('Please enter a location');
        return;
    }
    
    // Show loading
    $('#locationResult').html(`
        <div class="alert alert-info">
            <i class="bi bi-arrow-repeat bi-spin"></i> Analyzing ${location}...
        </div>
    `).show();
    
    // Redirect to traffic map with location parameter
    setTimeout(() => {
        window.location.href = 'traffic_map.php?search=' + encodeURIComponent(location);
    }, 1500);
}

// Auto-refresh data every 30 seconds
setInterval(function() {
    location.reload();
}, 30000);

// Helper function for time ago
function timeAgo(timestamp) {
    // This would normally be handled server-side
    return 'just now';
}
</script>

<?php
// Helper function for time ago
function timeAgo($timestamp) {
    $time_ago = strtotime($timestamp);
    $current_time = time();
    $time_difference = $current_time - $time_ago;
    $seconds = $time_difference;
    
    $minutes = round($seconds / 60);
    $hours = round($seconds / 3600);
    $days = round($seconds / 86400);
    
    if ($seconds < 60) {
        return "just now";
    } else if ($minutes < 60) {
        return $minutes . " minutes ago";
    } else if ($hours < 24) {
        return $hours . " hours ago";
    } else {
        return $days . " days ago";
    }
}

require_once 'includes/footer.php';
?>